/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';
import { z } from 'zod';
import http from 'http';
import path from 'path';
import crypto from 'crypto';
import { createServer as createViteServer } from 'vite';
import { Server as SocketServer } from 'socket.io';
import { db } from './server/db.js';

// Global error handlers to prevent backend server downtime or silent crashes on transient errors
process.on('uncaughtException', (err) => {
  console.error('[SERVER CRITICAL] Uncaught exception logged:', err);
});
process.on('unhandledRejection', (reason, promise) => {
  console.error('[SERVER CRITICAL] Unhandled promise rejection logged:', reason);
});
import { 
  initGameEngine, 
  joinRoom, 
  forceRestartGame, 
  endGame, 
  translateToAmharicVoice 
} from './server/gameEngine.js';
import { 
  sendTelegramMessage,
  getTelegramHistory,
  handleUserTelegramCommand,
  handleUserTelegramPhoto,
  startTelegramBotPolling
} from './server/bot.js';
import { parseAndVerifyTelebirrReceipt } from './server/telebirrVerifier.js';
import { GoogleGenAI, Modality, Type } from '@google/genai';
import fs from 'fs';

const speechCacheFile = path.join(process.cwd(), 'data', 'speech_cache.json');
let speechCache: Record<string, string> = {};

try {
  if (fs.existsSync(speechCacheFile)) {
    const raw = fs.readFileSync(speechCacheFile, 'utf8');
    speechCache = JSON.parse(raw);
    console.log(`Loaded ${Object.keys(speechCache).length} items from Amharic TTS audio cache.`);
  }
} catch (err) {
  console.error("Failed to load Amharic speech cache file:", err);
}

function saveSpeechCache() {
  try {
    const dir = path.dirname(speechCacheFile);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(speechCacheFile, JSON.stringify(speechCache, null, 2), 'utf8');
  } catch (err) {
    console.error("Failed to save Amharic speech cache file:", err);
  }
}

let geminiAiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!geminiAiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is required");
    }
    geminiAiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return geminiAiClient;
}

const lastOtpRequest = new Map<string, number>();
const activeVerifications = new Set<string>();

async function sendSms(phone: string, message: string): Promise<boolean> {
  const isDev = process.env.NODE_ENV === 'development' || process.env.DEV_MODE === 'true';
  if (isDev) {
    console.log("\n==================================================");
    console.log("🔒 [DEV MODE OTP] SMS LOG (SIMULATED):");
    console.log(`📱 Phone: ${phone}`);
    console.log(`💬 Message: "${message}"`);
    console.log("==================================================\n");
    return true;
  }

  const token = process.env.AFROMESSAGE_TOKEN;
  const senderId = process.env.AFROMESSAGE_SENDER_ID;
  if (!token) {
    console.warn("⚠️ [SMS WARNING] AFROMESSAGE_TOKEN is not configured! Fallback to simulated log.");
    console.log(`📱 Phone: ${phone}`);
    console.log(`💬 Message: "${message}"`);
    return false;
  }

  try {
    const response = await fetch('https://api.afromessage.com/api/send', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        to: phone,
        message: message,
        sender: senderId || 'RayaBingo',
        callback: ''
      })
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error(`|SMS ERROR] AfroMessage API responded with status ${response.status}:`, errorText);
      return false;
    }

    const data = await response.json();
    console.log('|SMS SUCCESS] AfroMessage response:', data);
    return true;
  } catch (err: any) {
    console.error('|SMS EXCEPTION] Failed to send SMS via AfroMessage:', err.message);
    return false;
  }
}

async function triggerAIRecommendationOnly(txId: string, io: SocketServer) {
  // Give a small delay of 1.5 seconds for UI smoothness & transition effect
  await new Promise(r => setTimeout(r, 1500));

  const tx = db.getTransaction(txId);
  if (!tx || tx.status !== 'pending') return;

  const user = db.getUser(tx.userId);
  const allTransactions = db.getTransactions();
  const duplicateRefs = allTransactions.filter(
    t => t.id !== tx.id && t.referenceNumber && t.referenceNumber.trim().toUpperCase() === tx.referenceNumber?.trim().toUpperCase() && t.status === 'completed'
  );
  const isDuplicate = duplicateRefs.length > 0;
  const referenceNumber = (tx.referenceNumber || '').trim();

  let recommendation = 'REJECT';
  let explanation = '';
  let confidence = 50;

  if (process.env.GEMINI_API_KEY) {
    try {
      const ai = getGeminiClient();
      const prompt = `
Please audit the following pending transaction requested in Raya Bingo.

TRANSACTION DETAILS:
- ID: ${tx.id}
- Type: ${tx.type.toUpperCase()} (${(tx.type as string) === 'deposit' ? 'User claims to have deposited money' : 'User requests cashout'})
- Player Name: ${tx.userName} (User ID: ${tx.userId})
- Phone Number: ${tx.phoneNumber}
- Payment Method: ${tx.method.toUpperCase()}
- Amount: ${tx.amount} ETB
${tx.type === 'withdrawal' ? `- 5% Withdrawal Fee Deducted: ${(tx.amount * 0.05).toFixed(2)} ETB` : ''}
${tx.type === 'withdrawal' ? `- Net Client Payout: ${(tx.amount * 0.95).toFixed(2)} ETB` : ''}
- Reference Number provided: "${tx.referenceNumber || 'N/A'}"
- Created At: ${tx.createdAt}

USER CONTEXT:
- Saved Wallet Balance (Pre-Hold Deducted for Withdrawals): ${user ? user.balance : 0} ETB
- Account Status: ${user ? user.status : 'unknown'}

SYSTEM SIGNALS:
- Duplicate reference check: ${isDuplicate ? "DUPLICATE FOUND! High risk." : "Clean (no other completed transaction has this reference code)"}
- Reference length: ${referenceNumber ? `${referenceNumber.length} chars` : "N/A"}
- Reference format analysis: ${tx.method === 'telebirr' ? 'Telebirr codes are usually 10-letter alphanumeric strings.' : 'CBE Reference numbers are typically CBE alphanumeric string hashes.'}

IMPORTANT:
- Telebirr deposit: Must be exactly 10 characters and unique.
- Withdrawal: Confirm the user has sufficient assets.

Output a highly professional audit opinion.
`;

      const gRes = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              recommendation: {
                type: Type.STRING,
                description: "Must be 'APPROVE' or 'REJECT'"
              },
              confidence: {
                type: Type.INTEGER,
                description: "Confidence rating from 0 to 100"
              },
              explanation: {
                type: Type.STRING,
                description: "A professional, concise reason."
              }
            },
            required: ["recommendation", "confidence", "explanation"]
          }
        }
      });

      const auditResult = JSON.parse(gRes.text || '{}');
      recommendation = auditResult.recommendation || 'REJECT';
      explanation = auditResult.explanation || '';
      confidence = auditResult.confidence || 50;
    } catch (apiErr: any) {
      console.warn("AI Auto-approver query failed, falling back to rule engine:", apiErr.message || apiErr);
      if ((tx.type as string) === 'deposit') {
        if (isDuplicate || !referenceNumber || referenceNumber.length !== 10) {
          recommendation = 'REJECT';
          explanation = isDuplicate ? 'Duplicate reference code.' : 'Invalid format length.';
        } else {
          recommendation = 'APPROVE';
          explanation = 'Unique reference format verified.';
        }
      } else if (tx.type === 'withdrawal') {
        recommendation = 'APPROVE';
        explanation = 'Wallet balance verified.';
      }
    }
  } else {
    if ((tx.type as string) === 'deposit') {
      if (isDuplicate || !referenceNumber || referenceNumber.length !== 10) {
        recommendation = 'REJECT';
        explanation = 'Rule-based check failed.';
      } else {
        recommendation = 'APPROVE';
        explanation = 'Rule-based unique format matched.';
      }
    } else if (tx.type === 'withdrawal') {
      recommendation = 'APPROVE';
      explanation = 'Rule-based balance checked.';
    }
  }

  // Write recommendation comment on transaction, status ALWAYS remains 'pending'
  (tx as any).comment = `[AI Recommendation: ${recommendation}] Confidence: ${confidence}%. ${explanation}`;
  db.saveCollection('transactions.json', db.getTransactions());

  // Notify admins
  io.emit('admin:refresh_financials');
}

async function startServer() {
  const app = express();
  app.set('trust proxy', 1);
  const server = http.createServer(app);

  // --- ENTERPRISE SECURITY HEADERS (HELMET) ---
  const isProd = process.env.NODE_ENV === 'production';
  if (isProd) {
    app.use(helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'", "https://telegram.org", "https://*.telegram.org"],
          styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
          fontSrc: ["'self'", "https://fonts.gstatic.com"],
          imgSrc: ["'self'", "data:", "https://telegram.org", "https://*.telegram.org", "referrer", "no-referrer"],
          connectSrc: ["'self'", "wss:", "ws:", "https://api.telegram.org", "https://*.telegram.org"],
          frameSrc: ["'self'", "https://*.telegram.org", "https://telegram.org"],
        },
      },
      frameguard: false, // MANDATORY: allows sandboxed preview iframe to load flawlessly!
      crossOriginEmbedderPolicy: false
    }));
  } else {
    console.log('[HELMET] Bypassing helmet security configuration in development mode for seamless iframe preview rendering.');
  }

  // --- SECURE COOKIE / PROTECTION GLOBAL HEADERS ---
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('Referrer-Policy', 'no-referrer');
    next();
  });

  // --- SECURITY RATE LIMIT CONSTRAINTS ---
  const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes window
    max: 150, // Limit each IP address
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Too many auth requests from this IP. Verification throttled.' }
  });

  const apiLimiter = rateLimit({
    windowMs: 1 * 60 * 1000, 
    max: 400, // Limit general endpoints
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Rate limit exceeded.' }
  });

  // Apply general REST rate limits to our API scope
  app.use('/api/', apiLimiter);
  
  // Configure CORS and JSON Body Parsers
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));

  // Dynamically record the applet URL based on active client requests
  app.use((req, res, next) => {
    const host = req.get('host');
    if (host && !host.includes('api.telegram.org')) {
      const protocol = req.protocol === 'https' || req.headers['x-forwarded-proto'] === 'https' ? 'https' : 'http';
      const parsedUrl = `${protocol}://${host}`;
      if (db.getAppUrl() !== parsedUrl) {
        db.setAppUrl(parsedUrl);
        console.log(`[DYNAMIC URL UPDATE]: Detected current active host as "${parsedUrl}"`);
      }
    }
    next();
  });

  // Initialize Socket.io Server on port 3000
  const io = new SocketServer(server, {
    cors: {
      origin: '*',
      methods: ['GET', 'POST']
    }
  });

  // Load and configure real-time multiplayer loops
  initGameEngine(io);

  // Enterprise Security Configuration (JSON Web Tokens)
  const JWT_SECRET = process.env.JWT_SECRET || 'raya-bingo-enterprise-security-token-key-2519';

  const generateToken = (userId: string) => {
    return jwt.sign({ userId }, JWT_SECRET, { expiresIn: '24h' });
  };

  const authenticateToken = (req: any, res: any, next: any) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    
    if (!token) {
      return res.status(401).json({ error: 'Access Token required' });
    }

    try {
      const decoded: any = jwt.verify(token, JWT_SECRET);
      const user = db.getUser(decoded.userId);
      if (!user) {
        return res.status(403).json({ error: 'Invalid user session' });
      }
      req.user = user;
      next();
    } catch (e) {
      return res.status(403).json({ error: 'Malformed or expired access token' });
    }
  };

  // ==========================================
  // REST API ENDPOINTS
  // ==========================================

  // --- HEALTH CHECK ---
  app.get('/api/health', (req, res) => {
    // Dynamic App URL Auto-Discovery to ensure high-fidelity Telegram Web App redirects
    const host = req.get('host');
    if (host && (host.includes('.run.app') || host.includes('localhost') || host.includes('127.0.0.1'))) {
      const protocol = req.headers['x-forwarded-proto'] || req.protocol || 'https';
      const currentUrl = `${protocol}://${host}`;
      if (db.getAppUrl() !== currentUrl) {
        db.setAppUrl(currentUrl);
        console.log(`[ROUTING INTELLIGENCE] Dynamically discovered and persisted App URL: ${currentUrl}`);
      }
    }
    res.json({ status: 'ok', serverTime: new Date().toISOString() });
  });

  // --- GEMINI TEXT TO SPEECH VOICES ---
  app.get('/api/tts', async (req, res) => {
    const text = req.query.text as string;
    if (!text) {
      return res.status(400).json({ error: 'Text query parameter is required' });
    }

    // Serve from persistent cache if available
    const normalizedText = text.trim();
    if (speechCache[normalizedText]) {
      return res.json({ base64Audio: speechCache[normalizedText] });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.status(503).json({ error: 'Gemini API is currently not configured.' });
    }

    try {
      const ai = getGeminiClient();
      const response = await ai.models.generateContent({
        model: "gemini-3.1-flash-tts-preview",
        contents: [{ parts: [{ text: `Say in a professional Amharic male announcer voice: ${normalizedText}` }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Kore' } // Core prebuilt speech voice for standard tts modal preview
            }
          }
        }
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (!base64Audio) {
        throw new Error("No audio data returned from Gemini TTS");
      }

      // Populate local memory cache & persist to file asynchronously
      speechCache[normalizedText] = base64Audio;
      saveSpeechCache();

      res.json({ base64Audio });
    } catch (e: any) {
      console.log('Amharic speech synthesis routing fallback activated');
      // Fail gracefully with a specific error so client-side native TTS triggers
      res.status(200).json({ 
        error: 'Engine shift',
        fallbackToNative: true
      });
    }
  });

  // --- HARDENED INPUT VALIDATION SCHEMAS (ZOD) ---
  const registerSchema = z.object({
    name: z.string().min(2, "Name must be at least 2 characters."),
    phoneNumber: z.string().regex(/^(\+2519|\+2517|09|07)\d{8}$/, "Please enter a valid Ethiopian phone number (+2519... or 09...)."),
    password: z.string().min(4, "Password must be at least 4 characters long."),
    telegramId: z.any().optional(),
    username: z.any().optional(),
    firstName: z.any().optional()
  });

  const verifyOtpSchema = z.object({
    userId: z.string().min(1, "User ID is required."),
    code: z.string().min(4, "OTP code must be at least 4 digits.")
  });

  const loginSchema = z.object({
    phoneNumber: z.string().min(1, "Phone number is required."),
    password: z.string().min(1, "Password is required.")
  });

  const loginTelegramSchema = z.object({
    telegramId: z.any(),
    username: z.any().optional(),
    name: z.any().optional()
  });

  const depositSchema = z.object({
    amount: z.coerce.number().min(10, "Minimum deposit is 10 ETB.").max(10000, "Maximum deposit limit is 10,000 ETB."),
    method: z.enum(['telebirr', 'cbe_birr', 'bank_transfer']),
    referenceNumber: z.string().min(4, "Reference must be at least 4 characters.").max(30, "Reference number cannot exceed 30 characters.").regex(/^[A-Za-z0-9_-]+$/, "Alphanumeric reference only."),
    phoneNumber: z.string().regex(/^(\+2519|\+2517|09|07)\d{8}$/, "Ethiopian phone number required."),
    screenshot: z.string().optional().nullable()
  });

  const autoDepositSchema = z.object({
    pastedSMS: z.string().optional().nullable(),
    screenshot: z.string().optional().nullable()
  });

  const withdrawSchema = z.object({
    amount: z.coerce.number().min(50, "Minimum withdrawal is 50 ETB.").max(5000, "Maximum withdrawal limit is 5000 ETB."),
    method: z.enum(['telebirr', 'cbe_birr', 'bank_transfer']),
    phoneNumber: z.string().regex(/^(\+2519|\+2517|09|07)\d{8}$/, "Ethiopian phone number required.")
  });

  const sanitizeUser = (user: any) => {
    if (!user) return null;
    const clean = { ...user };
    delete clean.password;
    delete clean.otpCode;
    return clean;
  };

  // --- HARDENED AUTHENTICATION & REGISTRATION ENDPOINTS ---
  app.post('/api/auth/register', authLimiter, async (req, res) => {
    const parseResult = registerSchema.safeParse(req.body);
    if (!parseResult.success) {
      return res.status(400).json({ error: parseResult.error.issues[0]?.message || 'Validation error' });
    }

    const { name, phoneNumber, username, telegramId, firstName, password } = parseResult.data;

    // OTP Rate Limiting per Telephone Number
    const now = Date.now();
    const lastRequest = lastOtpRequest.get(phoneNumber);
    if (lastRequest && (now - lastRequest < 60 * 1000)) {
      const remaining = Math.ceil((60 * 1000 - (now - lastRequest)) / 1000);
      return res.status(429).json({ error: `Too many OTP requests. Please wait ${remaining} seconds.` });
    }
    lastOtpRequest.set(phoneNumber, now);

    // Prevent duplicate registration on phone number
    const existingPhone = db.getUserByPhoneNumber(phoneNumber);
    if (existingPhone) {
      return res.status(400).json({ error: 'A user with this Ethiopian phone number already exists.' });
    }

    // If telegram ID is linked, prevent duplicate
    const stringTgId = telegramId ? String(telegramId) : '';
    if (stringTgId) {
      const existingTG = db.getUserByTelegramId(stringTgId);
      if (existingTG) {
        return res.status(400).json({ error: 'This Telegram account is already linked to another phone number.' });
      }
    }

    // Hash the password securely with 12 bcrypt salt rounds
    const hashedPassword = bcrypt.hashSync(password, 12);

    // Create user with unverified status - requiring dynamic secure OTP
    const id = 'user-' + crypto.randomBytes(4).toString('hex');
    const welcomeBalance = 10.0; // 10 birr welcoming bonus for instant gameplay!
    const generatedOtp = Math.floor(1000 + Math.random() * 9000).toString();
    const otpExpiresAt = Date.now() + 5 * 60 * 1000; // 5 minutes expiration
    
    const newUser = db.saveUser({
      id,
      name,
      phoneNumber,
      telegramId: stringTgId,
      username: username ? String(username) : '',
      firstName: firstName ? String(firstName) : '',
      balance: welcomeBalance,
      role: 'user',
      status: 'active',
      otpVerified: false,
      password: hashedPassword,
      createdAt: new Date().toISOString()
    });

    // Save newly generated dynamic OTP code and expiry to user object
    (newUser as any).otpCode = generatedOtp;
    (newUser as any).otpExpiresAt = otpExpiresAt;
    db.saveUser(newUser);

    // Use secure sendSms helper
    sendSms(phoneNumber, `Welcome to Raya Bingo! Your verification code is: ${generatedOtp}. It expires in 5 minutes.`).catch(err => {
      console.error('Failed to dispatch registration OTP SMS:', err);
    });

    db.log('User Registered - Awaiting OTP', id, `Registered user ${name} with phone ${phoneNumber}. Dynamic OTP sent.`);

    res.json({ 
      success: true, 
      message: 'Account registered successfully. Verify the dynamic OTP sent to your phone to continue.', 
      userId: id,
      otpRequired: true,
      user: sanitizeUser(newUser)
    });
  });

  app.post('/api/auth/verify-otp', authLimiter, (req, res) => {
    const parseResult = verifyOtpSchema.safeParse(req.body);
    if (!parseResult.success) {
      return res.status(400).json({ error: parseResult.error.issues[0]?.message || 'Validation error' });
    }

    const { userId, code } = parseResult.data;

    const user = db.getUser(userId);
    if (!user) {
      return res.status(404).json({ error: 'User session not found.' });
    }

    const targetCode = (user as any).otpCode;
    const expiresAt = (user as any).otpExpiresAt;

    if (!targetCode) {
      return res.status(400).json({ error: 'No active OTP verification code found. Please request a new code.' });
    }

    // Verify OTP code expiry
    if (expiresAt && Date.now() > expiresAt) {
      return res.status(400).json({ error: 'Your verification OTP has expired (5-minute ceiling exceeded). Please register again.' });
    }

    if (code !== targetCode) {
      return res.status(400).json({ error: 'Incorrect verification code. Access denied.' });
    }

    user.otpVerified = true;
    // Clear registration OTP secrets after successful verification
    delete (user as any).otpCode;
    delete (user as any).otpExpiresAt;
    
    db.saveUser(user);
    db.log('OTP Verified', user.id, `User ${user.name} successfully verified OTP.`);

    // Generate Token
    const token = generateToken(user.id);

    // Notify user via simulated telegram bot if linked!
    if (user.telegramId) {
      sendTelegramMessage(
          user.telegramId, 
          `📱 *OTP Verification Successful!*\n\nWelcome ${user.name} to Raya Bingo. Your 10 ETB registration welcome bonus has been activated inside your wallet balance. Good luck in the lobbies! 🎰`,
          io
      );
    }

    res.json({
      success: true,
      token,
      user: sanitizeUser(user)
    });
  });

  // Credentials-based login (specifically requested for admin secure portal)
  app.post('/api/auth/login', authLimiter, (req, res) => {
    const parseResult = loginSchema.safeParse(req.body);
    if (!parseResult.success) {
      return res.status(400).json({ error: parseResult.error.issues[0]?.message || 'Validation error' });
    }

    const { phoneNumber, password } = parseResult.data;
    const cleanPhone = phoneNumber.trim();

    // Support lookup with both raw format and standard +251 format
    let user = db.getUserByPhoneNumber(cleanPhone);
    
    // Also try matching +251 format if input started with 09 / 07
    if (!user && cleanPhone.startsWith('0')) {
      const altPhone = '+251' + cleanPhone.slice(1);
      user = db.getUserByPhoneNumber(altPhone);
    } else if (!user && cleanPhone.startsWith('+251')) {
      const altPhone = '0' + cleanPhone.slice(4);
      user = db.getUserByPhoneNumber(altPhone);
    }

    if (!user) {
      return res.status(404).json({ error: 'This phone number is not registered on Raya Bingo.' });
    }

    // Verify Password Securely
    let isMatch = false;
    const plainSecurePassword = password;
    if (user.password && (user.password.startsWith('$2a$') || user.password.startsWith('$2b$'))) {
      isMatch = bcrypt.compareSync(plainSecurePassword, user.password);
    } else {
      // BACKWARDS-COMPATIBILITY: Safe fallback to compare plain string
      isMatch = (user.password === plainSecurePassword);
      if (isMatch) {
        // Transparent, instant upgrade on login of plaintext entries to cryptographically secure standard!
        user.password = bcrypt.hashSync(plainSecurePassword, 12);
        db.saveUser(user);
        db.log('Password Hashing Upgrade', user.id, `Successfully upgraded legacy plain credentials tobcrypt-12 salted hash.`);
      }
    }

    if (!isMatch) {
      return res.status(401).json({ error: 'Incorrect password. Access denied.' });
    }

    const token = generateToken(user.id);
    db.log('User Credentials Login', user.id, `User ${user.name} logged in successfully.`);

    res.json({
      success: true,
      token,
      user: sanitizeUser(user)
    });
  });

  // Seamless Telegram Deep-linking login callback
  app.post('/api/auth/login-telegram', authLimiter, (req, res) => {
    const parseResult = loginTelegramSchema.safeParse(req.body);
    if (!parseResult.success) {
      return res.status(400).json({ error: parseResult.error.issues[0]?.message || 'Validation error' });
    }

    const { telegramId, username, name } = parseResult.data;
    const stringTgId = String(telegramId);

    let user = db.getUserByTelegramId(stringTgId);
    let registeredNow = false;

    if (!user) {
      // Auto-register via Telegram credentials!
      const id = 'user-' + Math.random().toString(36).substr(2, 9);
      user = {
        id,
        name: name ? String(name) : (username ? String(username) : `TG User #${stringTgId.substr(0,4)}`),
        phoneNumber: '', // Prompt to add phone number in profile
        telegramId: stringTgId,
        username: username ? String(username) : '',
        firstName: name ? String(name) : '',
        balance: 10.0, // Welcoming bonus
        role: 'user',
        status: 'active',
        otpVerified: true, // Auto verified if logging in through authentic TG Bot API key handoff
        createdAt: new Date().toISOString()
      };
      db.saveUser(user);
      db.log('Telegram User Auth Auto-Created', id, `Registered user ${user.name} via Telegram deep-link`);
      registeredNow = true;

      // Welcome Telegram bot push notification
      sendTelegramMessage(
        stringTgId,
        `🚀 *Welcome back to Raya Bingo!* \n\nWe logged you in instantly via your Telegram handle. Since you are new, we credited a *10 ETB Game Balance* inside your account! Let's hit the rooms!`,
        io
      );
    }

    const token = generateToken(user.id);
    res.json({
      success: true,
      token,
      user: sanitizeUser(user),
      registeredNow
    });
  });

  app.get('/api/auth/me', authenticateToken, (req: any, res) => {
    res.json({ user: sanitizeUser(req.user) });
  });

  // --- SIMULATED TELEGRAM PORTAL API PATHWAYS ---
  let cachedBotUsername = 'Eti_Raya_Bingo_bot';

  app.get('/api/telegram/bot-info', async (req, res) => {
    try {
      const token = (process.env.TELEGRAM_BOT_TOKEN || '8974458592:AAEaudEb_ze_8vnPnStAAhpjp4JwUQheGcw').trim();
      if (token && token.includes(':')) {
        const response = await fetch(`https://api.telegram.org/bot${token}/getMe`);
        if (response.ok) {
          const data = await response.json();
          if (data.ok && data.result && data.result.username) {
            cachedBotUsername = data.result.username;
          }
        }
      }
    } catch (err) {
      console.error('Error fetching bot info from Telegram:', err);
    }
    res.json({ username: cachedBotUsername });
  });

  app.get('/api/telegram/history/:telegramId', (req, res) => {
    const { telegramId } = req.params;
    res.json(getTelegramHistory(telegramId));
  });

  app.post('/api/telegram/message', async (req, res) => {
    const { telegramId, username, text } = req.body;
    if (!telegramId) return res.status(400).json({ error: 'telegramId is required' });
    const reply = await handleUserTelegramCommand(telegramId, username || 'TG Guest', text || '', io);
    res.json({ success: true, reply, history: getTelegramHistory(telegramId) });
  });

  app.post('/api/telegram/photo', async (req, res) => {
    const { telegramId, username, image, caption } = req.body;
    if (!telegramId) return res.status(400).json({ error: 'telegramId is required' });
    if (!image) return res.status(400).json({ error: 'image is required' });
    const reply = await handleUserTelegramPhoto(telegramId, username || 'TG Guest', image, caption || '', io);
    res.json({ success: true, reply, history: getTelegramHistory(telegramId) });
  });

  app.post('/api/telegram/share-contact', (req, res) => {
    const { telegramId, username, phoneNumber, name } = req.body;

    if (!telegramId || !phoneNumber) {
      return res.status(400).json({ error: 'telegramId and phoneNumber are required.' });
    }

    const cleanedPhone = phoneNumber.trim();
    let user = db.getUserByPhoneNumber(cleanedPhone);

    if (user) {
      // Existing user: link telegram details
      user.telegramId = telegramId;
      if (username) {
        user.username = username.replace('@', '');
      }
      db.saveUser(user);
      db.log('Telegram Linked via Bot contact share', user.id, `Linked Telegram ID ${telegramId} to phone ${cleanedPhone}`);
      
      const token = generateToken(user.id);
      
      sendTelegramMessage(
        telegramId,
        `🔗 *Account Securely Linked!*\n\nWelcome back to Raya Bingo, *${user.name}*! We linked your existing account (Balance: *${user.balance} ETB*) to your Telegram profile.\n\nPress **Play 🎮** to open the lobbies!`,
        io
      );

      return res.json({
        success: true,
        token,
        user,
        registeredNow: false
      });
    } else {
      // Create new user instantly
      const id = 'user-' + Math.random().toString(36).substr(2, 9);
      const generatedUser = {
        id,
        name: name || username || `TG-User-${telegramId.substr(0,4)}`,
        phoneNumber: cleanedPhone,
        telegramId,
        username: username?.replace('@', '') || '',
        firstName: name || username || 'Player',
        balance: 10.0, // Welcome bonus
        role: 'user' as const,
        status: 'active' as const,
        otpVerified: true,
        createdAt: new Date().toISOString()
      };
      
      db.saveUser(generatedUser);
      db.log('Telegram SignUp via contact share', id, `Registered user ${generatedUser.name} via Telegram contact card share`);

      const token = generateToken(id);

      sendTelegramMessage(
        telegramId,
        `🎉 *Registration Successful!*\n\nWelcome to Raya Bingo, *${generatedUser.name}*! We verified your phone number *${cleanedPhone}*.\n\n🎁 A *10.00 ETB Welcome Bonus* has been credited to your playing wallet!`,
        io
      );

      return res.json({
        success: true,
        token,
        user: generatedUser,
        registeredNow: true
      });
    }
  });

  // --- LOBBY ROOMS ---
  app.get('/api/rooms', (req, res) => {
    res.json(db.getRooms());
  });

  // --- BINGO CARDS ---
  app.get('/api/cards/available', (req, res) => {
    const { roomId } = req.query;
    if (!roomId) {
      return res.status(400).json({ error: 'roomId query parameter is required.' });
    }
    // Return cards that are not reserved
    const available = db.getCards().filter(c => !c.reservedBy);
    res.json(available);
  });

  app.get('/api/cards/my', authenticateToken, (req: any, res) => {
    const myCards = db.getCards().filter(c => c.reservedBy === req.user.id);
    res.json(myCards);
  });

  app.get('/api/cards/:id', (req, res) => {
    const card = db.getCard(parseInt(req.params.id));
    if (!card) {
      return res.status(404).json({ error: 'Card not found' });
    }
    res.json(card);
  });

  // --- CHAPA REAL INTEGRATED PAYMENT CHANNELS ---
  app.post('/api/payments/chapa/initialize', authenticateToken, async (req: any, res) => {
    const { amount, phoneNumber } = req.body;
    if (!amount || amount <= 0) {
      return res.status(400).json({ error: 'Please specify a positive amount to deposit.' });
    }

    const txId = 'tx-chapa-' + Math.random().toString(36).substr(2, 9);
    const user = req.user;

    const baseAppUrl = process.env.APP_URL || `http://localhost:3000`;

    // Save pending ledger transaction trace
    const newTx = {
      id: txId,
      userId: user.id,
      userName: user.name,
      amount: Number(amount),
      type: 'deposit' as const,
      status: 'pending' as const,
      method: 'telebirr' as const,
      referenceNumber: 'WAIT-' + Math.random().toString(36).substr(2, 6).toUpperCase(),
      phoneNumber: phoneNumber || user.phoneNumber || '0940889473',
      createdAt: new Date().toISOString()
    };
    db.addTransaction(newTx);

    // If Chapa secret keys are present, initialize authentic external transaction
    if (process.env.CHAPA_SECRET_KEY && process.env.CHAPA_SECRET_KEY !== 'MY_CHAPA_KEY') {
      try {
        const response = await fetch('https://api.chapa.co/v1/transaction/initialize', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${process.env.CHAPA_SECRET_KEY}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            amount: Number(amount),
            currency: 'ETB',
            email: `${user.id}@rayabingo.com`,
            first_name: user.name || 'Bingo',
            last_name: 'Player',
            phone_number: phoneNumber || user.phoneNumber || '0940889473',
            tx_ref: txId,
            callback_url: `${baseAppUrl}/api/payments/chapa/callback`,
            return_url: `${baseAppUrl}/?payment_success=true&tx_id=${txId}`,
            customization: {
              title: "Raya Bingo Wallet Deposit",
              description: `Onboarding credit entry of ${amount} ETB`
            }
          })
        });

        const chapaData = await response.json();
        if (response.ok && chapaData.status === 'success') {
          return res.json({ 
            success: true, 
            checkoutUrl: chapaData.data.checkout_url, 
            txId, 
            isReal: true 
          });
        } else {
          console.warn("Chapa rejected initialization payload, reverting back to secured sandbox fallback:", chapaData);
        }
      } catch (err: any) {
        console.error("Failed to connect with physical Chapa gateway APIs, falling back:", err.message);
      }
    }

    // High security sandbox visualization portal
    const sandboxUrl = `/api/payments/chapa/sandbox-checkout?tx_ref=${txId}&amount=${amount}&name=${encodeURIComponent(user.name)}`;
    return res.json({ 
      success: true, 
      checkoutUrl: sandboxUrl, 
      txId, 
      isReal: false 
    });
  });

  app.get('/api/payments/chapa/sandbox-checkout', (req, res) => {
    const { tx_ref, amount, name } = req.query;
    
    res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Chapa Partner Gateway • Secure Pay</title>
      <script src="https://cdn.tailwindcss.com"></script>
      <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@700&display=swap" rel="stylesheet">
      <style>
        body { font-family: 'Inter', sans-serif; }
      </style>
    </head>
    <body class="bg-slate-950 text-slate-100 min-h-screen flex items-center justify-center p-4">
      <div class="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(16,185,129,0.03),transparent_40%)]" />
      <div class="absolute inset-0 bg-[radial-gradient(circle_at_70%_80%,rgba(59,130,246,0.03),transparent_40%)]" />
      
      <div class="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl p-6 relative overflow-hidden">
        <!-- Chapa design header banner -->
        <div class="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-emerald-500 via-yellow-400 to-blue-500" />
        
        <!-- Brand identity -->
        <div class="flex justify-between items-center mb-6">
          <div class="flex items-center gap-2">
            <span class="font-black text-lg bg-gradient-to-r from-emerald-400 via-emerald-500 to-blue-400 bg-clip-text text-transparent w-fit block italic">CHAPAPay</span>
            <span class="text-[9px] bg-slate-800 text-slate-400 border border-slate-700/60 px-1.5 py-0.5 rounded-full uppercase tracking-wider font-semibold">Sandbox Portal</span>
          </div>
          <span class="text-xs text-slate-500 font-mono" id="sec-timer">Expires: 05:00</span>
        </div>
        
        <div class="mb-5 p-4 bg-slate-950/60 border border-slate-800/85 rounded-2xl relative overflow-hidden">
          <div class="absolute top-0 right-0 h-16 w-16 bg-blue-500/5 rounded-full blur-xl" />
          <div class="text-[10px] uppercase tracking-wider text-slate-500 font-semibold mb-1">Raya Bingo Payment Request</div>
          <div class="flex items-baseline justify-between mb-2">
            <h1 class="text-3xl font-extrabold text-yellow-400 tracking-tight font-mono">${amount} <span class="text-xs text-slate-300">ETB</span></h1>
            <span class="text-[10px] font-mono text-slate-500 bg-slate-900 border border-slate-800 px-1.5 py-0.5 rounded">Ref: ${tx_ref}</span>
          </div>
          <div class="text-xs text-slate-400 max-w-[280px] overflow-hidden text-ellipsis whitespace-nowrap">Merchant Customer: <span class="text-white font-medium">${name || 'Bingo Player'}</span></div>
        </div>
        
        <!-- Channels tabs -->
        <div class="mb-4">
          <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-2">Select Ethiopian Payment Service</label>
          <div class="grid grid-cols-1 gap-2.5">
            <button id="tg-telebirr" class="p-3 bg-emerald-950/40 border border-emerald-500/50 rounded-2xl flex flex-col items-center gap-1 hover:bg-emerald-950/60 transition-colors cursor-pointer group w-full">
              <span class="text-base">📱</span>
              <span class="text-xs font-bold text-center text-white transition-colors">Telebirr Wallet</span>
            </button>
          </div>
        </div>

        <div class="p-4 bg-slate-950/40 border border-slate-850 rounded-2xl space-y-3 mb-6">
          <div class="flex justify-between items-center">
            <span class="text-xs text-slate-400 flex items-center gap-1.5">
              <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span>Secure Layer Status</span>
            </span>
            <span class="text-[9px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded font-bold uppercase tracking-wider">SECURE SHIELD v2</span>
          </div>
          <p class="text-[10px] text-slate-500 leading-relaxed font-medium">By authorizing this sandbox checkout payment request, the gateway will execute a cryptographically signed callback webhook payload to the merchant servers to automatically credit their balance instantly.</p>
        </div>
        
        <!-- Confirm Actions -->
        <div class="space-y-2">
          <button id="btn-pay" class="w-full py-3 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl cursor-pointer hover:shadow-lg hover:shadow-emerald-500/20 transition-all flex justify-center items-center gap-2">
            <span>✓ Complete Payment Authorization</span>
          </button>
          <button id="btn-cancel" class="w-full py-2.5 bg-slate-950/40 hover:bg-slate-950 text-slate-400 hover:text-slate-200 text-xs font-bold rounded-xl cursor-pointer transition-colors text-center border border-slate-800">
            Cancel & Return
          </button>
        </div>
      </div>
      
      <script>
        // Channel selection highlights
        let selectedMethod = 'telebirr';

        // 5 Minutes countdown timers
        let secs = 300;
        const timerText = document.getElementById('sec-timer');
        const interval = setInterval(() => {
          secs--;
          if (secs <= 0) {
            clearInterval(interval);
            alert('Payment code expired, please request again.');
            window.location.href = '/';
          } else {
            const m = Math.floor(secs / 60).toString().padStart(2, '0');
            const s = (secs % 60).toString().padStart(2, '0');
            timerText.innerText = 'Expires: ' + m + ':' + s;
          }
        }, 1000);

        // Submit action
        document.getElementById('btn-pay').addEventListener('click', async () => {
          document.getElementById('btn-pay').disabled = true;
          document.getElementById('btn-pay').innerText = 'SECURELY DISPATCHING WEBHOOK CALLBACK...';
          
          try {
            // Send direct secure Callback verification request matching official webhook payload
            const callbackRes = await fetch('/api/payments/chapa/callback', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                event: 'charge.success',
                amount: Number('${amount}'),
                currency: 'ETB',
                tx_ref: '${tx_ref}',
                status: 'success',
                method: selectedMethod,
                reference: 'CHAPA-REF-MOCK-' + Math.random().toString(36).substr(2, 8).toUpperCase()
              })
            });
            
            const callbackData = await callbackRes.json();
            if (callbackRes.ok && callbackData.success) {
              alert('🎉 Sandbox Payment Authorized Successfully! Directing you back to Raya Bingo.');
              window.location.href = '/?payment_success=true&tx_id=${tx_ref}';
            } else {
              alert('Error verifying sandbox webhook: ' + (callbackData.error || 'Server error'));
              document.getElementById('btn-pay').disabled = false;
              document.getElementById('btn-pay').innerText = '✓ Complete Payment Authorization';
            }
          } catch(e) {
            alert('Failed to connect with merchant webhook: ' + e.message);
            document.getElementById('btn-pay').disabled = false;
            document.getElementById('btn-pay').innerText = '✓ Complete Payment Authorization';
          }
        });

        document.getElementById('btn-cancel').addEventListener('click', () => {
          window.location.href = '/';
        });
      </script>
    </body>
    </html>
    `);
  });

  app.post('/api/payments/chapa/callback', (req, res) => {
    const { tx_ref, amount, status, reference, method } = req.body;

    if (!tx_ref) {
      return res.status(400).json({ error: 'Missing transaction reference ID' });
    }

    const tx = db.getTransaction(tx_ref);
    if (!tx) {
      return res.status(404).json({ error: 'Transaction reference not found on merchant server.' });
    }

    if (tx.status !== 'pending') {
      return res.json({ success: true, message: 'Transaction is already finalized' });
    }

    if (status === 'success') {
      tx.status = 'completed';
      tx.referenceNumber = reference || 'CHAPA-' + Math.random().toString(36).substr(2, 6).toUpperCase();
      if (method) {
        tx.method = method;
      }

      // Update real user credit balance
      const user = db.updateUserBalance(tx.userId, tx.amount);
      db.saveCollection('transactions.json', db.getTransactions());

      db.log('Deposit Completed via Chapa Gateway', tx.userId, `Chapa verified deposit of ${tx.amount} ETB successfully.`);

      db.addNotification({
        id: 'notif-dep-chapa-' + Math.random().toString(36).substr(2, 9),
        userId: tx.userId,
        message: `🎉 GATEWAY DEPOSIT INSTANTLY CREDITED! Real-time check finalized. Credited +${tx.amount} ETB via ${tx.method.toUpperCase()} gateway.`,
        read: false,
        type: 'payment',
        createdAt: new Date().toISOString()
      });

      // Send websocket updates
      io.to(tx.userId).emit('wallet:update', { userId: tx.userId, balance: user?.balance || 0 });
      // General refresh broadcasts
      io.emit('admin:refresh_financials');

      if (user && user.telegramId) {
        sendTelegramMessage(
          user.telegramId,
          `💳 *REAL-TIME GATEWAY DEPOSIT APPROVED!*\n\nOur payment gateway successfully authorized your top-up of *${tx.amount} ETB* via *${tx.method.toUpperCase()}*. \n\n*Reference:* ${tx.referenceNumber}\n*New Balance:* ${user.balance} ETB.\n\nGood luck! 🎰`,
          io
        );
      }

      return res.json({ success: true, message: 'Transaction credited successfully.' });
    } else {
      tx.status = 'rejected';
      db.saveCollection('transactions.json', db.getTransactions());
      return res.json({ success: false, message: 'Payment failure received.' });
    }
  });

  // --- PAYMENTS & WALLET TRANSACTIONS ---
  app.post('/api/payments/deposit', authenticateToken, (req: any, res) => {
    const parseResult = depositSchema.safeParse(req.body);
    if (!parseResult.success) {
      return res.status(400).json({ error: parseResult.error.issues[0]?.message || 'Validation error' });
    }

    const { amount, method, referenceNumber, screenshot, phoneNumber } = parseResult.data;
    const normRef = referenceNumber.trim().toUpperCase();

    // Prevent concurrent duplicate submission clicks using the activeVerifications lock
    if (activeVerifications.has(normRef)) {
      return res.status(409).json({ error: 'This reference number is currently being verified. Please wait a moment.' });
    }
    activeVerifications.add(normRef);

    try {
      // Server-side duplicate check
      const allTransactions = db.getTransactions();
      const duplicateRefs = allTransactions.some(
        t => t.referenceNumber && t.referenceNumber.trim().toUpperCase() === normRef
      );
      if (duplicateRefs) {
        return res.status(400).json({ error: `This reference code (${referenceNumber}) has already been submitted or completed.` });
      }

      // Capture standard transaction in 'pending' status
      const newTx = {
        id: 'tx-dep-' + crypto.randomBytes(4).toString('hex'),
        userId: req.user.id,
        userName: req.user.name,
        amount: Number(amount),
        type: 'deposit' as const,
        status: 'pending' as const,
        method,
        referenceNumber: normRef,
        phoneNumber,
        screenshot: screenshot || '',
        createdAt: new Date().toISOString()
      };

      db.addTransaction(newTx);
      db.log('Deposit requested', req.user.id, `User requested deposit of ${amount} ETB via ${method.toUpperCase()}. Ref: ${normRef}`);

      // Push realtime alert to admins
      io.emit('admin:notif', {
        type: 'deposit',
        message: `🔔 NEW Deposit Request for ${amount} ETB from ${req.user.name} (${method.toUpperCase()}).`,
        tx: newTx
      });

      // Run background AI auditor to generate helpful recommendation note
      triggerAIRecommendationOnly(newTx.id, io);

      return res.json({ 
        success: true, 
        txn: newTx, 
        message: 'Deposit request submitted successfully. Awaiting manual admin review and approval.' 
      });
    } finally {
      activeVerifications.delete(normRef);
    }
  });

  // --- AUTOMATED DEPOSIT APPROVAL VIA COPY PASTE OR SCREENSHOT ---
  app.post('/api/payments/auto-deposit', authenticateToken, async (req: any, res) => {
    const parseResult = autoDepositSchema.safeParse(req.body);
    if (!parseResult.success) {
      return res.status(400).json({ error: parseResult.error.issues[0]?.message || 'Validation error' });
    }

    const { pastedSMS, screenshot } = parseResult.data;

    if (!pastedSMS && !screenshot) {
      return res.status(400).json({ error: 'Please provide either a pasted Telebirr message or a screenshot receipt.' });
    }

    try {
      // Extract details using our Telebirr verifier (AI or regex fallback)
      const audit = await parseAndVerifyTelebirrReceipt(pastedSMS || '', screenshot || null);
      
      if (!audit.verified || !audit.referenceNumber || audit.amount <= 0) {
        return res.status(400).json({ error: audit.explanation || 'Verification failed. Please double check that the screenshot or message represents a valid, unique Telebirr deposit.' });
      }

      // Enforce server-side amount limits (10 - 10,000 ETB)
      if (audit.amount < 10 || audit.amount > 10000) {
        return res.status(400).json({ error: `Parsed deposit amount ( ${audit.amount} ETB ) is outside permissible bounds (10 - 10,000 ETB).` });
      }

      const normRef = audit.referenceNumber.trim().toUpperCase();

      // Lock reference number to prevent rapid concurrent submission spikes
      if (activeVerifications.has(normRef)) {
        return res.status(409).json({ error: 'This reference is currently being verified. Please wait.' });
      }
      activeVerifications.add(normRef);

      try {
        // Enforce duplicate reference checks
        const allTransactions = db.getTransactions();
        const duplicateRefs = allTransactions.some(
          t => t.referenceNumber && t.referenceNumber.trim().toUpperCase() === normRef
        );
        if (duplicateRefs) {
          return res.status(400).json({ error: `Duplicate reference ID: ${audit.referenceNumber} has already been submitted.` });
        }

        // Create transaction directly in 'completed' status to auto-verify and credit deposit!
        const txId = 'tx-dep-' + crypto.randomBytes(4).toString('hex');
        const verifiedTx = {
          id: txId,
          userId: req.user.id,
          userName: req.user.name,
          amount: audit.amount,
          type: 'deposit' as const,
          status: 'completed' as const, // APPROVED!
          method: 'telebirr' as const,
          referenceNumber: normRef,
          phoneNumber: audit.senderPhone || req.user.phoneNumber || '0940889473',
          screenshot: screenshot || '',
          createdAt: new Date().toISOString()
        };

        db.addTransaction(verifiedTx);
        db.updateUserBalance(req.user.id, audit.amount);
        db.log('Auto-Deposit Approved', req.user.id, `Automatically verified & approved Telebirr deposit via Web App of ${audit.amount} ETB. Ref: ${normRef}`);

        db.addNotification({
          id: 'notif-auto-dep-' + crypto.randomBytes(4).toString('hex'),
          userId: req.user.id,
          message: `🎉 Telebirr deposit of ${audit.amount} ETB verified & approved automatically! Ref: ${normRef}`,
          read: false,
          type: 'payment',
          createdAt: new Date().toISOString()
        });

        // Push alert to admins and clients
        io.emit('wallet:update', { userId: req.user.id, balance: db.getUser(req.user.id)?.balance || 0 });
        io.emit('admin:refresh_financials');
        io.emit('admin:notif', {
          type: 'deposit',
          message: `✅ Telebirr auto-deposit approved: ${audit.amount} ETB by ${req.user.name}!`,
          tx: verifiedTx
        });

        // Automatically show the balance on their Telegram Bot profile if the account is linked!
        const linkedUser = db.getUser(req.user.id);
        if (linkedUser && linkedUser.telegramId) {
          sendTelegramMessage(
            linkedUser.telegramId,
            `🎉 *TELEBIRR PAYMENT AUTO-APPROVED!*\n\nYour deposit of *${audit.amount} ETB* has been processed and credited to your wallet via the web app.\n\n👤 *Account:* ${linkedUser.name}\n🎰 *New Wallet Balance:* *${linkedUser.balance} ETB*\n\nPress **Play 🎮** to enter active bingo rooms!`,
            io
          );
        }

        return res.json({
          success: true,
          message: `🎉 Success! Your payment of ${audit.amount} ETB has been automatically verified and credited to your playing wallet.`,
          amount: audit.amount,
          referenceNumber: normRef
        });
      } finally {
        activeVerifications.delete(normRef);
      }
    } catch (e: any) {
      console.error('Error during automatic deposit processing:', e);
      return res.status(500).json({ error: e.message || 'Server error during automatic deposit verification.' });
    }
  });

  app.post('/api/payments/withdraw', authenticateToken, (req: any, res) => {
    const parseResult = withdrawSchema.safeParse(req.body);
    if (!parseResult.success) {
      return res.status(400).json({ error: parseResult.error.issues[0]?.message || 'Validation error' });
    }

    const { amount, method, phoneNumber } = parseResult.data;
    const amountNum = Number(amount);

    if (req.user.balance < amountNum) {
      return res.status(400).json({ error: `Insufficient funds. Your current balance is ${req.user.balance} ETB.` });
    }

    // Deduct the full amount instantly as pre-hold
    db.updateUserBalance(req.user.id, -amountNum);

    // withdrawal fee (5%)
    const withdrawalFee = Number((amountNum * 0.05).toFixed(2));
    const netPayout = Number((amountNum - withdrawalFee).toFixed(2));

    const newTx = {
      id: 'tx-with-' + crypto.randomBytes(4).toString('hex'),
      userId: req.user.id,
      userName: req.user.name,
      amount: amountNum,
      fee: withdrawalFee,
      netPayout: netPayout,
      type: 'withdrawal' as const,
      status: 'pending' as const,
      method,
      referenceNumber: 'WAIT-' + crypto.randomBytes(3).toString('hex').toUpperCase(),
      phoneNumber,
      createdAt: new Date().toISOString()
    };

    db.addTransaction(newTx);
    db.log('Withdrawal requested', req.user.id, `User requested withdrawal of ${amountNum} ETB (Fee: ${withdrawalFee} ETB, Net Payout: ${netPayout} ETB) through ${method.toUpperCase()} to mobile ${phoneNumber}`);

    // Alert admins
    io.emit('admin:notif', {
      type: 'withdrawal',
      message: `🔔 NEW Withdrawal Request: ${amountNum} ETB (Fee: ${withdrawalFee} ETB) by ${req.user.name} via ${method.toUpperCase()}.`,
      tx: newTx
    });

    // Run background AI auditor to generate helpful recommendation note
    triggerAIRecommendationOnly(newTx.id, io);

    res.json({ success: true, txn: newTx, updatedBalance: req.user.balance - amountNum });
  });

  app.get('/api/payments/history', authenticateToken, (req: any, res) => {
    const txs = db.getTransactions().filter(t => t.userId === req.user.id);
    res.json(txs);
  });

  // --- USER NOTIFICATIONS ---
  app.get('/api/notifications', authenticateToken, (req: any, res) => {
    res.json(db.getUserNotifications(req.user.id));
  });

  app.post('/api/notifications/:id/read', authenticateToken, (req: any, res) => {
    const ok = db.markNotifRead(req.params.id);
    res.json({ success: !!ok });
  });

  // --- REVENUE & OVERRIDES API ---

  // ==========================================
  // ADMINISTRATIVE OVERRIDES & BACKOFFICE
  // ==========================================

  // Financial summary query
  app.get('/api/admin/financials', authenticateToken, (req: any, res) => {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Unauthorized backoffice access' });
    }

    const txs = db.getTransactions();
    const deposits = txs.filter(t => t.type === 'deposit' && t.status === 'completed');
    const withdrawals = txs.filter(t => t.type === 'withdrawal' && t.status === 'completed');
    
    const totalDeposits = deposits.reduce((sum, t) => sum + t.amount, 0);
    const totalWithdrawals = withdrawals.reduce((sum, t) => sum + t.amount, 0);
    
    // Commission revenue summing
    const revs = db.getRevenue();
    const totalCommission = revs.reduce((sum, r) => sum + r.commission, 0);

    // Platform balance first rule
    const usersList = db.getUsers();
    const totalUserLiability = usersList.reduce((sum, u) => sum + u.balance, 0);
    const platformLiq = totalDeposits - totalWithdrawals;

    res.json({
      platformBalance: Number((platformLiq - totalUserLiability).toFixed(2)), // net escrow holdings
      commissionRevenue: Number(totalCommission.toFixed(2)),
      depositTotal: Number(totalDeposits.toFixed(2)),
      withdrawalTotal: Number(totalWithdrawals.toFixed(2)),
      profit: Number((totalCommission).toFixed(2)), // earnings directly from clean 25% take
      pendingTransactions: txs.filter(t => t.status === 'pending').length,
      escrowLiquidBalance: Number((platformLiq).toFixed(2)),
      userLiability: Number(totalUserLiability.toFixed(2))
    });
  });

  // List users
  app.get('/api/admin/users', authenticateToken, (req: any, res) => {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Unauthorized backoffice access' });
    }
    res.json(db.getUsers());
  });

  // Edit user balances
  app.post('/api/admin/users/:id/balance', authenticateToken, (req: any, res) => {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Unauthorized backoffice access' });
    }
    const { amount, action } = req.body; // action: 'add' | 'deduct'
    const sign = action === 'deduct' ? -1 : 1;
    const user = db.updateUserBalance(req.params.id, sign * Math.abs(Number(amount)));

    if (!user) return res.status(404).json({ error: 'User not found' });

    db.log('Admin Action balance update', 'admin-1', `Manually ${action}ed ${amount} ETB to user ${user.name}'s wallet. New balance: ${user.balance}`);

    // Notify user via TG
    if (user.telegramId) {
      sendTelegramMessage(
        user.telegramId,
        `💰 *Official Balance Correction:*\n\nAdministrator has updated your account wallet. \n\nAmount Changed: *${sign * Math.abs(Number(amount))} ETB*\nNew Wallet Balance: *${user.balance} ETB*.`,
        io
      );
    }

    res.json({ success: true, user });
  });

  // Modify user accounts status
  app.post('/api/admin/users/:id/status', authenticateToken, (req: any, res) => {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Unauthorized backoffice access' });
    }
    const { status } = req.body; // 'active' | 'suspended' | 'banned'
    const user = db.getUser(req.params.id);
    if (!user) return res.status(404).json({ error: 'User not found' });
    
    user.status = status;
    db.saveUser(user);

    db.log('Admin Action status change', 'admin-1', `Admin redefined user ${user.name} account standing to: ${status.toUpperCase()}`);

    if (user.telegramId) {
      sendTelegramMessage(
        user.telegramId,
        `⚠️ *Security Advisory:*\n\nYour Raya Bingo account standing status has been updated to: *${status.toUpperCase()}*. If you believe this is in error, please contact support.`,
        io
      );
    }

    res.json({ success: true, user });
  });

  // Fetch complete audit logs
  app.get('/api/admin/audit', authenticateToken, (req: any, res) => {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Unauthorized backoffice access' });
    }
    res.json(db.getAuditLogs());
  });

  // Force restart active games
  app.post('/api/admin/rooms/:id/restart', authenticateToken, (req: any, res) => {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Unauthorized backoffice access' });
    }
    forceRestartGame(req.params.id, io);
    res.json({ success: true, message: 'Bingo Table game successfully restarted.' });
  });

  // AI Auditor to verify and recommend approvals
  app.post('/api/admin/transactions/:id/ai-check', authenticateToken, async (req: any, res) => {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Unauthorized backoffice access' });
    }

    const tx = db.getTransaction(req.params.id);
    if (!tx) {
      return res.status(404).json({ error: 'Transaction search failed' });
    }

    const user = db.getUser(tx.userId);
    const allTransactions = db.getTransactions();

    // Check pre-computable signals
    const duplicateRefs = allTransactions.filter(
      t => t.id !== tx.id && t.referenceNumber && t.referenceNumber.trim() === tx.referenceNumber?.trim() && t.status === 'completed'
    );
    const isDuplicate = duplicateRefs.length > 0;

    const referenceNumber = (tx.referenceNumber || '').trim();

    try {
      const ai = getGeminiClient();
      
      const prompt = `
Please audit the following pending transaction requested in Raya Bingo.

TRANSACTION DETAILS:
- ID: ${tx.id}
- Type: ${tx.type.toUpperCase()} (${tx.type === 'deposit' ? 'User claims to have deposited money' : 'User requests cashout'})
- Player Name: ${tx.userName} (User ID: ${tx.userId})
- Phone Number: ${tx.phoneNumber}
- Payment Method: ${tx.method.toUpperCase()}
- Amount: ${tx.amount} ETB
- Reference Number provided: "${tx.referenceNumber || 'N/A'}"
- Created At: ${tx.createdAt}

USER CONTEXT:
- Saved Wallet Balance: ${user ? user.balance : 0} ETB
- Account Status: ${user ? user.status : 'unknown'}

SYSTEM SIGNALS:
- Duplicate reference check: ${isDuplicate ? "DUPLICATE FOUND! This reference number is already used in other completed transactions. HIGH RISK of fraud." : "Clean (no other completed transaction has this reference code)"}
- Reference length: ${referenceNumber ? `${referenceNumber.length} chars` : "N/A"}
- Reference format analysis: ${tx.method === 'telebirr' ? 'Telebirr codes are usually 10-letter alphanumeric strings.' : 'CBE Reference numbers are typically CBE alphanumeric string hashes.'}

Determine whether the transaction should be APPROVED or REJECTED.
For deposit: Approve only if there is no duplicate reference code and reference is provided. Reject duplicate reference claims or missing references.
For withdrawal: Approve only if the user has a sufficient balance to support the withdrawal (requested: ${tx.amount} ETB, saved balance: ${user ? user.balance : 0} ETB). Reject if the user's wallet doesn't have enough funds.

Output a highly professional audit opinion.
`;

      const gRes = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              recommendation: {
                type: Type.STRING,
                description: "Must be 'APPROVE' or 'REJECT'"
              },
              confidence: {
                type: Type.INTEGER,
                description: "Confidence rating as a percentage from 0 to 100"
              },
              explanation: {
                type: Type.STRING,
                description: "A professional, concise bulleted reason explaining the audit opinion in English."
              }
            },
            required: ["recommendation", "confidence", "explanation"]
          }
        }
      });

      const auditResult = JSON.parse(gRes.text || '{}');
      res.json({
        success: true,
        recommendation: auditResult.recommendation || 'REJECT',
        confidence: auditResult.confidence || 50,
        explanation: auditResult.explanation || 'Failed to parse AI structure',
        preComputed: {
          isDuplicate,
          referenceLength: referenceNumber.length
        }
      });

    } catch (e: any) {
      console.warn('Gemini AI billing auditor offline fallback:', e.message || e);
      // Fail back to basic rule-based engine if Gemini is rate limited or offline
      let ruleRecommendation = 'REJECT';
      let ruleExplanation = '';

      if (tx.type === 'deposit') {
        if (isDuplicate) {
          ruleRecommendation = 'REJECT';
          ruleExplanation = 'REJECTED (Auto-Blocked): Duplicate reference number detected in transactions database!';
        } else if (!referenceNumber) {
          ruleRecommendation = 'REJECT';
          ruleExplanation = 'REJECTED: Reference number is blank or missing.';
        } else if (referenceNumber.length < 5) {
          ruleRecommendation = 'REJECT';
          ruleExplanation = 'REJECTED: Reference number is too short or invalid.';
        } else {
          ruleRecommendation = 'APPROVE';
          ruleExplanation = 'APPROVED: Unique reference structure matches.';
        }
      } else if (tx.type === 'withdrawal') {
        if (!user || user.balance < tx.amount) {
          ruleRecommendation = 'REJECT';
          ruleExplanation = 'REJECTED: Insufficient user balance to execute withdrawal.';
        } else {
          ruleRecommendation = 'APPROVE';
          ruleExplanation = 'APPROVED: Sufficient user balance available.';
        }
      }

      res.json({
        success: true,
        recommendation: ruleRecommendation,
        confidence: 95,
        explanation: `Rule-Engine Safety Fallback: ${ruleExplanation}`,
        preComputed: {
          isDuplicate,
          referenceLength: referenceNumber.length
        }
      });
    }
  });

  // Approve payments (deposits or withdrawals)
  app.post('/api/admin/transactions/:id/status', authenticateToken, (req: any, res) => {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Unauthorized backoffice access' });
    }
    const { status } = req.body; // 'completed' (for withdrawal) | 'completed/approved' (for deposit) | 'rejected'
    const tx = db.getTransaction(req.params.id);

    if (!tx) return res.status(404).json({ error: 'Transaction search failed' });

    if (tx.status !== 'pending') {
      return res.status(400).json({ error: 'Transaction is already closed.' });
    }

    // Process approval
    if (tx.type === 'deposit') {
      if (status === 'completed' || status === 'approved') {
        tx.status = 'completed';
        // Credit the deposit amount to user's wallet
        const updatedUser = db.updateUserBalance(tx.userId, tx.amount);
        db.saveCollection('transactions.json', db.getTransactions());
        
        db.log('Deposit Approved', 'admin-1', `Approved CBE/Telebirr deposit request #${tx.id} of ${tx.amount} ETB for user ${tx.userName}`);

        if (updatedUser && updatedUser.telegramId) {
          sendTelegramMessage(
            updatedUser.telegramId,
            `✅ *DEPOSIT APPROVED!*\n\nYour top up request for *${tx.amount} ETB* via *${tx.method.toUpperCase()}* has been verified and processed. \n\nWallet Updated: *${updatedUser.balance} ETB*.\nThank you for choosing Raya Bingo! 🎰`,
            io
          );
        }
      } else {
        tx.status = 'rejected';
        db.saveCollection('transactions.json', db.getTransactions());
        db.log('Deposit Rejected', 'admin-1', `REJECTED deposit request #${tx.id} of ${tx.amount} ETB by ${tx.userName}`);
        
        const tgtUser = db.getUser(tx.userId);
        if (tgtUser && tgtUser.telegramId) {
          sendTelegramMessage(
            tgtUser.telegramId,
            `❌ *DEPOSIT REJECTED!*\n\nOur billing admins could not verify your deposit of *${tx.amount} ETB* via *${tx.method.toUpperCase()}*. Reference: ${tx.referenceNumber}.\n\nPlease cross-check and resubmit a correct reference id.`,
            io
          );
        }
      }
    } else if (tx.type === 'withdrawal') {
      if (status === 'completed' || status === 'approved') {
        tx.status = 'completed';
        db.saveCollection('transactions.json', db.getTransactions());
        db.log('Withdrawal Completed', 'admin-1', `Admin completed withdrawal payout #${tx.id} of ${tx.amount} ETB to user ${tx.userName}'s mobile cash ${tx.phoneNumber}`);

        const tgtUser = db.getUser(tx.userId);
        if (tgtUser && tgtUser.telegramId) {
          sendTelegramMessage(
            tgtUser.telegramId,
            `💸 *WITHDRAWAL COMPLETED!*\n\nGood news! Your cashout request of *${tx.amount} ETB* has been completed. The transfer was successfully credited to your ${tx.method.toUpperCase()} phone *${tx.phoneNumber}*.\n\nPlay more, win more! 🎆`,
            io
          );
        }
      } else {
        tx.status = 'rejected';
        // Refund the pre-held balance to the user
        const updatedUser = db.updateUserBalance(tx.userId, tx.amount);
        db.saveCollection('transactions.json', db.getTransactions());
        db.log('Withdrawal Rejected', 'admin-1', `Admin rejected and refunded withdrawal payout #${tx.id} of ${tx.amount} ETB to user ${tx.userName}`);

        if (updatedUser && updatedUser.telegramId) {
          sendTelegramMessage(
            updatedUser.telegramId,
            `⚠️ *WITHDRAWAL REJECTED!*\n\nYour cashout request of *${tx.amount} ETB* was declined by our auditing team. We refunded the entire sum back to your wallet count.\n\nReason: Details do not match payout profile or verification issue.`,
            io
          );
        }
      }
    }

    // Refresh general admin view
    io.emit('admin:refresh_financials');
    res.json({ success: true, txn: tx });
  });

  // ==========================================
  // SOCKET.IO REAL-TIME multiplayer HANDLING
  // ==========================================

  io.on('connection', (socket) => {
    let currentRoomId: string | null = null;
    let authUser: any = null;

    console.log(`Socket client connected: ${socket.id}`);

    // Join room channel mapping
    socket.on('room:join', ({ roomId, token, cardIds }) => {
      try {
        if (!token) return socket.emit('error', 'Token parameter is required.');
        
        let userId: string;
        try {
          const decoded: any = jwt.verify(token, JWT_SECRET);
          userId = decoded.userId;
        } catch (jwtErr) {
          // Fallback to base64 JSON parsing just in case some static legacy tokens exist
          const payloadString = Buffer.from(token, 'base64').toString('utf-8');
          const payload = JSON.parse(payloadString);
          userId = payload.userId;
        }

        let user = db.getUser(userId);
        
        if (!user) return socket.emit('error', 'Invalid user identity.');
        if (user.status !== 'active') return socket.emit('error', `Account is currently ${user.status}.`);

        authUser = user;
        currentRoomId = roomId;

        socket.join(roomId);
        console.log(`User ${user.name} (${user.id}) joined Socket Channel [${roomId}]`);

        // Trigger real join in engine with multiple cards if supplied
        if (Array.isArray(cardIds) && cardIds.length > 0) {
          user = db.getUser(userId); // fetch latest balance
          if (user) {
            const result = joinRoom(roomId, user, cardIds, io);
            if (!result.success) {
              socket.emit('error', result.message);
            } else {
              socket.emit('room:joined_with_cards', { cardIds });
              // Refresh wallets
              io.emit('admin:refresh_financials');
            }
          }
        }
      } catch (err) {
        socket.emit('error', 'Socket authorization failed');
      }
    });

    socket.on('lobby:join', () => {
      socket.join('lobby');
      socket.emit('lobby:rooms', db.getRooms());
    });

    // Chat room messaging
    socket.on('game:chat', (messageText) => {
      if (!currentRoomId || !authUser) return;
      
      const newMsg = db.addChatMessage({
        id: 'chat-' + Math.random().toString(36).substr(2, 9),
        userId: authUser.id,
        userName: authUser.name,
        message: messageText,
        timestamp: new Date().toISOString()
      });

      io.to(currentRoomId).emit('room:chat_msg', newMsg);
    });

    socket.on('room:leave', ({ roomId }) => {
      socket.leave(roomId);
      console.log(`Socket client active disconnect from room channel [${roomId}]`);
    });

    socket.on('disconnect', () => {
      console.log(`Socket client disconnected: ${socket.id}`);
    });
  });

  // ==========================================
  // VITE DEVELOPMENT MIDDLEWARE OR STATIC SERVER
  // ==========================================

  // Extremely robust check to detect if we should serve static assets instead of Vite development server.
  // We check if process.env.NODE_ENV is "production", or we are running inside dist/ directory,
  // or the typescript source file doesn't exist.
  const isProductionMode = 
    process.env.NODE_ENV === 'production' || 
    (typeof __dirname !== 'undefined' && __dirname.includes('dist')) || 
    !fs.existsSync(path.join(process.cwd(), 'server.ts'));

  if (!isProductionMode) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = (typeof __dirname !== 'undefined' && __dirname.includes('dist')) ? __dirname : path.join(process.cwd(), 'dist');
    console.log(`[PRODUCTION STATIC FILES]: Serving static files from path: ${distPath}`);
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // Bind to PORT 3000 as strictly hardcoded
  server.listen(3000, '0.0.0.0', () => {
    console.log('Raya Bingo full-stack backend running perfectly at http://0.0.0.0:3000');
    // Start automated background polling cycle of the real Telegram Bot API
    startTelegramBotPolling(io);
  });
}

startServer();
