/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { 
  User, 
  BingoCard, 
  BingoRoom, 
  Transaction, 
  AppNotification, 
  RevenueRecord, 
  AuditLog, 
  ChatMessage 
} from '../src/types.js';

import { dbConnection } from '../src/db/index.js';
import { 
  users as usersTable,
  rooms as roomsTable,
  wallets as walletsTable,
  games as gamesTable,
  cards as cardsTable,
  transactions as transactionsTable,
  referrals as referralsTable,
  auditLogs as auditLogsTable,
  announcements as announcementsTable,
  gameResults as gameResultsTable
} from '../src/db/schema.js';
import { eq, and, desc, sql } from 'drizzle-orm';

const DATA_DIR = path.join(process.cwd(), 'data');

// Local Fallback Database State in case SQL instance is not provisioned
let users: User[] = [];
let cards: BingoCard[] = [];
let rooms: BingoRoom[] = [];
let transactions: Transaction[] = [];
let notifications: AppNotification[] = [];
let revenueRecords: RevenueRecord[] = [];
let auditLogs: AuditLog[] = [];
let chatMessages: ChatMessage[] = [];

// --- SERIALIZED WRITE QUEUE TO PREVENT CONCURRENT FILE CORRUPTION ---
class WriteQueue {
  private lastPromise: Promise<any> = Promise.resolve();

  enqueue<T>(action: () => Promise<T> | T): Promise<T> {
    return new Promise<T>((resolve, reject) => {
      this.lastPromise = this.lastPromise
        .then(async () => {
          try {
            const result = await action();
            resolve(result);
          } catch (err) {
            reject(err);
          }
        })
        .catch(() => {}); // Continues the queue chain even if this action fails
    });
  }
}

const writeQueues: Record<string, WriteQueue> = {};

function getWriteQueue(filename: string): WriteQueue {
  if (!writeQueues[filename]) {
    writeQueues[filename] = new WriteQueue();
  }
  return writeQueues[filename];
}

function isBcryptHash(str: string): boolean {
  return typeof str === 'string' && str.startsWith('$2') && str.includes('$');
}

// Helper to ensure data directory and files exist
async function initDB() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }

  // Initializing local arrays
  users = loadCollection('users.json', []);
  transactions = loadCollection('transactions.json', []);
  notifications = loadCollection('notifications.json', []);
  revenueRecords = loadCollection('revenue.json', []);
  auditLogs = loadCollection('audit.json', []);
  chatMessages = loadCollection('chat.json', []);

  // Initialize standard Rooms
  const roomTemplates: BingoRoom[] = [
    { id: 'room-10', name: '10 ETB Economy', entryFee: 10, prizePool: 0, commission: 0, status: 'waiting', activePlayers: 0, maxPlayers: 1000 },
    { id: 'room-20', name: '20 ETB Bronze', entryFee: 20, prizePool: 0, commission: 0, status: 'waiting', activePlayers: 0, maxPlayers: 1000 },
    { id: 'room-50', name: '50 ETB Silver', entryFee: 50, prizePool: 0, commission: 0, status: 'waiting', activePlayers: 0, maxPlayers: 1000 },
    { id: 'room-100', name: '100 ETB Gold', entryFee: 100, prizePool: 0, commission: 0, status: 'waiting', activePlayers: 0, maxPlayers: 1000 },
    { id: 'room-200', name: '200 ETB Platinum', entryFee: 200, prizePool: 0, commission: 0, status: 'waiting', activePlayers: 0, maxPlayers: 1000 },
    { id: 'room-500', name: '500 ETB VIP Raya', entryFee: 500, prizePool: 0, commission: 0, status: 'waiting', activePlayers: 0, maxPlayers: 1000 },
  ];
  
  const savedRooms = loadCollection('rooms.json', null);
  if (savedRooms && savedRooms.length > 0) {
    rooms = savedRooms;
    // Always sync status on startup
    rooms.forEach(r => {
      r.status = 'waiting';
      r.activePlayers = 0;
      r.prizePool = 0;
      r.commission = 0;
    });
  } else {
    rooms = roomTemplates;
    saveCollection('rooms.json', rooms);
  }

  // Generate 1000 Unique Bingo Cards if they don't exist
  const savedCards = loadCollection('cards.json', null);
  if (savedCards && savedCards.length === 1000) {
    cards = savedCards;
  } else {
    console.log('Generating 1,000 unique Bingo Cards for Raya Bingo...');
    cards = generateUniqueCards();
    console.log('Successfully pre-generated 1,000 unique cards.');
  }

  // Always reset card assignments on startup to stay consistent with room reset state
  cards.forEach(c => {
    c.reservedBy = null;
    c.roomId = null;
  });
  saveCollection('cards.json', cards);

  // Ensure high-level admin user exists without hardcoded plaintext credentials
  const adminPhone = process.env.ADMIN_PHONE || '0940889473';
  const adminIndex = users.findIndex(u => u.role === 'admin' || u.id === 'admin-1');
  let adminEntity: User;

  if (adminIndex >= 0) {
    // Existing admin: pull in current details, and verify their password format
    const existingAdmin = users[adminIndex];
    existingAdmin.phoneNumber = adminPhone;
    if (existingAdmin.password && !isBcryptHash(existingAdmin.password)) {
      existingAdmin.password = bcrypt.hashSync(existingAdmin.password, 12);
    }
    adminEntity = existingAdmin;
  } else {
    // Generate a secure one-time initial admin password
    const secureRawPassword = crypto.randomBytes(16).toString('hex') + 'A1!';
    
    console.log('\n================================================================');
    console.log('🛡️  SECURITY ALERT: INITIAL ADVANCED ADMIN CONFIGURED (ONE-TIME)');
    console.log(`👤 Name: Daniel`);
    console.log(`📱 Admin Phone Number: ${adminPhone}`);
    console.log(`🔑 PLAINTEXT PASSWORD: ${secureRawPassword}`);
    console.log('⚠️  Store this securely. It will never be printed or saved in plaintext.');
    console.log('================================================================\n');

    adminEntity = {
      id: "admin-1",
      name: "Daniel",
      phoneNumber: adminPhone,
      telegramId: "123456789",
      username: "rayabingoadmin",
      firstName: "Daniel",
      balance: 100000,
      role: 'admin',
      status: 'active',
      otpVerified: true,
      createdAt: new Date().toISOString(),
      password: bcrypt.hashSync(secureRawPassword, 12)
    };
    users.push(adminEntity);
  }

  // Migration: Hash any legacy plaintext user passwords with bcrypt cost factor 12
  let migratedCount = 0;
  users.forEach(u => {
    if (u.password && !isBcryptHash(u.password)) {
      u.password = bcrypt.hashSync(u.password, 12);
      migratedCount++;
    }
  });
  if (migratedCount > 0) {
    console.log(`🔑 [MIGRATION] Hashed ${migratedCount} plaintext passwords in local database.`);
  }

  saveCollection('users.json', users);
  console.log('Raya Bingo Local Database initialized successfully!');

  // --- SQL INSTANCE SYNCHRONIZER WRAPPER (Graceful Bootstrap) ---
  if (dbConnection.isAvailable()) {
    try {
      const sqlDb = dbConnection.db;
      console.log('⚡ [SQL SYNC ROOT] Bootstrap synchronizing fallback data into PostgreSQL database...');

      // 1. Sync Rooms
      for (const r of rooms) {
        await sqlDb.insert(roomsTable).values({
          id: r.id,
          name: r.name,
          entryFee: r.entryFee,
          prizePool: r.prizePool,
          commission: r.commission,
          status: r.status,
          activePlayers: r.activePlayers,
          maxPlayers: r.maxPlayers,
          updatedAt: new Date()
        }).onConflictDoUpdate({
          target: roomsTable.id,
          set: {
            name: r.name,
            entryFee: r.entryFee,
            updatedAt: new Date()
          }
        });
      }

      // 2. Sync Pre-generated 1,000 unique Cards
      const existingCardsCount = await sqlDb.select({ count: sql`count(*)` }).from(cardsTable);
      const rowCount = Number(existingCardsCount[0]?.count || 0);
      if (rowCount < 1000) {
        console.log(`[SQL SYNC ROOT] Pushing 1,000 unique cards to PostgreSQL (current: ${rowCount})...`);
        const batchSize = 100;
        for (let i = 0; i < cards.length; i += batchSize) {
          const batch = cards.slice(i, i + batchSize).map(c => ({
            id: c.id,
            numbers: JSON.stringify(c.numbers),
            reservedBy: null,
            roomId: null
          }));
          await sqlDb.insert(cardsTable).values(batch).onConflictDoNothing();
        }
      }

      // 3. Sync Admin
      await sqlDb.insert(usersTable).values({
        id: adminEntity.id,
        name: adminEntity.name,
        phoneNumber: adminEntity.phoneNumber,
        telegramId: adminEntity.telegramId,
        username: adminEntity.username || null,
        firstName: adminEntity.firstName || null,
        balance: adminEntity.balance,
        role: adminEntity.role,
        status: adminEntity.status,
        otpVerified: adminEntity.otpVerified,
        password: adminEntity.password || '',
        createdAt: adminEntity.createdAt ? new Date(adminEntity.createdAt) : new Date()
      }).onConflictDoUpdate({
        target: usersTable.id,
        set: {
          password: adminEntity.password,
          phoneNumber: adminEntity.phoneNumber,
          role: adminEntity.role
        }
      });

      console.log('🎉 [SQL SYNC ROOT] PostgreSQL synchronization completed cleanly!');
    } catch (err: any) {
      console.error('[SQL SYNC ROOT EXCEPTION] Could not bootstrap data to PostgreSQL:', err.message);
    }
  }
}

function loadCollection<T>(filename: string, defaultValue: T): T {
  const filePath = path.join(DATA_DIR, filename);
  if (fs.existsSync(filePath)) {
    try {
      const content = fs.readFileSync(filePath, 'utf-8');
      return JSON.parse(content) as T;
    } catch (e) {
      console.error(`Error reading ${filename}`, e);
      return defaultValue;
    }
  }
  return defaultValue;
}

function saveCollection<T>(filename: string, content: T) {
  const filePath = path.join(DATA_DIR, filename);
  const jsonContent = JSON.stringify(content, null, 2);
  
  // Enqueue file write in serialized, async queue with atomic temp file swap
  getWriteQueue(filename).enqueue(async () => {
    try {
      const tempPath = filePath + '.tmp';
      await fs.promises.writeFile(tempPath, jsonContent, 'utf-8');
      await fs.promises.rename(tempPath, filePath);
    } catch (e) {
      console.error(`Error saving ${filename} atomically:`, e);
    }
  });
}

function generateUniqueCards(): BingoCard[] {
  const generated: BingoCard[] = [];
  const cardHashes = new Set<string>();

  const getRandomUniqueNumbers = (min: number, max: number, count: number): number[] => {
    const list: number[] = [];
    for (let i = min; i <= max; i++) {
      list.push(i);
    }
    const result: number[] = [];
    for (let i = 0; i < count; i++) {
      const idx = Math.floor(Math.random() * list.length);
      result.push(list.splice(idx, 1)[0]);
    }
    return result.sort((a, b) => a - b);
  };

  let attempts = 0;
  const maxAttempts = 10000;

  while (generated.length < 1000 && attempts < maxAttempts) {
    attempts++;
    const colB = getRandomUniqueNumbers(1, 15, 5);
    const colI = getRandomUniqueNumbers(16, 30, 5);
    const colN = getRandomUniqueNumbers(31, 45, 4);
    const colG = getRandomUniqueNumbers(46, 60, 5);
    const colO = getRandomUniqueNumbers(61, 75, 5);

    const grid: number[][] = [];
    for (let r = 0; r < 5; r++) {
      const row: number[] = [];
      row.push(colB[r]);
      row.push(colI[r]);
      if (r === 2) {
        row.push(0);
      } else {
        row.push(colN[r > 2 ? r - 1 : r]);
      }
      row.push(colG[r]);
      row.push(colO[r]);
      grid.push(row);
    }

    const hash = grid.flat().join(',');
    // Relax uniqueness constraints slightly if we hit close to maxAttempts fallback thresholds to avoid near-infinite loops
    if (!cardHashes.has(hash) || attempts >= maxAttempts - 1100) {
      cardHashes.add(hash);
      generated.push({
        id: generated.length + 1,
        numbers: grid,
        reservedBy: null,
        roomId: null
      });
    }
  }

  // Graceful backup fallback
  while (generated.length < 1000) {
    const template = generated[generated.length % (generated.length || 1)];
    generated.push({
      id: generated.length + 1,
      numbers: JSON.parse(JSON.stringify(template.numbers)),
      reservedBy: null,
      roomId: null
    });
  }

  return generated;
}

initDB();

// Database Export Object
export const db = {
  // --- USERS ---
  getUsers: () => {
    return users;
  },
  
  getUser: (id: string) => {
    return users.find(u => u.id === id);
  },
  
  getUserByTelegramId: (telegramId: string) => {
    return users.find(u => u.telegramId === telegramId);
  },
  
  getUserByPhoneNumber: (phoneNumber: string) => {
    return users.find(u => u.phoneNumber === phoneNumber);
  },
  
  saveUser: (user: User) => {
    const idx = users.findIndex(u => u.id === user.id);
    if (idx >= 0) {
      users[idx] = user;
    } else {
      users.push(user);
    }
    saveCollection('users.json', users);

    // SQL Mirroring Layer (Lazy/Fire-And-Forget background updates)
    if (dbConnection.isAvailable()) {
      const sqlDb = dbConnection.db;
      sqlDb.insert(usersTable).values({
        id: user.id,
        name: user.name,
        phoneNumber: user.phoneNumber,
        telegramId: user.telegramId || null,
        username: user.username || null,
        firstName: user.firstName || null,
        balance: user.balance,
        role: user.role,
        status: user.status as any,
        otpVerified: user.otpVerified,
        password: user.password || '',
        createdAt: new Date(user.createdAt || Date.now()),
        otpCode: (user as any).otpCode || null
      }).onConflictDoUpdate({
        target: usersTable.id,
        set: {
          name: user.name,
          phoneNumber: user.phoneNumber,
          telegramId: user.telegramId || null,
          username: user.username || null,
          firstName: user.firstName || null,
          balance: user.balance,
          role: user.role,
          status: user.status as any,
          otpVerified: user.otpVerified,
          password: user.password || '',
          otpCode: (user as any).otpCode || null
        }
      }).catch((err: any) => console.error('[SQL SAVE USER FAIL]', err.message));
    }
    return user;
  },
  
  updateUserBalance: (userId: string, amount: number) => {
    const user = users.find(u => u.id === userId);
    if (user) {
      user.balance = Number((user.balance + amount).toFixed(2));
      saveCollection('users.json', users);

      // SQL Atomic Multi-User Race Condition Guard
      if (dbConnection.isAvailable()) {
        const sqlDb = dbConnection.db;
        sqlDb.update(usersTable)
          .set({ balance: sql`${usersTable.balance} + ${amount}` })
          .where(eq(usersTable.id, userId))
          .catch((err: any) => console.error('[SQL BALANCE SYNC ACTION FAIL]', err.message));
      }
      return user;
    }
    return null;
  },

  // --- BINGO CARDS ---
  getCards: () => cards,
  
  getCard: (id: number) => cards.find(c => c.id === id),
  
  reserveCard: (cardId: number, userId: string, roomId: string) => {
    const card = cards.find(c => c.id === cardId);
    if (card && !card.reservedBy) {
      card.reservedBy = userId;
      card.roomId = roomId;
      saveCollection('cards.json', cards);

      if (dbConnection.isAvailable() && !userId.startsWith('bot-')) {
        const sqlDb = dbConnection.db;
        sqlDb.update(cardsTable)
          .set({ reservedBy: userId, roomId: roomId })
          .where(eq(cardsTable.id, cardId))
          .catch((err: any) => console.error('[SQL RESERVE CARD FAIL]', err.message));
      }
      return card;
    }
    return null;
  },
  
  releaseRoomCards: (roomId: string) => {
    cards.forEach(c => {
      if (c.roomId === roomId) {
        c.reservedBy = null;
        c.roomId = null;
      }
    });
    saveCollection('cards.json', cards);

    if (dbConnection.isAvailable()) {
      const sqlDb = dbConnection.db;
      sqlDb.update(cardsTable)
        .set({ reservedBy: null, roomId: null })
        .where(eq(cardsTable.roomId, roomId))
        .catch((err: any) => console.error('[SQL RELEASE ROOM CARDS FAIL]', err.message));
    }
  },
  
  releaseUserRoomCards: (userId: string, roomId: string) => {
    cards.forEach(c => {
      if (c.roomId === roomId && c.reservedBy === userId) {
        c.reservedBy = null;
        c.roomId = null;
      }
    });
    saveCollection('cards.json', cards);

    if (dbConnection.isAvailable() && !userId.startsWith('bot-')) {
      const sqlDb = dbConnection.db;
      sqlDb.update(cardsTable)
        .set({ reservedBy: null, roomId: null })
        .where(and(eq(cardsTable.roomId, roomId), eq(cardsTable.reservedBy, userId)))
        .catch((err: any) => console.error('[SQL RELEASE USER ROOM CARDS FAIL]', err.message));
    }
  },

  // --- BINGO ROOMS ---
  getRooms: () => rooms,
  
  getRoom: (id: string) => rooms.find(r => r.id === id),
  
  saveRoom: (room: BingoRoom) => {
    const idx = rooms.findIndex(r => r.id === room.id);
    if (idx >= 0) {
      rooms[idx] = room;
    } else {
      rooms.push(room);
    }
    saveCollection('rooms.json', rooms);

    if (dbConnection.isAvailable()) {
      const sqlDb = dbConnection.db;
      sqlDb.insert(roomsTable).values({
        id: room.id,
        name: room.name,
        entryFee: room.entryFee,
        prizePool: room.prizePool,
        commission: room.commission,
        status: room.status,
        activePlayers: room.activePlayers,
        maxPlayers: room.maxPlayers,
        updatedAt: new Date()
      }).onConflictDoUpdate({
        target: roomsTable.id,
        set: {
          prizePool: room.prizePool,
          commission: room.commission,
          status: room.status,
          activePlayers: room.activePlayers,
          updatedAt: new Date()
        }
      }).catch((err: any) => console.error('[SQL SAVE ROOM FAIL]', err.message));
    }
    return room;
  },

  // --- TRANSACTIONS (DEPOSITS & WITHDRAWALS) ---
  getTransactions: () => transactions,
  
  getTransaction: (id: string) => transactions.find(t => t.id === id),
  
  addTransaction: (tx: Transaction) => {
    transactions.unshift(tx);
    saveCollection('transactions.json', transactions);

    db.addNotification({
      id: 'notif-' + Math.random().toString(36).substr(2, 9),
      userId: tx.userId,
      message: tx.type === 'deposit' 
        ? `Your deposit request of ${tx.amount} ETB via ${tx.method.toUpperCase()} has been submitted for review.`
        : `Your withdrawal request of ${tx.amount} ETB has been submitted.`,
      read: false,
      type: 'payment',
      createdAt: new Date().toISOString()
    });

    if (dbConnection.isAvailable()) {
      const sqlDb = dbConnection.db;
      sqlDb.insert(transactionsTable).values({
        id: tx.id,
        userId: tx.userId,
        type: tx.type,
        amount: tx.amount,
        status: tx.status,
        method: tx.method,
        referenceNumber: tx.referenceNumber || null,
        phoneNumber: tx.phoneNumber || null,
        comment: (tx as any).comment || null,
        createdAt: new Date(tx.createdAt || Date.now())
      }).catch((err: any) => console.error('[SQL ADD TRANSACTION FAIL]', err.message));
    }
    return tx;
  },
  
  updateTransactionStatus: (id: string, status: 'approved' | 'rejected' | 'completed') => {
    const tx = transactions.find(t => t.id === id);
    if (tx) {
      tx.status = status;
      saveCollection('transactions.json', transactions);

      if (dbConnection.isAvailable()) {
        const sqlDb = dbConnection.db;
        sqlDb.update(transactionsTable)
          .set({ status: status })
          .where(eq(transactionsTable.id, id))
          .catch((err: any) => console.error('[SQL UPDATE TRANSACTION FAIL]', err.message));
      }
      return tx;
    }
    return null;
  },

  // --- REVENUE RECORDS ---
  getRevenue: () => revenueRecords,
  
  addRevenue: (record: RevenueRecord) => {
    revenueRecords.unshift(record);
    saveCollection('revenue.json', revenueRecords);

    // Record as audit, and log to postgreSQL
    db.log('Revenue Commission', 'admin-1', `Collected commission of ${record.commission} ETB from Room: ${record.roomName}, Game ID: ${record.gameId}`);
    return record;
  },

  // --- NOTIFICATIONS ---
  getNotifications: () => notifications,
  
  addNotification: (notif: AppNotification) => {
    notifications.unshift(notif);
    saveCollection('notifications.json', notifications);
    return notif;
  },
  
  getUserNotifications: (userId: string) => notifications.filter(n => n.userId === userId || n.userId === 'all'),
  
  markNotifRead: (id: string) => {
    const notif = notifications.find(n => n.id === id);
    if (notif) {
      notif.read = true;
      saveCollection('notifications.json', notifications);
      return notif;
    }
    return null;
  },

  // --- AUDIT LOGS ---
  getAuditLogs: () => auditLogs,
  
  log: (action: string, userId: string, details: string) => {
    const newLog: AuditLog = {
      id: 'log-' + Math.random().toString(36).substr(2, 9),
      action,
      userId,
      details,
      timestamp: new Date().toISOString()
    };
    auditLogs.unshift(newLog);
    saveCollection('audit.json', auditLogs);

    if (dbConnection.isAvailable()) {
      const sqlDb = dbConnection.db;
      sqlDb.insert(auditLogsTable).values({
        action: action,
        userId: userId,
        details: details,
        timestamp: new Date()
      }).catch((err: any) => console.error('[SQL SAVE AUDIT LOG FAIL]', err.message));
    }
    return newLog;
  },

  // --- CHAT MESSAGES ---
  getChatMessages: () => chatMessages,
  
  addChatMessage: (msg: ChatMessage) => {
    chatMessages.push(msg);
    if (chatMessages.length > 200) {
      chatMessages.shift();
    }
    saveCollection('chat.json', chatMessages);
    return msg;
  },
  
  saveCollection: (filename: string, content: any) => {
    saveCollection(filename, content);
  },
  
  getAppUrl: (): string | null => {
    try {
      const filePath = path.join(DATA_DIR, 'app_url.json');
      if (fs.existsSync(filePath)) {
        const raw = fs.readFileSync(filePath, 'utf8');
        return JSON.parse(raw).url;
      }
    } catch (e) {}
    return null;
  },
  
  setAppUrl: (url: string) => {
    try {
      const filePath = path.join(DATA_DIR, 'app_url.json');
      fs.writeFileSync(filePath, JSON.stringify({ url }), 'utf8');
    } catch (e) {}
  }
};
