/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { db } from './db.js';
import { BingoCard, BingoRoom, BingoGame, User } from '../src/types.js';
import { Server as SocketServer } from 'socket.io';

export interface GameSession {
  roomId: string;
  roomName: string;
  entryFee: number;
  gameId: string | null;
  status: 'waiting' | 'playing' | 'completed';
  players: {
    userId: string;
    userName: string;
    isBot: boolean;
    cardId: number | null;
  }[];
  calledNumbers: number[];
  numberPool: number[];
  callingIntervalId: NodeJS.Timeout | null;
  startTime: number | null;
  lastCalledNumber: number | null;
}

// In-Memory active game sessions
const activeSessions: Map<string, GameSession> = new Map();

// Helper to translate numbers into Amharic speech
export function translateToAmharicVoice(num: number): string {
  let letter = '';
  if (num >= 1 && num <= 15) letter = 'B';
  else if (num >= 16 && num <= 30) letter = 'I';
  else if (num >= 31 && num <= 45) letter = 'N';
  else if (num >= 46 && num <= 60) letter = 'G';
  else if (num >= 61 && num <= 75) letter = 'O';

  const ones = ['', 'አንድ', 'ሁለት', 'ሶስት', 'አራት', 'አምስት', 'ስድስት', 'ሰባት', 'ስምንት', 'ዘጠኝ'];
  
  let numWord = '';
  if (num >= 10 && num < 20) {
    const teenMap: { [key: number]: string } = {
      10: 'አስር', 11: 'አስራ አንድ', 12: 'አስራ ሁለት', 13: 'አስራ ሶስት', 14: 'አስራ አራት',
      15: 'አስራ አምስት', 16: 'አስራ ስድስት', 17: 'አስራ ሰባት', 18: 'አስራ ስምንት', 19: 'አስራ ዘጠኝ'
    };
    numWord = teenMap[num];
  } else {
    const tensIdx = Math.floor(num / 10);
    const onesIdx = num % 10;
    const tensMap: { [key: number]: string } = {
      2: 'ሃያ', 3: 'ሰላሳ', 4: 'አርባ', 5: 'ሃምሳ', 6: 'ስድሳ', 7: 'ሰባ'
    };
    
    const tensWord = tensMap[tensIdx] || '';
    const onesWord = ones[onesIdx] || '';
    
    if (tensWord && onesWord) {
      numWord = `${tensWord} ${onesWord}`;
    } else {
      numWord = tensWord || onesWord || '';
    }
  }

  return `${letter} ${numWord}`;
}

// Check if a bingo card has a winning pattern
export function checkBingo(cardNumbers: number[][], calledNumbers: number[]): { isWinner: boolean; pattern: string; marked: boolean[][] } {
  const marked: boolean[][] = Array(5).fill(null).map(() => Array(5).fill(false));
  const calledSet = new Set(calledNumbers);

  // Center coordinate [2][2] is FREE space
  for (let r = 0; r < 5; r++) {
    for (let c = 0; c < 5; c++) {
      if (r === 2 && c === 2) {
        marked[r][c] = true; // FREE index
      } else {
        const val = cardNumbers[r][c];
        marked[r][c] = calledSet.has(val);
      }
    }
  }

  // 1. Check Horizontal Lines
  for (let r = 0; r < 5; r++) {
    if (marked[r].every(v => v)) {
      return { isWinner: true, pattern: `Horizontal Row ${r + 1}`, marked };
    }
  }

  // 2. Check Vertical Lines
  for (let c = 0; c < 5; c++) {
    let verticalWin = true;
    for (let r = 0; r < 5; r++) {
      if (!marked[r][c]) {
        verticalWin = false;
        break;
      }
    }
    if (verticalWin) {
      return { isWinner: true, pattern: `Vertical Column ${c + 1}`, marked };
    }
  }

  // 3. Check Diagonal (Top-Left to Bottom-Right)
  let diag1Win = true;
  for (let i = 0; i < 5; i++) {
    if (!marked[i][i]) {
      diag1Win = false;
      break;
    }
  }
  if (diag1Win) {
    return { isWinner: true, pattern: 'Diagonal Primary', marked };
  }

  // 4. Check Diagonal (Bottom-Left to Top-Right)
  let diag2Win = true;
  for (let i = 0; i < 5; i++) {
    if (!marked[4 - i][i]) {
      diag2Win = false;
      break;
    }
  }
  if (diag2Win) {
    return { isWinner: true, pattern: 'Diagonal Secondary', marked };
  }

  // 5. Check 4 Corners
  if (marked[0][0] && marked[0][4] && marked[4][0] && marked[4][4]) {
    return { isWinner: true, pattern: '4 Corners', marked };
  }

  // 6. Full House (all coordinates marked)
  let fullHouse = true;
  for (let r = 0; r < 5; r++) {
    for (let c = 0; c < 5; c++) {
      if (!marked[r][c]) {
        fullHouse = false;
        break;
      }
    }
  }
  if (fullHouse) {
    return { isWinner: true, pattern: 'Full House!', marked };
  }

  return { isWinner: false, pattern: '', marked };
}

// Generate the randomized sequence of 75 numbers
function generateCalledPool(): number[] {
  const pool: number[] = [];
  for (let i = 1; i <= 75; i++) {
    pool.push(i);
  }
  // Cryptographically secure randomize (using sort + map with crypto or Math.random)
  const shuffled: number[] = [];
  while (pool.length > 0) {
    const idx = Math.floor(Math.random() * pool.length);
    shuffled.push(pool.splice(idx, 1)[0]);
  }
  return shuffled;
}

// Initialize active room states on start
export function initGameEngine(io: SocketServer) {
  const rooms = db.getRooms();
  rooms.forEach(room => {
    activeSessions.set(room.id, {
      roomId: room.id,
      roomName: room.name,
      entryFee: room.entryFee,
      gameId: null,
      status: 'waiting',
      players: [],
      calledNumbers: [],
      numberPool: [],
      callingIntervalId: null,
      startTime: null,
      lastCalledNumber: null,
    });
  });

  // Start background bot manager script to periodically join awaiting rooms
  setInterval(() => {
    manageBotParticipation(io);
  }, 4000);

  // Second-by-second room scheduler for precise 30s countdown and continuous auto-starts
  setInterval(() => {
    rooms.forEach(room => {
      const session = activeSessions.get(room.id);
      if (!session) return;

      if (session.status === 'waiting') {
        if (session.startTime === null) {
          session.startTime = Date.now() + 30000;
        }
        const secondsLeft = Math.ceil((session.startTime - Date.now()) / 1000);
        if (secondsLeft > 0) {
          io.to(room.id).emit('room:countdown', { seconds: secondsLeft });
        } else {
          // Timer expired!
          const registeredPlayersCount = session.players.length;
          if (registeredPlayersCount > 0) {
            // IF A PLAYER HAS JOINED: Strictly ensure no bots are allowed in the session.
            session.players = session.players.filter(p => !p.isBot);
            room.activePlayers = session.players.length;
            db.saveRoom(room);
            
            // Start the game automatically with only the real players
            startGame(room.id, io);
          } else {
            // No players registered. AS REQUESTED: Start game anyway with random bots!
            const botNames = [
              'Abenezer', 'Selam', 'Yonas', 'Beti', 'Ruth', 'Tariku', 
              'Mahlet', 'Dawit', 'Feven', 'Elias', 'Almaz', 'Henok'
            ];
            // Shuffle names and pick 4 to 6 random bots
            const shuffledNames = [...botNames].sort(() => 0.5 - Math.random());
            const numBots = 4 + Math.floor(Math.random() * 3); // 4 to 6 bots
            const selectedBotNames = shuffledNames.slice(0, numBots);

            // Fetch available cards for the room that are not reserved
            const allCards = db.getCards();
            const availableCards = allCards.filter(c => !c.reservedBy);

            selectedBotNames.forEach((name, bidx) => {
              if (bidx < availableCards.length) {
                const card = availableCards[bidx];
                const botUserId = `bot-${Math.random().toString(36).substr(2, 9)}`;
                
                // Reserve card in DB for the bot
                db.reserveCard(card.id, botUserId, room.id);

                session.players.push({
                  userId: botUserId,
                  userName: `🤖 ${name}`,
                  isBot: true,
                  cardId: card.id
                });
              }
            });

            // Set room player counts
            room.activePlayers = session.players.length;
            db.saveRoom(room);

            // Start the game automatically
            startGame(room.id, io);
          }
        }
      }
    });
  }, 1000);
}

// Handle Bot Auto-Joining and Card Reservation
function manageBotParticipation(io: SocketServer) {
  // Disabled demo bots per client request
  return;
}

// Join room handler for live users with multiple cards (up to 20)
export function joinRoom(
  roomId: string, 
  user: User, 
  cardIds: number[], 
  io: SocketServer
): { success: boolean; message: string } {
  const room = db.getRoom(roomId);
  const session = activeSessions.get(roomId);

  if (!room || !session) {
    return { success: false, message: 'Bingo Room not found.' };
  }

  if (session.status !== 'waiting') {
    return { success: false, message: 'Game has already started in this room.' };
  }

  // Validate number of card registrations
  if (cardIds.length === 0) {
    return { success: false, message: 'You must select at least 1 card to play.' };
  }

  // Release previous reservations in this room by this user and refund them
  const previousUserCards = db.getCards().filter(c => c.roomId === roomId && c.reservedBy === user.id);
  let refundAmt = 0;
  if (previousUserCards.length > 0) {
    refundAmt = previousUserCards.length * room.entryFee;
    db.updateUserBalance(user.id, refundAmt);
    db.releaseUserRoomCards(user.id, roomId);
    session.players = session.players.filter(p => !(p.userId === user.id && !p.isBot));
  }

  const updatedUser = db.getUser(user.id) || user;

  // Check user balance for all combined cards
  const totalCost = room.entryFee * cardIds.length;
  if (updatedUser.balance < totalCost) {
    // Revert original cards and balance if check fails
    if (refundAmt > 0) {
      db.updateUserBalance(user.id, -refundAmt);
      previousUserCards.forEach(c => {
        db.reserveCard(c.id, user.id, roomId);
        session.players.push({
          userId: user.id,
          userName: user.name,
          isBot: false,
          cardId: c.id
        });
      });
    }
    return { success: false, message: `Insufficient ETB balance. Required: ${totalCost} ETB.` };
  }

  // Deduct entire entry fees amount from user balance
  db.updateUserBalance(updatedUser.id, -totalCost);
  db.log('Game Play bet deduction', updatedUser.id, `Deducted entry fees total of ${totalCost} ETB for ${cardIds.length} card(s) in Room ${room.name}`);

  // Reserve all chosen cardIds
  const successfullyReserved: number[] = [];
  for (const cid of cardIds) {
    const reserved = db.reserveCard(cid, updatedUser.id, roomId);
    if (reserved) {
      successfullyReserved.push(cid);
      
      session.players.push({
        userId: updatedUser.id,
        userName: updatedUser.name,
        isBot: false,
        cardId: cid
      });
    }
  }

  // If none could be reserved, return error and refund bet
  if (successfullyReserved.length === 0) {
    db.updateUserBalance(user.id, totalCost);
    return { success: false, message: 'All selected cards have already been reserved.' };
  }

  // Refund some portion if partial reservation failed (rare but safe safeguard)
  if (successfullyReserved.length < cardIds.length) {
    const refundCount = cardIds.length - successfullyReserved.length;
    db.updateUserBalance(user.id, refundCount * room.entryFee);
    db.log('Game Play partial refund', user.id, `Refunded ${refundCount * room.entryFee} ETB because some cards were occupied.`);
  }

  room.activePlayers = session.players.length;
  db.saveRoom(room);

  // Broadcast updates
  io.to(roomId).emit('room:updated', { room, players: session.players });
  io.emit('lobby:rooms', db.getRooms());

  return { success: true, message: `Joined successfully with ${successfullyReserved.length} cards!` };
}

// Start Game loop
export function startGame(roomId: string, io: SocketServer) {
  const session = activeSessions.get(roomId);
  const room = db.getRoom(roomId);

  if (!session || !room || session.status !== 'waiting') return;

  // Ensure there are players
  if (session.players.length === 0) {
    session.startTime = null;
    return;
  }

  // Compute prizes and deductions (25% Commission)
  const totalPool = session.players.length * room.entryFee;
  const commission = Number((totalPool * 0.25).toFixed(2));
  const prizePool = Number((totalPool - commission).toFixed(2));

  room.prizePool = prizePool;
  room.commission = commission;
  room.status = 'playing';
  db.saveRoom(room);

  session.status = 'playing';
  session.calledNumbers = [];
  session.numberPool = generateCalledPool();
  session.gameId = 'game-' + Math.random().toString(36).substr(2, 9);

  io.to(roomId).emit('game:started', {
    gameId: session.gameId,
    room,
    players: session.players,
    prizePool,
    commission
  });

  io.emit('lobby:rooms', db.getRooms());

  // Initiate automatic calling engine loop (calls every 4.5 seconds for quick and low-latency interaction)
  session.callingIntervalId = setInterval(() => {
    callNextNumber(roomId, io);
  }, 4500);
}

// Call next number
function callNextNumber(roomId: string, io: SocketServer) {
  const session = activeSessions.get(roomId);
  if (!session || session.status !== 'playing') {
    if (session?.callingIntervalId) clearInterval(session.callingIntervalId);
    return;
  }

  if (session.numberPool.length === 0) {
    // End game as draw if all 75 numbers called without winner
    endGame(roomId, null, 'No Winner (Draw)', io);
    return;
  }

  const num = session.numberPool.pop()!;
  session.calledNumbers.push(num);
  session.lastCalledNumber = num;

  const amharicText = translateToAmharicVoice(num);

  // Send called notification to clients
  io.to(roomId).emit('game:number_called', {
    number: num,
    calledNumbers: session.calledNumbers,
    amharicText
  });

  // Automatically check if any BOT has won
  // For Real players, they also auto-shout or use automated marks.
  // We will check ALL players' cards (real AND bots) server-authoritatively!
  // This ensures fair play, 100% security against client-side cheats, and immediate payouts!
  let winnerFound = false;
  let winningPlayer: any = null;
  let winningPattern = '';

  for (const player of session.players) {
    if (player.cardId) {
      const card = db.getCard(player.cardId);
      if (card) {
        const check = checkBingo(card.numbers, session.calledNumbers);
        if (check.isWinner) {
          winnerFound = true;
          winningPlayer = player;
          winningPattern = check.pattern;
          break; // Stop at first winner
        }
      }
    }
  }

  if (winnerFound && winningPlayer) {
    endGame(roomId, winningPlayer.userId, winningPattern, io);
  }
}

// End Game and handle financial distributions
export function endGame(roomId: string, winnerId: string | null, pattern: string, io: SocketServer) {
  const session = activeSessions.get(roomId);
  const room = db.getRoom(roomId);

  if (!session || !room) return;

  if (session.callingIntervalId) {
    clearInterval(session.callingIntervalId);
    session.callingIntervalId = null;
  }

  const totalPool = session.players.length * room.entryFee;
  const commission = Number((totalPool * 0.25).toFixed(2));
  const prizePool = Number((totalPool - commission).toFixed(2));

  let winnerName = 'No Winner';
  let isBotWinner = false;

  if (winnerId) {
    const player = session.players.find(p => p.userId === winnerId);
    if (player) {
      winnerName = player.userName;
      isBotWinner = player.isBot;

      // Award prize to database if real player
      if (!player.isBot) {
        db.updateUserBalance(player.userId, prizePool);
        db.log('Bingo gameplay win', player.userId, `Awarded ${prizePool} ETB prize pool for winning Room ${room.name} with pattern '${pattern}'`);
        
        // Notify the player
        db.addNotification({
          id: 'notif-' + Math.random().toString(36).substr(2, 9),
          userId: player.userId,
          message: `🎉 CONGRATULATIONS! You won ${prizePool} ETB in room '${room.name}'! Pattern: ${pattern}.`,
          read: false,
          type: 'game',
          createdAt: new Date().toISOString()
        });
      }

      // Record System Commision Revenue
      db.addRevenue({
        id: 'rev-' + Math.random().toString(36).substr(2, 9),
        gameId: session.gameId || 'none',
        roomName: room.name,
        totalPool,
        commission,
        winnerPrize: prizePool,
        timestamp: new Date().toISOString()
      });
    }
  }

  // Record audit logs
  db.log('Game end log', 'system', `Room ${room.name} completed. Winner: ${winnerName} (${winnerId}). Total Pool: ${totalPool} ETB, Commission: ${commission} ETB, Payout: ${prizePool} ETB`);

  // Release card reservations associated with this completed room
  db.releaseRoomCards(roomId);

  // Broadcast game results
  io.to(roomId).emit('game:ended', {
    winnerId,
    winnerName,
    pattern,
    prizePool,
    isBot: isBotWinner,
    gameId: session.gameId
  });

  // Reset room and session states
  room.activePlayers = 0;
  room.status = 'waiting';
  room.prizePool = 0;
  room.commission = 0;
  db.saveRoom(room);

  session.status = 'waiting';
  session.players = [];
  session.calledNumbers = [];
  session.numberPool = [];
  session.startTime = null;
  session.lastCalledNumber = null;

  io.to(roomId).emit('room:updated', { room, players: [] });
  io.emit('lobby:rooms', db.getRooms());
}

export function forceRestartGame(roomId: string, io: SocketServer) {
  const session = activeSessions.get(roomId);
  const room = db.getRoom(roomId);

  if (session && room) {
    if (session.callingIntervalId) {
      clearInterval(session.callingIntervalId);
    }
    
    db.releaseRoomCards(roomId);
    
    room.activePlayers = 0;
    room.status = 'waiting';
    room.prizePool = 0;
    room.commission = 0;
    db.saveRoom(room);

    session.status = 'waiting';
    session.players = [];
    session.calledNumbers = [];
    session.numberPool = [];
    session.startTime = null;
    session.lastCalledNumber = null;

    io.to(roomId).emit('room:updated', { room, players: [] });
    io.emit('lobby:rooms', db.getRooms());
    db.log('Admin Action', 'admin-1', `Force restarted Room ${room.name}`);
  }
}
