/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GoogleGenAI, Type } from '@google/genai';
import { db } from './db.js';

let geminiClient: GoogleGenAI | null = null;
function getVerifierGeminiClient(): GoogleGenAI | null {
  if (!geminiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey) {
      geminiClient = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });
    }
  }
  return geminiClient;
}

export function parseTelebirrSMSRegex(text: string): { amount: number; referenceNumber: string; senderPhone?: string; verified: boolean } | null {
  const cleanText = text.trim();
  if (!cleanText) return null;

  // Look for standard Telebirr transaction ID which is exactly 10 alphanumeric uppercase characters or containing letters and numbers
  const words = cleanText.split(/[\s,.;:!?()]+/);
  let referenceNumber = '';
  for (const word of words) {
    const cleanedWord = word.toUpperCase().trim();
    if (/^[A-Z0-9]{10}$/.test(cleanedWord)) {
      if (cleanedWord !== 'SUCCESSFUL' && cleanedWord !== 'REDEEMABLE' && cleanedWord !== 'COMMISSION' && cleanedWord !== 'TRANSACTIO' && cleanedWord !== 'TELEBIRRCO') {
        referenceNumber = cleanedWord;
        break;
      }
    }
  }

  // Look for amount (digits with optional decimals followed/preceded by Birr or ETB)
  let amount = 0;
  const amountPatterns = [
    /(?:Birr|ETB)\s*([\d,]+(?:\.\d{2})?)/i,
    /([\d,]+(?:\.\d{2})?)\s*(?:Birr|ETB)/i,
    /(?:amount of|sum of)\s*([\d,]+(?:\.\d{2})?)/i
  ];

  for (const pattern of amountPatterns) {
    const match = cleanText.match(pattern);
    if (match) {
      const parsedAmount = parseFloat(match[1].replace(/,/g, ''));
      if (parsedAmount > 0) {
        amount = parsedAmount;
        break;
      }
    }
  }

  // Look for Ethiopian phone number (typically starts with 09 or 07, etc., or +251)
  let senderPhone = '';
  const phoneMatch = cleanText.match(/(?:\+2519|\+2517|09|07)\d{8}\b/);
  if (phoneMatch) {
    senderPhone = phoneMatch[0];
  }

  if (referenceNumber && amount > 0) {
    return {
      referenceNumber,
      amount,
      senderPhone: senderPhone || undefined,
      verified: true
    };
  }

  return null;
}

export async function parseAndVerifyTelebirrReceipt(
  text: string, 
  imageBase64: string | null
): Promise<{ verified: boolean; amount: number; referenceNumber: string; senderPhone?: string; explanation: string }> {
  const ai = getVerifierGeminiClient();

  if (ai) {
    try {
      let contents: any[] = [];
      if (imageBase64) {
        const cleanBase64 = imageBase64.includes(';base64,') ? imageBase64.split(';base64,')[1] : imageBase64;
        contents.push({
          inlineData: {
            mimeType: "image/png",
            data: cleanBase64,
          }
        });
      }
      
      const promptText = `
You are an expert fraud investigator and automated payment verification agent for Raya Bingo.
Verify and audit the following Telebirr SMS notification or receipt image to prevent edited messages, fake transactions, or malformed inputs:

TEXT SUBMITTED BY USER:
"""
${text}
"""

Instructions:
1. Validate if this is a genuine, unaltered Telebirr SMS notification or invoice from a verified mobile payment transfer.
2. If the user presents a fake, edited, incomplete, or spoofed receipt layout, set "verified" to false.
3. Verify that the transaction code is exactly 10 character Alphanumeric (typically letters and numbers, in mixed or uppercase, e.g., "9FA6DE4E21" or "HF8279DK28").
4. Extract the EXACT transaction amount (value after "Birr" or "ETB" transferred). Do NOT assume or default any amount.
5. If the details are ambiguous, missing, or do not look authentic, set "verified" to false.
6. The receipt MUST show that the funds were sent or received successfully.

Extract these properties and respond in JSON:
{
  "verified": boolean,
  "amount": number,
  "referenceNumber": "10-char alphanumeric string",
  "senderPhone": "sender phone string or null",
  "explanation": "Detailed explanation of verification decision"
}
`;
      contents.push(promptText);

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              verified: { type: Type.BOOLEAN },
              amount: { type: Type.NUMBER },
              referenceNumber: { type: Type.STRING },
              senderPhone: { type: Type.STRING, nullable: true },
              explanation: { type: Type.STRING }
            },
            required: ["verified", "amount", "referenceNumber", "explanation"]
          }
        }
      });

      const responseText = response.text || '{}';
      const data = JSON.parse(responseText);
      if (data && data.referenceNumber) {
        data.referenceNumber = data.referenceNumber.toUpperCase().replace(/[^A-Z0-9]/g, '');
        if (data.referenceNumber.length === 10 && data.amount > 0 && data.verified) {
          return {
            verified: true,
            amount: Number(data.amount),
            referenceNumber: data.referenceNumber,
            senderPhone: data.senderPhone || undefined,
            explanation: data.explanation || 'Verified successfully!'
          };
        }
      }
    } catch (err: any) {
      console.warn("Gemini verifier fail, calling regex engine fallback:", err.message);
    }
  }

  // Fallback to Regex Parser
  const regexResult = parseTelebirrSMSRegex(text);
  if (regexResult) {
    return {
      verified: true,
      amount: regexResult.amount,
      referenceNumber: regexResult.referenceNumber,
      senderPhone: regexResult.senderPhone,
      explanation: `Verified automatically via regex ledger matching. Ref: ${regexResult.referenceNumber}`
    };
  }

  return {
    verified: false,
    amount: 0,
    referenceNumber: '',
    explanation: 'Unable to extract transaction details. Please submit a valid copy-pasted Telebirr SMS or clear receipt image.'
  };
}
