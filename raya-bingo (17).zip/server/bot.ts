/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { db } from './db.js';
import { Server as SocketServer } from 'socket.io';
import { parseAndVerifyTelebirrReceipt, parseTelebirrSMSRegex } from './telebirrVerifier.js';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'raya-bingo-enterprise-security-token-key-2519';

export function getAppUrl(): string {
  const dynamicUrl = db.getAppUrl();
  if (dynamicUrl) {
    return dynamicUrl;
  }
  // Always favor the direct, standalone Shared App URL to avoid loading the AI Studio editor/frame wrapper!
  return 'https://ais-pre-m2cpap5lzg2uajfdrg5puh-374804593577.us-west1.run.app';
}

export interface TelegramMockMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
  image?: string;
}

// Store the mock chat history for different users
const chatHistories: Map<string, TelegramMockMessage[]> = new Map();

export function sendTelegramMessage(telegramId: string, text: string, io?: SocketServer) {
  // Ensure chat history exists
  if (!chatHistories.has(telegramId)) {
    chatHistories.set(telegramId, [
      {
        id: 'msg-welcome',
        sender: 'bot',
        text: '👋 Welcome to Raya Bingo Bot! Press /start to begin.',
        timestamp: new Date(Date.now() - 60000).toISOString()
      }
    ]);
  }

  const history = chatHistories.get(telegramId)!;
  const newMsg: TelegramMockMessage = {
    id: 'msg-' + Math.random().toString(36).substr(2, 9),
    sender: 'bot',
    text,
    timestamp: new Date().toISOString()
  };

  history.push(newMsg);

  // If Socket.io server is provided, broadast in real-time to user's browser session!
  if (io) {
    io.emit(`telegram:message:${telegramId}`, newMsg);
    io.emit('telegram:push_notif', { telegramId, text });
  }

  console.log(`[TELEGRAM BOT NOTIFICATION] User ID: ${telegramId}, Message: "${text}"`);
}

export async function handleUserTelegramCommand(
  telegramId: string,
  username: string,
  text: string,
  io: SocketServer
): Promise<string> {
  // Init history
  if (!chatHistories.has(telegramId)) {
    chatHistories.set(telegramId, []);
  }

  const history = chatHistories.get(telegramId)!;
  
  // Save user's text
  history.push({
    id: 'msg-' + Math.random().toString(36).substr(2, 9),
    sender: 'user',
    text,
    timestamp: new Date().toISOString()
  });

  const rawText = text.trim();
  const cmd = rawText.toLowerCase();
  let reply = '';

  const user = db.getUserByTelegramId(telegramId);

  // Parse transfer command: /transfer <phone> <amount> or transfer <phone> <amount>
  const parts = rawText.split(/\s+/);
  const isTransferInit = parts[0]?.toLowerCase() === '/transfer' || parts[0]?.toLowerCase() === 'transfer' || parts[0] === 'Transfer 🎁';

  if (isTransferInit && parts.length >= 3) {
    if (!user) {
      reply = `❌ You haven't registered on Raya Bingo yet!\n\nUse the **Register 📝** button or launch **Play 🎮** to create and link your user account in 2 seconds.`;
    } else {
      const recipientPhone = parts[1].trim();
      const amount = parseFloat(parts[2]);

      if (isNaN(amount) || amount <= 0) {
        reply = `⚠️ *Invalid Transfer Amount!*\n\nPlease use format:\n\`/transfer <phone> <amount>\`\n\nExample: \`/transfer 0940889473 50\``;
      } else if (user.balance < amount) {
        reply = `❌ *Insufficient Balance!*\n\nYour current wallet balance is *${user.balance} ETB*. You cannot transfer *${amount} ETB*.`;
      } else {
        const recipient = db.getUserByPhoneNumber(recipientPhone);
        if (!recipient) {
          reply = `❌ *User Not Found!*\n\nWe couldn't locate any registered player on Raya Bingo with phone number *${recipientPhone}*. Ensure they register first!`;
        } else if (recipient.id === user.id) {
          reply = `🤔 *Self-Transfer Not Permitted.*\n\nYou cannot transfer funds to your own wallet!`;
        } else {
          // Perform transfer
          db.updateUserBalance(user.id, -amount);
          db.updateUserBalance(recipient.id, amount);

          // Log the transaction
          db.log('Wallet Transfer', user.id, `Transferred ${amount} ETB to receiver ${recipient.name} (${recipient.phoneNumber}) via Telegram bot.`);
          db.log('Wallet Transfer Received', recipient.id, `Received ${amount} ETB from sender ${user.name} (${user.phoneNumber}) via Telegram bot.`);

          // Send in-bot alerts
          reply = `✅ *Transfer Successful!*\n\n🎁 You have successfully transferred *${amount} ETB* to *${recipient.name}* (📱 ${recipient.phoneNumber}).\n\nYour new balance is *${user.balance} ETB*.`;
          
          if (recipient.telegramId) {
            sendTelegramMessage(
              recipient.telegramId,
              `🎁 *Balance Received!*\n\n*${user.name}* has sent you *${amount} ETB* directly via Telegram Bot.\n\nYour new wallet balance is *${recipient.balance} ETB*!`,
              io
            );
          }
        }
      }
    }
  } else if (cmd === '/start' || cmd === 'start') {
    reply = `🇪🇹 *Raya Bingo Secure Telegram Portal* 🇪🇹\n\nWelcome to Ethiopia's premium real-time multiplayer bingo system! Engage with other players in our competitive 10 ETB to 500 ETB lobbies.\n\n👇 Feel free to use the interactive bot keyboard below:`;
  } else if (cmd === '/play' || cmd === 'play 🎮' || cmd === 'play') {
    const appUrl = getAppUrl();
    const deepLink = `${appUrl}?tg_auth=true&tg_id=${telegramId}&tg_username=${username}&tg_name=${encodeURIComponent(username || 'TG User')}`;
    reply = `🎮 *Launces Raya Bingo Applet!*\n\nClick the button link below to securely login with your Telegram account details and play live Bingo inside our Addis multiplayer lobbies:\n\n🔗 [Open Raya Bingo Applet](${deepLink})`;
  } else if (cmd === '/register' || cmd === 'register 📝' || cmd === 'register') {
    if (user) {
      reply = `✅ *Already Registered!*\n\nYou are already registered on Raya Bingo!\n\n👤 *Player Name:* ${user.name}\n📱 *Phone:* ${user.phoneNumber || 'Not Linked'}\n💰 *Balance:* *${user.balance} ETB*\n\nPress **Play 🎮** to enter active bingo lobbies!`;
    } else {
      reply = `📝 *Register Your Raya Bingo Player Account*\n\nTo lock your *10 ETB Onboarding Bonus* and play with real-money deposits, please share your Telegram contact number securely with us.\n\n👇 Click the green **📱 Share Contact / Phone** button on your screen to register instantly!`;
    }
  } else if (cmd === '/balance' || cmd === 'check balance 💵' || cmd === 'balance' || cmd === 'check balance') {
    if (user) {
      reply = `💰 *Raya Wallet Statement*\n\n👤 Account: ${user.name}\n📞 Telephone: ${user.phoneNumber || 'Not Linked'}\n🎰 Available Balance: *${user.balance} ETB*\n\nRequest deposits and withdrawals in Telebirr inside the app dashboard!`;
    } else {
      reply = `❌ *You are not registered yet!*\n\nClick the **Register 📝** button to share your mobile contact and activate your Raya Bingo account.`;
    }
  } else if (cmd === '/deposit' || cmd === 'deposit 💵' || cmd === 'deposit') {
    reply = `📥 *Official Raya Bingo Wallet Deposits*\n\nTransfer your deposit funds manually to our official billing wallet:\n\n• *Telebirr Wallet:* \`0940889473\` (Daniel)\n\n⚠️ *Important:* After transferring, launch **Play 🎮**, click on **Wallet**, submit your 10-character reference ID, and our billing administration will instantly verify and credit your balance!`;
  } else if (cmd === '/support' || cmd === 'contact support ☎️' || cmd === 'contact support' || cmd === 'support') {
    reply = `☎️ *Raya Bingo Customer Support*\n\nWe are here for you 24 hours a day, 7 days a week! Get in touch for any deposit, checkout, or account queries:\n\n• *Direct Telegram Support:* @RayaBingoSupport_Bot\n• *Phone Support:* \`0940889473\`\n• *Admin Office:* Addis Ababa, Bole Sub-City, Block 4B\n• *Platform Helpline:* care@rayabingo.et`;
  } else if (cmd === '/instructions' || cmd === 'instruction 📖' || cmd === 'instructions' || cmd === 'instruction') {
    reply = `📖 *Raya Bingo Quick Tutorial*\n\n1️⃣ Join any room (Economy: \`10 ETB\`, Gold: \`100 ETB\` or VIP: \`500 ETB\` entry fee).\n2️⃣ Claim your desired Bingo Cards from the public pool.\n3️⃣ The system calls random numbers between 1-75 clearly in *Amharic* & *English*.\n4️⃣ Be the first to complete a full horizontal line, vertical line, diagonal, 4 angles, or full house and press "BINGO"!\n5️⃣ Winning pools automatically pay out right after validation. 25% table commission is transparently charged to fuel development.`;
  } else if (cmd === '/transfer' || cmd === 'transfer 🎁' || cmd === 'transfer') {
    if (user) {
      reply = `🎁 *Instant Balance Transfer*\n\nSend game money to friends on Raya Bingo directly using their phone number!\n\n*Usage Syntax:*\nWrite \`transfer <receiver_phone> <amount>\`\n\n*Example:* \`transfer 0940889473 50\`\n\n_Note: Transfers are irreversible and executed instantly._`;
    } else {
      reply = `❌ *Access Denied!*\n\nYou must register first by sharing your contact card before playing or transferring credits.`;
    }
  } else if (cmd === '/withdraw' || cmd === 'withdraw 🤑' || cmd === 'withdraw') {
    reply = `🤑 *Raya Fast Cashout Guidelines*\n\n• Withdrawals are initiated inside the wallet tab in the mobile dashboard.\n• Supported Option: *Telebirr* mobile banking.\n• Processing Speed: Completed within 1 to 2 hours after quick security checks by administrative audits.\n• Daily Limit: Starts at 5,000 ETB per player account.`;
  } else if (cmd === '/invite' || cmd === 'invite 🔗' || cmd === 'invite') {
    const appUrl = getAppUrl();
    const refCode = user ? `tg_${telegramId}` : `tg_guest_${telegramId}`;
    const inviteLink = `${appUrl}?ref=${refCode}`;
    reply = `🔗 *Raya Bingo Referral Program*\n\nInvite your network and friends to register! Receive an instant *10 ETB Bonus Reward* straight to your playable wallet for every friend who registers and links their contact card!\n\nYour Invite Link:\n\`${inviteLink}\``;
  } else if (cmd === '/convert' || cmd === 'convert bonus 💲' || cmd === 'convert' || cmd === 'convert bonus') {
    if (user) {
      reply = `💲 *Bonus Wallet Conversion*\n\nYou currently have: \`10.00 ETB\` in Welcome/Referral promotional bonus balances.\n\n🌟 Convert your bonus to cash by playing entries in our *10 ETB Economy Lobbies*! All winnings from promotional cash are fully withdrawable into raw cash on approval!`;
    } else {
      reply = `❌ Please register on Raya Bingo first to unlock eligible promotional bonuses.`;
    }
  } else {
    // Check if the user pasted a Telebirr receipt message / SMS directly to the bot.
    // We check for potential codes, or if the text looks like an official payment receipt.
    const potentialCode = parseTelebirrSMSRegex(rawText);
    const textHasKeywords = rawText.toLowerCase().includes('telebirr') ||
                           rawText.toLowerCase().includes('birr') ||
                           rawText.toLowerCase().includes('etb') ||
                           rawText.toLowerCase().includes('transferred') ||
                           rawText.toLowerCase().includes('received') ||
                           /^[A-Z0-9]{10}$/i.test(rawText);

    if (potentialCode || textHasKeywords) {
      if (!user) {
        reply = `❌ *You are not registered yet!*\n\nPlease click the **Register 📝** button below or launch **Play 🎮** to share your mobile contact as safe registration code first, then you can paste any Telebirr receipt to automatically top-up.`;
      } else {
        const refMsg = potentialCode ? potentialCode.referenceNumber : "scanning";
        reply = `⏳ *Processing automated Telebirr journal check...*\nChecking Reference ID \`${refMsg}\` on telebirr.com official ledgers...`;
        
        try {
          // Audit receipt text using the full Gemini parser or regular expression fallback
          const audit = await parseAndVerifyTelebirrReceipt(rawText, null);
          if (audit.verified && audit.referenceNumber && audit.amount > 0) {
            const normRef = audit.referenceNumber.trim().toUpperCase();
            const dupTx = db.getTransactions().find(t => t.referenceNumber === normRef && t.status === 'completed');
            
            if (dupTx) {
              reply = `⚠️ *Duplicate Transaction!* The reference *${normRef}* has already been credited in another transaction. Fraud checked.`;
            } else if (audit.amount < 10 || audit.amount > 10000) {
              reply = `❌ *Invalid Deposit Amount*\n\nParsed amount *${audit.amount} ETB* is outside permissible boundaries (10 - 10,000 ETB).`;
            } else {
              const txId = 'tx-dep-' + Math.random().toString(36).substr(2, 9);
              const auditTx = {
                id: txId,
                userId: user.id,
                userName: user.name,
                amount: audit.amount,
                type: 'deposit' as const,
                status: 'completed' as const,
                method: 'telebirr' as const,
                referenceNumber: normRef,
                phoneNumber: audit.senderPhone || user.phoneNumber || '0940889473',
                screenshot: '',
                createdAt: new Date().toISOString()
              };
              
              db.addTransaction(auditTx);
              db.updateUserBalance(user.id, audit.amount);
              db.log('Auto-Deposit Approved via Paste', user.id, `Automatically verified & approved Telebirr deposit via pasted text of ${audit.amount} ETB. Ref: ${normRef}`);
              
              io.emit('wallet:update', { userId: user.id, balance: db.getUser(user.id)?.balance || 0 });
              io.emit('admin:refresh_financials');
              
              reply = `🎉 *TELEBIRR PAYMENT AUTO-APPROVED!*\n\nOur system successfully matched transaction ID *${normRef}* with telebirr.com official ledgers.\n\n👤 *Player:* ${user.name}\n💰 *Amount Credited:* *${audit.amount} ETB*\n🎰 *New Wallet Balance:* *${db.getUser(user.id)?.balance || user.balance} ETB*\n\nYou can now tap **Play 🎮** to join live lobbies instantly with your funded wallet!`;
            }
          } else {
            reply = `❌ *Verification Failed*\n\nReason: ${audit.explanation || 'We could not verify this transaction code on telebirr.com standard ledger.'}`;
          }
        } catch (e: any) {
          reply = `❌ *Auto-Approval Error*\n\nUnable to verify transaction automatically. Pls use the manual deposit form inside the desktop/mobile applet.`;
        }
      }
    } else {
      reply = `🤔 Command not recognized. Use the custom keyboard buttons below (Play 🎮, Register 📝, Check Balance 💵, etc.) or write \`transfer <phone> <amt>\` to send money.\n\n💡 *Tip:* To deposit, just copy and paste the entire Telebirr receipt SMS message you received here, and we will approve and credit it automatically!`;
    }
  }

  // Save bot's reply and broadcast
  sendTelegramMessage(telegramId, reply, io);
  return reply;
}

export async function handleUserTelegramPhoto(
  telegramId: string,
  username: string,
  imageBase64: string,
  captionText: string,
  io: SocketServer
): Promise<string> {
  // Init history
  if (!chatHistories.has(telegramId)) {
    chatHistories.set(telegramId, []);
  }

  const history = chatHistories.get(telegramId)!;
  
  // Save user's photograph block
  history.push({
    id: 'msg-' + Math.random().toString(36).substr(2, 9),
    sender: 'user' as const,
    text: captionText || 'Uploaded payment receipt',
    image: imageBase64,
    timestamp: new Date().toISOString()
  });

  const user = db.getUserByTelegramId(telegramId);
  let reply = '';

  if (!user) {
    reply = `❌ *You are not registered yet!*\n\nPlease share your mobile phone contact card / register first, then upload your Telebirr receipt image for instant auto-balance crediting!`;
  } else {
    sendTelegramMessage(telegramId, `⏳ *Analyzing your screenshot via AI OCR verifier...*\nDownloading and scanning transaction proof receipt details...`, io);

    try {
      // Validate payment screenshot via standard parser
      const audit = await parseAndVerifyTelebirrReceipt(captionText, imageBase64);
      if (audit.verified && audit.referenceNumber && audit.amount > 0) {
        const normRef = audit.referenceNumber.trim().toUpperCase();

        if (audit.amount < 10 || audit.amount > 10000) {
          reply = `❌ *Invalid Deposit Amount*\n\nParsed amount *${audit.amount} ETB* is outside permissible bounds (10 - 10,000 ETB).`;
        } else {
          // Check duplicates
          const allTransactions = db.getTransactions();
          const exists = allTransactions.some(
            t => t.referenceNumber && t.referenceNumber.trim().toUpperCase() === normRef
          );
          if (exists) {
            reply = `⚠️ *Duplicate Transaction ID!*\n\nThe reference *${normRef}* has already been verified and credited.`;
          } else {
            // Save completed transfer
            const txId = 'tx-dep-' + Math.random().toString(36).substr(2, 9);
            const approvedTx = {
              id: txId,
              userId: user.id,
              userName: user.name,
              amount: audit.amount,
              type: 'deposit' as const,
              status: 'completed' as const,
              method: 'telebirr' as const,
              referenceNumber: normRef,
              phoneNumber: audit.senderPhone || user.phoneNumber || '0940889473',
              screenshot: imageBase64,
              createdAt: new Date().toISOString()
            };

            db.addTransaction(approvedTx);
            db.updateUserBalance(user.id, audit.amount);
            db.log('Auto-Deposit Screen Approved via Bot Simulator', user.id, `Parsed & approved telebirr screenshot. Ref: ${normRef}, Amt: ${audit.amount} ETB`);

            db.addNotification({
              id: 'notif-auto-dep-' + Math.random().toString(36).substr(2, 9),
              userId: user.id,
              message: `🎉 Telebirr deposit of ${audit.amount} ETB auto-approved via bot panel attachment! Ref: ${normRef}`,
              read: false,
              type: 'payment',
              createdAt: new Date().toISOString()
            });

            // Notify active browser session
            io.emit('wallet:update', { userId: user.id, balance: db.getUser(user.id)?.balance || 0 });
            io.emit('admin:refresh_financials');

            reply = `🎉 *TELEBIRR PAYMENT AUTO-APPROVED!*\n\nOur system successfully scanned receipt *${normRef}* and credited your wallet instantly!\n\n👤 *Player Name:* ${user.name}\n💰 *Credited Amount:* *${audit.amount} ETB*\n🎰 *New Wallet Balance:* *${db.getUser(user.id)?.balance || user.balance} ETB*`;
          }
        }
      } else {
        reply = `❌ *Verification Failed*\n\nReason: ${audit.explanation || 'We could not verify this receipt screenshot. Ensure it is a valid Telebirr deposit proof and try again.'}`;
      }
    } catch (err: any) {
      console.error('Error in simulated photo handler parser:', err);
      reply = `❌ *Processing Error*\n\nUnable to verify transaction. Please try pasting the SMS text or select app manual verification panel.`;
    }
  }

  // Save bot's reply and broadcast
  sendTelegramMessage(telegramId, reply, io);
  return reply;
}

export function getTelegramHistory(telegramId: string): TelegramMockMessage[] {
  if (!chatHistories.has(telegramId)) {
    chatHistories.set(telegramId, [
      {
        id: 'msg-welcome',
        sender: 'bot',
        text: '👋 Welcome to Raya Bingo Bot! Press `/start` or `/play` to begin your gaming journey!',
        timestamp: new Date().toISOString()
      }
    ]);
  }
  return chatHistories.get(telegramId)!;
}

// ============================================================================
// --- OFFICIAL TELEGRAM BOT ENGINE (REAL BOT HOOK HANDLERS) ---
// ============================================================================

function normalizePhone(phone: string): string {
  let cleaned = phone.replace(/\s+/g, '').replace(/[^\d+]/g, '');
  if (cleaned.startsWith('+251')) {
    cleaned = '0' + cleaned.substring(4);
  } else if (cleaned.startsWith('251')) {
    cleaned = '0' + cleaned.substring(3);
  }
  return cleaned;
}

function generateToken(userId: string) {
  return jwt.sign({ userId }, JWT_SECRET, { expiresIn: '24h' });
}

function getMainMenuMarkup() {
  return {
    keyboard: [
      [{ text: 'Play 🎮' }, { text: 'Register 📝' }],
      [{ text: 'Check Balance 💵' }, { text: 'Deposit 💵' }],
      [{ text: 'Contact Support ☎️' }, { text: 'Instruction 📖' }],
      [{ text: 'Transfer 🎁' }, { text: 'Withdraw 🤑' }],
      [{ text: 'Invite 🔗' }, { text: 'Convert Bonus 💲' }]
    ],
    resize_keyboard: true
  };
}

function getRegisterKeyboard() {
  return {
    keyboard: [
      [{ text: '📱 Share Contact / Phone', request_contact: true }],
      [{ text: 'Back to Main Menu' }]
    ],
    resize_keyboard: true,
    one_time_keyboard: true
  };
}

async function sendRealMessage(token: string, chatId: number, options: { text: string; keyboard?: any; inlineKeyboard?: any }) {
  try {
    const payload: any = {
      chat_id: chatId,
      text: options.text,
      parse_mode: 'Markdown',
    };
    if (options.inlineKeyboard) {
      payload.reply_markup = options.inlineKeyboard;
    } else if (options.keyboard) {
      payload.reply_markup = options.keyboard;
    }

    const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const errTxt = await response.text();
      console.error(`[TELEGRAM REAL BOT SEND ERROR] Status ${response.status}:`, errTxt);
    }
  } catch (err) {
    console.error('[TELEGRAM REAL BOT FETCH ERROR]', err);
  }
}

async function sendWithRealDeepLinks(
  token: string,
  chatId: number,
  telegramId: string,
  username: string,
  text: string,
  replyMarkup?: any
) {
  const lowered = text.toLowerCase();
  const isPlay = lowered.includes('/play') || lowered.includes('launces raya') || lowered.includes('open raya bingo');
  const isInvite = lowered.includes('referral program');

  let inlineKeyboard: any = null;

  if (isPlay) {
    const userObj = db.getUserByTelegramId(telegramId);
    const sessionToken = userObj ? generateToken(userObj.id) : '';
    const appUrl = getAppUrl();
    const deepLink = `${appUrl}?tg_auth=true&tg_id=${telegramId}&tg_username=${username}&tg_name=${encodeURIComponent(username || 'TG User')}${sessionToken ? `&token=${sessionToken}` : ''}`;

    inlineKeyboard = {
      inline_keyboard: [
        [
          {
            text: '🎮 Open Raya Bingo (Instant Login)',
            web_app: {
              url: deepLink
            }
          }
        ]
      ]
    };
  } else if (isInvite) {
    const match = text.match(/https?:\/\/[^\s]+/);
    if (match) {
      inlineKeyboard = {
        inline_keyboard: [
          [
            {
              text: '🔗 Direct Share Invite',
              url: `https://t.me/share/url?url=${encodeURIComponent(match[0])}&text=${encodeURIComponent('Join Ethiopia\'s premier multiplayer real-money Bingo & get 10 ETB free registration bonus instantly!')}`
            }
          ]
        ]
      };
    }
  }

  await sendRealMessage(token, chatId, {
    text,
    inlineKeyboard,
    keyboard: replyMarkup
  });
}

async function handleTelegramUpdate(update: any, token: string, io: SocketServer) {
  const message = update.message;
  if (!message) return;

  const chatId = message.chat.id;
  const username = message.from?.username || message.from?.first_name || 'TG Client';
  const telegramId = message.from?.id ? String(message.from.id) : '';

  if (!telegramId) return;

  // 1. Process contact sharing handshake info
  if (message.contact) {
    const contact = message.contact;
    const rawPhone = contact.phone_number;
    const cleanedPhone = normalizePhone(rawPhone);
    const firstName = contact.first_name || '';

    let user = db.getUserByPhoneNumber(cleanedPhone);
    if (user) {
      // Existing: link and login
      user.telegramId = telegramId;
      if (username) {
        user.username = username.replace('@', '');
      }
      db.saveUser(user);
      db.log('Telegram Linked (Real Bot contact share)', user.id, `Linked Telegram ID ${telegramId} to phone ${cleanedPhone}`);

      io.emit(`telegram:push_notif`, { telegramId, text: `Connected!` });

      const userObj = db.getUserByTelegramId(telegramId);
      const sessionToken = userObj ? generateToken(userObj.id) : '';
      const appUrl = getAppUrl();
      const deepLink = `${appUrl}?tg_auth=true&tg_id=${telegramId}&tg_username=${username}&tg_name=${encodeURIComponent(username || 'TG User')}${sessionToken ? `&token=${sessionToken}` : ''}`;

      await sendRealMessage(token, chatId, {
        text: `🔗 *Account Securely Linked!*\n\nWelcome back to Raya Bingo, *${user.name}*! We successfully matched your registered phone number (*${cleanedPhone}*) to this Telegram profile.\n\n💰 *Wallet Balance:* *${user.balance} ETB*\n\nPress the **Open Raya Bingo** button below to launch lobbies and enter active games instantly!`,
        inlineKeyboard: {
          inline_keyboard: [
            [
              {
                text: '🎮 Open Raya Bingo (Instant Login)',
                web_app: {
                  url: deepLink
                }
              }
            ]
          ]
        },
        keyboard: getMainMenuMarkup()
      });
    } else {
      // New: Instant auto registration
      const id = 'user-' + Math.random().toString(36).substr(2, 9);
      const generatedUser = {
        id,
        name: firstName || username || `TG-User-${telegramId.substr(0,4)}`,
        phoneNumber: cleanedPhone,
        telegramId,
        username: username?.replace('@', '') || '',
        firstName: firstName || username || 'Player',
        balance: 10.0, // Onboarding welcome bonus
        role: 'user' as const,
        status: 'active' as const,
        otpVerified: true,
        createdAt: new Date().toISOString()
      };

      db.saveUser(generatedUser);
      db.log('Telegram SignUp (Real Bot contact share)', id, `Registered user ${generatedUser.name} via Telegram contact card share`);

      const userObj = db.getUserByTelegramId(telegramId);
      const sessionToken = userObj ? generateToken(userObj.id) : '';
      const appUrl = getAppUrl();
      const deepLink = `${appUrl}?tg_auth=true&tg_id=${telegramId}&tg_username=${username}&tg_name=${encodeURIComponent(username || 'TG User')}${sessionToken ? `&token=${sessionToken}` : ''}`;

      await sendRealMessage(token, chatId, {
        text: `🎉 *Registration Successful!*\n\nWelcome to Raya Bingo, *${generatedUser.name}*! We verified your phone number *${cleanedPhone}*.\n\n🎁 A *10.00 ETB Welcome Bonus* has been credited to your playing wallet!\n\nPress the **Open Raya Bingo** button below to launch active lobbies with your free bonus instantly!`,
        inlineKeyboard: {
          inline_keyboard: [
            [
              {
                text: '🎮 Open Raya Bingo (Instant Login)',
                web_app: {
                  url: deepLink
                }
              }
            ]
          ]
        },
        keyboard: getMainMenuMarkup()
      });
    }
    return;
  }

  // 1.5 Process photo/screenshot sharing info
  let photoFileId = '';
  let photoMime = 'image/png';
  if (message.photo && message.photo.length > 0) {
    const largestPhoto = message.photo[message.photo.length - 1];
    photoFileId = largestPhoto.file_id;
  } else if (message.document && message.document.mime_type?.startsWith('image/')) {
    photoFileId = message.document.file_id;
    photoMime = message.document.mime_type;
  }

  if (photoFileId) {
    const user = db.getUserByTelegramId(telegramId);
    if (!user) {
      await sendRealMessage(token, chatId, {
        text: `❌ *Registration Required*\n\nPlease click the **Register 📝** button below or launch **Play 🎮** to link your mobile contact first before uploading screenshots for auto-topup.`,
        keyboard: getRegisterKeyboard()
      });
      return;
    }

    try {
      await sendRealMessage(token, chatId, {
        text: `⏳ *Analyzing your screenshot via AI OCR verifier...*\nDownloading and auditing transaction details from standard Telebirr receipts...`
      });

      // Get file details
      const getFileResponse = await fetch(`https://api.telegram.org/bot${token}/getFile?file_id=${photoFileId}`);
      if (!getFileResponse.ok) {
        throw new Error(`Telegram API responded with code ${getFileResponse.status}`);
      }
      
      const fileData = await getFileResponse.json();
      if (!fileData.ok || !fileData.result?.file_path) {
        throw new Error('Could not get valid folder retrieval path for uploaded media.');
      }

      const filePath = fileData.result.file_path;
      const downloadUrl = `https://api.telegram.org/file/bot${token}/${filePath}`;
      const fileResponse = await fetch(downloadUrl);
      if (!fileResponse.ok) {
        throw new Error(`Failed to download matching image from Telegram file server.`);
      }

      const arrayBuffer = await fileResponse.arrayBuffer();
      const base64 = Buffer.from(arrayBuffer).toString('base64');
      const captionText = message.caption || '';

      // Validate payment
      const audit = await parseAndVerifyTelebirrReceipt(captionText, base64);
      if (audit.verified && audit.referenceNumber && audit.amount > 0) {
        const normRef = audit.referenceNumber.trim().toUpperCase();

        if (audit.amount < 10 || audit.amount > 10000) {
          await sendRealMessage(token, chatId, {
            text: `❌ *Permit Refused*\n\nParsed amount *${audit.amount} ETB* is outside allowable single deposit range (10 - 10,000 ETB).`,
            keyboard: getMainMenuMarkup()
          });
          return;
        }

        // Check duplicates
        const allTransactions = db.getTransactions();
        const exists = allTransactions.some(
          t => t.referenceNumber && t.referenceNumber.trim().toUpperCase() === normRef
        );
        if (exists) {
          await sendRealMessage(token, chatId, {
            text: `⚠️ *Duplicate Transaction ID!*\n\nThe reference *${normRef}* has already been verified and credited.`,
            keyboard: getMainMenuMarkup()
          });
          return;
        }

        // Save completed transfer
        const txId = 'tx-dep-' + Math.random().toString(36).substr(2, 9);
        const approvedTx = {
          id: txId,
          userId: user.id,
          userName: user.name,
          amount: audit.amount,
          type: 'deposit' as const,
          status: 'completed' as const, // AUTO-APPROVED/COMPLETED!
          method: 'telebirr' as const,
          referenceNumber: normRef,
          phoneNumber: audit.senderPhone || user.phoneNumber || '0940889473',
          screenshot: `data:${photoMime};base64,${base64}`,
          createdAt: new Date().toISOString()
        };

        db.addTransaction(approvedTx);
        db.updateUserBalance(user.id, audit.amount);
        db.log('Auto-Deposit Screen Approved via Bot', user.id, `Parsed & approved telebirr screenshot. Ref: ${normRef}, Amt: ${audit.amount} ETB`);

        db.addNotification({
          id: 'notif-auto-dep-' + Math.random().toString(36).substr(2, 9),
          userId: user.id,
          message: `🎉 Telebirr deposit of ${audit.amount} ETB verified & approved automatically via Telegram screenshot! Ref: ${normRef}`,
          read: false,
          type: 'payment',
          createdAt: new Date().toISOString()
        });

        // Notify active browser session
        io.emit('wallet:update', { userId: user.id, balance: db.getUser(user.id)?.balance || 0 });
        io.emit('admin:refresh_financials');

        await sendRealMessage(token, chatId, {
          text: `🎉 *TELEBIRR PAYMENT AUTO-APPROVED!*\n\nOur system successfully scanned receipt *${normRef}* and credited your wallet instantly!\n\n👤 *Player Name:* ${user.name}\n💰 *Credited Amount:* *${audit.amount} ETB*\n🎰 *New Wallet Balance:* *${db.getUser(user.id)?.balance} ETB*\n\nLaunch **Play 🎮** now to join active lobbies!`,
          keyboard: getMainMenuMarkup()
        });
      } else {
        await sendRealMessage(token, chatId, {
          text: `❌ *Verification Failed*\n\n${audit.explanation || 'We could not verify this receipt screenshot. Ensure it represents a valid Telebirr deposit and try again.'}`,
          keyboard: getMainMenuMarkup()
        });
      }
    } catch (err: any) {
      console.error('Error during automatic bot receipt handling:', err);
      await sendRealMessage(token, chatId, {
        text: `❌ *Processing Error*\n\nUnable to verify transaction automatically. Details: ${err.message || 'Parser engine error'}. Please try pasting the SMS or use application manual panel.`,
        keyboard: getMainMenuMarkup()
      });
    }
    return;
  }

  // 2. Normal text message and buttons
  if (message.text) {
    const text = message.text.trim();
    const cmd = text.toLowerCase();

    // Call simulated/central bot core matching structure in server/bot.ts to save history and return response
    const responseText = await handleUserTelegramCommand(telegramId, username, text, io);

    let replyMarkup = getMainMenuMarkup();
    if (cmd === '/register' || cmd === 'register 📝' || cmd === 'register') {
      const userObj = db.getUserByTelegramId(telegramId);
      if (!userObj) {
        replyMarkup = getRegisterKeyboard();
      }
    }

    await sendWithRealDeepLinks(token, chatId, telegramId, username, responseText, replyMarkup);
  }
}

let pollingActive = false;
let pollingTimeout: NodeJS.Timeout | null = null;
let lastUpdateId = 0;

export function startTelegramBotPolling(io: SocketServer) {
  if (pollingActive) return;
  pollingActive = true;
  console.log('🤖 Real Telegram Polling Engine starting up...');

  const token = (process.env.TELEGRAM_BOT_TOKEN || '8974458592:AAEaudEb_ze_8vnPnStAAhpjp4JwUQheGcw').trim();

  // Validate token shape before firing poll
  if (!token || token === 'MY_TELEGRAM_BOT_KEY' || !token.includes(':')) {
    console.warn('⚠️ Telegram Bot Token omitted or invalid. Skipping real bot polling loop.');
    return;
  }

  // Setup the chat menu button dynamically so the bottom-left Telegram Bot button points to the exact webapp URL
  const appUrl = getAppUrl();
  fetch(`https://api.telegram.org/bot${token}/setChatMenuButton`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      menu_button: {
        type: 'web_app',
        text: 'Play Raya Bingo 🎮',
        web_app: {
          url: appUrl
        }
      }
    })
  })
  .then(async r => {
    const resPayload = await r.json();
    console.log('[TELEGRAM SET MENU BUTTON SUCCESS]:', resPayload);
  })
  .catch(err => {
    console.error('[TELEGRAM SET MENU BUTTON ERROR]:', err);
  });

  async function poll() {
    if (!pollingActive) return;
    try {
      const url = `https://api.telegram.org/bot${token}/getUpdates?offset=${lastUpdateId}&timeout=10`;
      const response = await fetch(url);
      if (response.ok) {
        const data = await response.json();
        if (data.ok && data.result && data.result.length > 0) {
          for (const update of data.result) {
            lastUpdateId = update.update_id + 1;
            await handleTelegramUpdate(update, token, io);
          }
        }
      } else {
        console.warn(`[TELEGRAM POLL WARN] Server responded with code ${response.status}`);
      }
    } catch (err) {
      console.error('[TELEGRAM POLL EXCEPTION]', err);
    }
    // Schedule next poll cleanly
    if (pollingActive) {
      pollingTimeout = setTimeout(poll, 1500);
    }
  }

  poll();
}

export function stopTelegramBotPolling() {
  pollingActive = false;
  if (pollingTimeout) {
    clearTimeout(pollingTimeout);
    pollingTimeout = null;
  }
  console.log('🤖 Real Telegram Polling Engine stopped.');
}

