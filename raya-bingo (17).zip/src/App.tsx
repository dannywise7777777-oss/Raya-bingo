/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { User, AppNotification } from './types.js';
import Navigation from './components/Navigation.js';
import RegistrationForm from './components/RegistrationForm.js';
import WalletDashboard from './components/WalletDashboard.js';
import AdminPanel from './components/AdminPanel.js';
import BingoTable from './components/BingoTable.js';
import RayaBotPortal from './components/RayaBotPortal.js';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Trophy, 
  Sparkles, 
  ShieldAlert, 
  Zap, 
  Smartphone, 
  HelpCircle,
  Copy,
  Plus,
  MessageSquare
} from 'lucide-react';
import { io } from 'socket.io-client';

export default function App() {
  const [token, setToken] = useState<string | null>(localStorage.getItem('raya_token'));
  const [user, setUser] = useState<User | null>(null);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [activeTab, setActiveTab] = useState<string>('lobby'); // lobby, wallet, admin
  const [loading, setLoading] = useState(true);

  const fetchProfile = async (authToken: string) => {
    try {
      const res = await fetch('/api/auth/me', {
        headers: { 'Authorization': `Bearer ${authToken}` }
      });
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
        
        // Connect user persistent socket on lobby update
        const socket = io();
        socket.emit('lobby:join'); // joins lobby broadcast channel
        
        // Fetch current user notifications
        fetchNotifications(authToken);
      } else {
        // Token is stale or invalid, logout
        handleLogout();
      }
    } catch (e) {
      console.error('Error fetching user profile', e);
    } finally {
      setLoading(false);
    }
  };

  const fetchNotifications = async (authToken: string) => {
    try {
      const res = await fetch('/api/notifications', {
        headers: { 'Authorization': `Bearer ${authToken}` }
      });
      if (res.ok) {
        const data = await res.json();
        setNotifications(data);
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const tokenParam = params.get('token');
    const tgAuth = params.get('tg_auth');

    if (tokenParam) {
      localStorage.setItem('raya_token', tokenParam);
      setToken(tokenParam);
      // Clean query parameters from URL for a sleek browser experience
      window.history.replaceState({}, document.title, window.location.pathname);
    } else if (tgAuth === 'true') {
      const tgId = params.get('tg_id');
      const tgUsername = params.get('tg_username') || '';
      const tgName = params.get('tg_name') || '';
      if (tgId) {
        fetch('/api/auth/login-telegram', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ telegramId: tgId, username: tgUsername, name: tgName })
        })
        .then(res => res.json())
        .then(data => {
          if (data.token) {
            localStorage.setItem('raya_token', data.token);
            setToken(data.token);
            if (data.user) {
              setUser(data.user);
            }
          }
        })
        .catch(err => console.error('Telegram DeepLink Login Error', err));
        window.history.replaceState({}, document.title, window.location.pathname);
      }
    } else {
      // Check for native Telegram WebApp execution context
      const tgWebApp = (window as any).Telegram?.WebApp;
      if (tgWebApp && tgWebApp.initDataUnsafe && tgWebApp.initDataUnsafe.user) {
        const tgUser = tgWebApp.initDataUnsafe.user;
        const tgId = tgUser.id ? String(tgUser.id) : '';
        const tgUsername = tgUser.username || '';
        const tgName = `${tgUser.first_name || ''} ${tgUser.last_name || ''}`.trim();

        if (tgId) {
          fetch('/api/auth/login-telegram', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ telegramId: tgId, username: tgUsername, name: tgName })
          })
          .then(res => res.json())
          .then(data => {
            if (data.token) {
              localStorage.setItem('raya_token', data.token);
              setToken(data.token);
              if (data.user) {
                setUser(data.user);
              }
            }
          })
          .catch(err => console.error('Telegram Native MiniApp Login Error', err));
        }
      }
    }
  }, []);

  useEffect(() => {
    if (token) {
      fetchProfile(token);
    } else {
      setLoading(false);
    }
  }, [token]);

  // Read notifications update
  const handleReadNotification = async (notifId: string) => {
    if (!token) return;
    try {
      const res = await fetch(`/api/notifications/${notifId}/read`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        fetchNotifications(token);
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Add notification from client action
  const handleAddNotificationLocally = (message: string, type: 'payment' | 'game' | 'system') => {
    const newNotif: AppNotification = {
      id: 'notif-local-' + Math.random(),
      userId: user?.id || 'all',
      message,
      read: false,
      type,
      createdAt: new Date().toISOString()
    };
    setNotifications(prev => [newNotif, ...prev]);
  };

  const handleRegisterSuccess = (userId: string, otpPrompt: boolean) => {
    // Keeps verification flow container active
  };

  const handleVerifySuccess = (authToken: string, loggedUser: any) => {
    localStorage.setItem('raya_token', authToken);
    setToken(authToken);
    setUser(loggedUser);
    setActiveTab('lobby');
    fetchNotifications(authToken);
  };

  const handleLogout = () => {
    localStorage.removeItem('raya_token');
    setToken(null);
    setUser(null);
    setNotifications([]);
    setActiveTab('lobby');
  };

  const handleBalanceUpdate = (newBalance: number) => {
    if (user) {
      setUser({ ...user, balance: Number(newBalance.toFixed(2)) });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0b0f19] flex flex-col items-center justify-center font-sans relative">
        <div className="absolute inset-0 bg-radial-gradient from-emerald-500/5 via-transparent to-transparent opacity-50" />
        <div className="animate-spin h-8 w-8 rounded-full border-4 border-slate-700 border-t-yellow-500 mb-4" />
        <p className="text-xs font-mono tracking-widest text-[#768b9a] uppercase animate-pulse">Loading Raya Bingo...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0b0f19] text-[#f3f4f6] font-sans flex flex-col justify-between">
      
      {/* Dynamic Header */}
      <Navigation 
        user={user} 
        notifications={notifications} 
        currentTab={activeTab} 
        setTab={setActiveTab} 
        onLogout={handleLogout}
        onReadNotif={handleReadNotification}
      />

      {/* Main Content Arena with extra bottom-padding on mobile to prevent clipping with bottom navigation */}
      <main className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-8 pb-24 md:pb-8 flex-1">
        
        {user ? (
          <div>
            <AnimatePresence mode="wait">
              
              {activeTab === 'lobby' && (
                <motion.div
                  key="lobby"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                >
                  <BingoTable 
                    user={user} 
                    token={token} 
                    onBalanceUpdate={handleBalanceUpdate} 
                    onAddNotif={handleAddNotificationLocally}
                    setTab={setActiveTab}
                  />
                </motion.div>
              )}

              {activeTab === 'wallet' && (
                <motion.div
                  key="wallet"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                >
                  <WalletDashboard 
                    user={user} 
                    token={token} 
                    onBalanceUpdate={handleBalanceUpdate} 
                    onAddNotif={handleAddNotificationLocally}
                  />
                </motion.div>
              )}

              {activeTab === 'admin' && user.role === 'admin' && (
                <motion.div
                  key="admin"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                >
                  <AdminPanel user={user} token={token} onBalanceUpdate={handleBalanceUpdate} />
                </motion.div>
              )}

            </AnimatePresence>
          </div>
        ) : (
          /* ONBOARDING AND REGISTRATION LOBBIES */
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center max-w-5xl mx-auto py-4">
            
            <div className="space-y-6">
              <span className="text-xs font-bold text-yellow-400 bg-yellow-400/10 border border-yellow-500/20 px-3 py-1.5 rounded-full uppercase tracking-wider">
                🇪🇹 EXCLUSIVELY FOR GAMERS IN ETHIOPIA
              </span>
              
              <h1 className="font-display font-black text-3xl sm:text-4xl text-white tracking-tight leading-none">
                Play. Win.<br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-green-500 via-yellow-400 to-red-500">Celebrate!</span>
              </h1>
              
              <p className="text-xs text-slate-400 leading-relaxed max-w-md">
                Raya Bingo brings the high-intensity thrill of multiplayer bingo right to your device. Claim premium randomized cards, mark cells, and listen to spoken numbers called in native Amharic! Deduct 25% transparent commission on game pools with super fast payouts via CBE Birr and Telebirr.
              </p>

              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-slate-900 border border-slate-850 rounded-2xl flex items-center gap-3">
                  <div className="bg-gradient-to-tr from-[#15803d]/20 to-[#eab308]/20 p-2 rounded-xl text-yellow-500">
                    <Trophy size={18} />
                  </div>
                  <div>
                    <span className="text-xs font-black text-white block">25% Commission</span>
                    <span className="text-[10px] text-slate-500">Fixed rate of table entries.</span>
                  </div>
                </div>

                <div className="p-4 bg-slate-900 border border-slate-850 rounded-2xl flex items-center gap-3">
                  <div className="bg-gradient-to-tr from-[#eab308]/20 to-[#dc2626]/20 p-2 rounded-xl text-yellow-500">
                    <Zap size={18} />
                  </div>
                  <div>
                    <span className="text-xs font-black text-white block">Automatic Payouts</span>
                    <span className="text-[10px] text-slate-500">Instant winner verification.</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="lg:border-l lg:border-slate-850 lg:pl-8 space-y-4">
              <RegistrationForm 
                onRegisterSuccess={handleRegisterSuccess} 
                onVerifySuccess={handleVerifySuccess} 
              />
            </div>

          </div>
        )}

      </main>

      {/* Shared Footer Area */}
      <footer className="bg-slate-950 border-t border-slate-900 py-6 text-center text-xs text-slate-500 select-none shrink-0">
        <p className="font-display font-medium text-[11px] tracking-wider uppercase text-slate-600 mb-1">Raya Bingo Platform • Addis Ababa, Ethiopia</p>
        <p className="text-[10px] text-slate-700">Protected by cryptographic RNG protocols and server-authoritative pattern verification ledger.</p>
      </footer>

      <RayaBotPortal 
        user={user} 
        onLoginSuccess={handleVerifySuccess} 
        onBalanceUpdate={handleBalanceUpdate}
        onAddNotif={handleAddNotificationLocally}
      />

    </div>
  );
}
