/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { drizzle } from 'drizzle-orm/node-postgres';
import pkg from 'pg';
const { Pool } = pkg;
import * as schema from './schema.ts';

let poolInstance: any = null;
let dbInstance: any = null;
let isConnectionFailed = false;
let isConnectionTested = false;

export function getPostresConfig() {
  const host = process.env.SQL_HOST;
  const user = process.env.SQL_USER;
  const password = process.env.SQL_PASSWORD;
  const database = process.env.SQL_DB_NAME;

  if (host && user && password && database) {
    return { host, user, password, database };
  }
  return null;
}

export function isSqlDbAvailable(): boolean {
  if (getPostresConfig() === null) {
    return false;
  }
  return true;
}

// Background Self-Test to verify if the server is actually reachable
if (getPostresConfig() !== null) {
  const config = getPostresConfig()!;
  
  // Create a single-use client with shorter timeout for quick reachability test
  const testClient = new pkg.Client({
    host: config.host,
    user: config.user,
    password: config.password,
    database: config.database,
    connectionTimeoutMillis: 15000, // 15 seconds timeout
  });

  testClient.connect()
    .then(async () => {
      await testClient.query('SELECT 1;');
      isConnectionTested = true;
      isConnectionFailed = false;
      console.log('🎉 [SQL DATABASE] Verified: PostgreSQL database is reachable and active.');
      testClient.end().catch(() => {});
    })
    .catch((err) => {
      isConnectionFailed = true;
      isConnectionTested = true;
      console.warn('⚠️ [SQL DATABASE] Warning: PostgreSQL was found configured but could not be reached. Error:', err.message);
      console.warn('⚠️ [SQL DATABASE] Raya Bingo will automatically fall back to the robust JSON local storage engine.');
      testClient.end().catch(() => {});
    });
}

export function getPool() {
  if (!poolInstance && isSqlDbAvailable()) {
    try {
      const config = getPostresConfig()!;
      console.log(`[SQL DATABASE POOL] Initializing connection pool to PostgreSQL at ${config.host}...`);
      poolInstance = new Pool({
        host: config.host,
        user: config.user,
        password: config.password,
        database: config.database,
        connectionTimeoutMillis: 15000,
        idleTimeoutMillis: 30000,
        max: 20
      });

      poolInstance.on('error', (err: any) => {
        console.error('Unexpected error on idle PostgreSQL client pool:', err);
        isConnectionFailed = true;
        isConnectionTested = true;
      });
    } catch (err) {
      console.error('[SQL DATABASE ERROR] Failed to instantiate connection pool:', err);
      poolInstance = null;
    }
  }
  return poolInstance;
}

export function getDb() {
  if (!dbInstance && isSqlDbAvailable()) {
    const pool = getPool();
    if (pool) {
      try {
        dbInstance = drizzle(pool, { schema });
        console.log('[SQL DATABASE DRIZZLE] Successfully initialized Drizzle ORM client.');
      } catch (err) {
        console.error('[SQL DATABASE ERROR] Failed to initialize Drizzle model client:', err);
        dbInstance = null;
      }
    }
  }
  return dbInstance;
}

export const dbConnection = {
  get db() {
    return getDb();
  },
  get pool() {
    return getPool();
  },
  isAvailable: isSqlDbAvailable
};
