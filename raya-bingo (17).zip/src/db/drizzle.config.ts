/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { defineConfig } from "drizzle-kit";
import * as dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

// Load environment variables from .env file
dotenv.config();

const sqlHost = process.env.SQL_HOST;
const sqlDbName = process.env.SQL_DB_NAME;
const user = process.env.SQL_ADMIN_USER;
const password = process.env.SQL_ADMIN_PASSWORD;

if (!sqlHost) {
  console.warn("SQL_HOST is not set in environment variables.");
}
if (!sqlDbName) {
  console.warn("SQL_DB_NAME is not set in environment variables.");
}
if (!user) {
  console.warn("SQL_ADMIN_USER is not set in environment variables.");
}
if (!password) {
  console.warn("SQL_ADMIN_PASSWORD is not set in environment variables.");
}

// Derive __dirname in ES modules / common environments safely
const dname = typeof __dirname !== 'undefined' 
  ? __dirname 
  : path.dirname(fileURLToPath(import.meta.url));

let dbCredentials: any = {
  host: sqlHost || 'localhost',
  user: user || 'postgres',
  password: password || 'postgres',
  database: sqlDbName || 'rayabingo',
  ssl: false,
};

if (sqlHost && sqlHost.startsWith('/')) {
  const encodedPassword = encodeURIComponent(password || '');
  dbCredentials = {
    url: `postgresql://${user}:${encodedPassword}@/${sqlDbName}?host=${sqlHost}`,
  };
}

export default defineConfig({
  schema: path.resolve(dname, "schema.ts"),
  out: path.resolve(dname, "../../drizzle"), // Output migrations folder to root
  dialect: "postgresql",
  schemaFilter: ["public"],
  dbCredentials,
  verbose: true,
});
