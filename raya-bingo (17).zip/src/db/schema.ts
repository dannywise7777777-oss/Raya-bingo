/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { relations } from 'drizzle-orm';
import { 
  pgTable, 
  serial, 
  text, 
  integer, 
  timestamp, 
  doublePrecision, 
  boolean,
  index,
  uniqueIndex
} from 'drizzle-orm/pg-core';

// --- USERS TABLE ---
export const users = pgTable('users', {
  id: text('id').primaryKey(), // We use user-XXX or admin-1 ids
  name: text('name').notNull(),
  phoneNumber: text('phone_number').notNull().unique(),
  telegramId: text('telegram_id').unique(),
  username: text('username'),
  firstName: text('first_name'),
  balance: doublePrecision('balance').default(0).notNull(),
  role: text('role').notNull().default('user'), // 'user' | 'admin'
  status: text('status').notNull().default('active'), // 'active' | 'suspended' | 'banned'
  otpVerified: boolean('otp_verified').default(false).notNull(),
  password: text('password').notNull(),
  otpCode: text('otp_code'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  walletLocked: boolean('wallet_locked').default(false).notNull()
}, (table) => {
  return {
    phoneIdx: uniqueIndex('users_phone_idx').on(table.phoneNumber),
    tgIdx: index('users_tg_idx').on(table.telegramId),
    roleIdx: index('users_role_idx').on(table.role)
  };
});

// --- BINGO ROOMS TABLE ---
export const rooms = pgTable('rooms', {
  id: text('id').primaryKey(), // 'room-10', 'room-20', etc.
  name: text('name').notNull(),
  entryFee: doublePrecision('entry_fee').notNull(),
  prizePool: doublePrecision('prize_pool').default(0).notNull(),
  commission: doublePrecision('commission').default(0).notNull(),
  status: text('status').notNull().default('waiting'), // 'waiting' | 'playing' | 'completed'
  activePlayers: integer('active_players').default(0).notNull(),
  maxPlayers: integer('max_players').default(1000).notNull(),
  updatedAt: timestamp('updated_at').defaultNow()
});

// --- WALLETS TABLE (Dedicated Wallet Audit Ledger for multi-level defense) ---
export const wallets = pgTable('wallets', {
  id: serial('id').primaryKey(),
  userId: text('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull().unique(),
  address: text('address'),
  balance: doublePrecision('balance').default(0).notNull(),
  locked: boolean('locked').default(false).notNull(),
  lastUpdated: timestamp('last_updated').defaultNow()
}, (table) => {
  return {
    walletUserIdx: uniqueIndex('wallets_user_id_idx').on(table.userId)
  };
});

// --- GAMES TABLE (Bingo Live sessions tracker) ---
export const games = pgTable('games', {
  id: text('id').primaryKey(),
  roomId: text('room_id').references(() => rooms.id).notNull(),
  status: text('status').notNull().default('waiting'), // 'waiting' | 'playing' | 'completed'
  calledNumbers: text('called_numbers').notNull().default('[]'), // Stringified array: JSON.stringify(number[])
  winnerUserId: text('winner_user_id'),
  prizePaid: doublePrecision('prize_paid').default(0).notNull(),
  commissionCollected: doublePrecision('commission_collected').default(0).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull()
}, (table) => {
  return {
    gameRoomIdx: index('games_room_idx').on(table.roomId)
  };
});

// --- BINGO CARDS TABLE (Active Card configurations) ---
export const cards = pgTable('cards', {
  id: integer('id').primaryKey(), // 1 to 1000 pre-generated unique configs
  numbers: text('numbers').notNull(), // Stringified grid JSON
  reservedBy: text('reserved_by').references(() => users.id),
  roomId: text('room_id').references(() => rooms.id)
}, (table) => {
  return {
    cardReservedIdx: index('cards_reserved_idx').on(table.reservedBy),
    cardRoomIdx: index('cards_room_idx').on(table.roomId)
  };
});

// --- TRANSACTIONS TABLE (Core Wallet Ledger - Deposits and Withdrawals) ---
export const transactions = pgTable('transactions', {
  id: text('id').primaryKey(),
  userId: text('user_id').references(() => users.id).notNull(),
  type: text('type').notNull(), // 'deposit' | 'withdrawal' | 'transfer_out' | 'transfer_in' | 'game_entry' | 'win' | 'referral_bonus'
  amount: doublePrecision('amount').notNull(),
  status: text('status').notNull().default('pending'), // 'pending' | 'approved' | 'rejected' | 'completed'
  method: text('method').notNull().default('telebirr'), // 'telebirr' | 'chapa'
  referenceNumber: text('reference_number'),
  phoneNumber: text('phone_number'),
  comment: text('comment'),
  createdAt: timestamp('created_at').defaultNow().notNull()
}, (table) => {
  return {
    txUserIdx: index('tx_user_idx').on(table.userId),
    txRefIdx: index('tx_ref_idx').on(table.referenceNumber),
    txStatusIdx: index('tx_status_idx').on(table.status)
  };
});

// --- REFERRALS SYSTEM ---
export const referrals = pgTable('referrals', {
  id: serial('id').primaryKey(),
  referrerUserId: text('referrer_user_id').references(() => users.id).notNull(),
  referredUserId: text('referred_user_id').references(() => users.id).notNull().unique(),
  rewardAmount: doublePrecision('reward_amount').default(0).notNull(),
  status: text('status').notNull().default('completed'), // 'pending' | 'completed'
  createdAt: timestamp('created_at').defaultNow().notNull()
}, (table) => {
  return {
    referrerIdx: index('referrals_referrer_idx').on(table.referrerUserId),
    referredIdx: uniqueIndex('referrals_referred_idx').on(table.referredUserId)
  };
});

// --- AUDIT LOGS ---
export const auditLogs = pgTable('audit_logs', {
  id: serial('id').primaryKey(),
  action: text('action').notNull(),
  userId: text('user_id'),
  details: text('details'),
  timestamp: timestamp('timestamp').defaultNow().notNull()
}, (table) => {
  return {
    auditActionIdx: index('audit_action_idx').on(table.action),
    auditUserIdx: index('audit_user_idx').on(table.userId)
  };
});

// --- ANNOUNCEMENTS ---
export const announcements = pgTable('announcements', {
  id: serial('id').primaryKey(),
  title: text('title').notNull(),
  content: text('content').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull()
});

// --- GAME RESULTS TABLE (Historic record of round wins) ---
export const gameResults = pgTable('game_results', {
  id: serial('id').primaryKey(),
  gameId: text('game_id').references(() => games.id).notNull(),
  userId: text('user_id').references(() => users.id).notNull(),
  cardId: integer('card_id').notNull(),
  wonAmount: doublePrecision('won_amount').notNull(),
  pattern: text('pattern').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull()
}, (table) => {
  return {
    resultUserIdx: index('result_user_idx').on(table.userId),
    resultGameIdx: index('result_game_idx').on(table.gameId)
  };
});

// --- RELATIONSHIPS FOR DRIZZLE ---
export const usersRelations = relations(users, ({ many, one }) => ({
  wallet: one(wallets, {
    fields: [users.id],
    references: [wallets.userId]
  }),
  transactions: many(transactions),
  referralsMade: many(referrals, { relationName: 'referrerRelation' }),
  referralEarned: one(referrals, {
    fields: [users.id],
    references: [referrals.referredUserId],
    relationName: 'referredRelation'
  }),
  auditLogs: many(auditLogs)
}));

export const referralsRelations = relations(referrals, ({ one }) => ({
  referrer: one(users, {
    fields: [referrals.referrerUserId],
    references: [users.id],
    relationName: 'referrerRelation'
  }),
  referred: one(users, {
    fields: [referrals.referredUserId],
    references: [users.id],
    relationName: 'referredRelation'
  })
}));

export const transactionsRelations = relations(transactions, ({ one }) => ({
  user: one(users, {
    fields: [transactions.userId],
    references: [users.id]
  })
}));
