/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface User {
  id: string;
  name: string;
  phoneNumber: string;
  telegramId: string;
  username: string;
  firstName: string;
  balance: number;
  role: 'admin' | 'user';
  status: 'active' | 'suspended' | 'banned';
  otpVerified: boolean;
  createdAt: string;
  password?: string;
}

export interface BingoCard {
  id: number; // 1 to 1000
  numbers: number[][]; // 5x5 grid, where numbers[2][2] is 0 (FREE space)
  reservedBy: string | null; // User ID reserving it
  roomId: string | null; // Room it is playing in
}

export interface BingoRoom {
  id: string;
  name: string;
  entryFee: number; // 10, 20, 50, 100, 200, 500 ETB
  prizePool: number; // Sum of entry fees from active participants minus commission
  commission: number; // 25% of pool
  status: 'waiting' | 'playing' | 'completed';
  activePlayers: number;
  maxPlayers: number;
  gameStartTime?: string;
}

export interface BingoGame {
  id: string;
  roomId: string;
  calledNumbers: number[];
  winnerId: string | null;
  winnerName?: string;
  commissionEarned: number;
  prizeAwarded: number;
  status: 'active' | 'finished';
  createdAt: string;
  playerCards: { [userId: string]: number }; // map userId -> cardId
}

export type TransactionType = 'deposit' | 'withdrawal';
export type TransactionStatus = 'pending' | 'approved' | 'rejected' | 'completed';
export type PaymentMethod = 'telebirr' | 'cbe_birr' | 'bank_transfer';

export interface Transaction {
  id: string;
  userId: string;
  userName: string;
  amount: number;
  type: TransactionType;
  status: TransactionStatus;
  method: PaymentMethod;
  referenceNumber: string;
  phoneNumber: string;
  screenshot?: string;
  createdAt: string;
}

export interface AppNotification {
  id: string;
  userId: string;
  message: string;
  read: boolean;
  type: 'game' | 'payment' | 'system' | 'promo';
  createdAt: string;
}

export interface RevenueRecord {
  id: string;
  gameId: string;
  roomName: string;
  totalPool: number;
  commission: number;
  winnerPrize: number;
  timestamp: string;
}

export interface AuditLog {
  id: string;
  action: string;
  userId: string;
  details: string;
  timestamp: string;
}

export interface ChatMessage {
  id: string;
  userId: string;
  userName: string;
  message: string;
  timestamp: string;
}

export interface TelegramMockMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
  image?: string;
}
