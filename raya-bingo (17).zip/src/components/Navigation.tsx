/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { User, AppNotification } from '../types.js';
import { 
  Coins, 
  User as UserIcon, 
  Bell, 
  LogOut, 
  Shield, 
  Wallet, 
  Gamepad2, 
  MessageSquareCode,
  MessageSquare
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface NavigationProps {
  user: User | null;
  notifications: AppNotification[];
  currentTab: string;
  setTab: (tab: string) => void;
  onLogout: () => void;
  onReadNotif: (id: string) => void;
}

export default function Navigation({ 
  user, 
  notifications, 
  currentTab, 
  setTab, 
  onLogout,
  onReadNotif 
}: NavigationProps) {
  const [showNotifDropdown, setShowNotifDropdown] = useState(false);
  const [showUserDropdown, setShowUserDropdown] = useState(false);

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <>
      <nav className="sticky top-0 z-40 bg-slate-900 border-b border-slate-800 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Ethiopian Flag Accent */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setTab('lobby')}>
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr from-green-600 via-yellow-500 to-red-600 p-[2px] shadow-lg">
              <div className="flex h-full w-full items-center justify-center rounded-[10px] bg-slate-950 font-display font-black text-lg text-yellow-400">
                R
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5 leading-none">
                <span className="font-display font-semibold text-lg tracking-tight text-white">Raya Bingo</span>
                <span className="text-xs bg-emerald-950 text-emerald-400 border border-emerald-800 px-1 rounded">ETB</span>
              </div>
              <span className="text-[10px] text-slate-400 tracking-wider">Play. Win. Celebrate.</span>
            </div>
          </div>

          {/* Navigation Links for Authenticated Users */}
          {user && (
            <div className="hidden md:flex items-center gap-2">
              <button
                onClick={() => setTab('lobby')}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                  currentTab === 'lobby' || currentTab === 'game'
                    ? 'bg-gradient-to-r from-green-900/50 to-slate-800 text-yellow-400 border-b-2 border-yellow-500'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Gamepad2 size={16} />
                <span>Play Bingo</span>
              </button>

              <button
                onClick={() => setTab('wallet')}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                  currentTab === 'wallet'
                    ? 'bg-gradient-to-r from-green-900/50 to-slate-800 text-yellow-400 border-b-2 border-yellow-500'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Wallet size={16} />
                <span>Wallet & Cashier</span>
              </button>

              {user.role === 'admin' && (
                <button
                  onClick={() => setTab('admin')}
                  className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                    currentTab === 'admin'
                      ? 'bg-gradient-to-r from-red-950/40 to-slate-800 text-red-400 border-b-2 border-red-500'
                      : 'text-red-400 hover:bg-slate-800 hover:text-red-300'
                  }`}
                >
                  <Shield size={16} />
                  <span>Admin Panel</span>
                </button>
              )}
            </div>
          )}

          {/* Right Area - Balance + User Profile dropdown */}
          <div className="flex items-center gap-3">
            {user ? (
              <>
                {/* Glowing Balance Card (ALWAYS ETB) */}
                <div 
                  onClick={() => setTab('wallet')}
                  className="flex items-center gap-2 px-3 py-1.5 bg-slate-950 border border-slate-800 hover:border-yellow-500 rounded-xl cursor-pointer transition-all duration-200"
                >
                  <div className="bg-amber-400/10 p-1 rounded-lg">
                    <Coins size={16} className="text-yellow-400 animate-spin-slow" />
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] text-slate-400 leading-none">Wallet Balance</div>
                    <div className="text-sm font-mono font-bold text-yellow-400 leading-tight">
                      {user.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })} <span className="text-[10px] font-sans font-medium text-white">ETB</span>
                    </div>
                  </div>
                </div>

                {/* Notifications Bell */}
                <div className="relative">
                  <button
                    onClick={() => {
                      setShowNotifDropdown(!showNotifDropdown);
                      setShowUserDropdown(false);
                    }}
                    className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 relative focus:outline-none"
                  >
                    <Bell size={20} />
                    {unreadCount > 0 && (
                      <span className="absolute top-1.5 right-1.5 h-4 w-4 bg-red-600 rounded-full flex items-center justify-center text-[10px] font-bold text-white leading-none">
                        {unreadCount}
                      </span>
                    )}
                  </button>

                  <AnimatePresence>
                    {showNotifDropdown && (
                      <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                        className="absolute right-0 mt-2 w-80 bg-slate-950 border border-slate-800 rounded-xl shadow-2xl overflow-hidden z-50"
                      >
                        <div className="px-4 py-3 bg-slate-900 border-b border-slate-800 flex justify-between items-center">
                          <span className="text-xs font-semibold text-white">Notifications</span>
                          <span className="text-[10px] text-slate-400">{unreadCount} unread</span>
                        </div>
                        <div className="max-h-64 overflow-y-auto divide-y divide-slate-800">
                          {notifications.length === 0 ? (
                            <div className="px-4 py-6 text-center text-xs text-slate-500">
                              No notifications yet
                            </div>
                          ) : (
                            notifications.map(notif => (
                              <div 
                                key={notif.id} 
                                className={`p-3 text-xs transition-colors cursor-pointer ${notif.read ? 'bg-slate-950 hover:bg-slate-900' : 'bg-slate-900 hover:bg-slate-850'}`}
                                onClick={() => {
                                  onReadNotif(notif.id);
                                  setShowNotifDropdown(false);
                                }}
                              >
                                <p className="text-slate-200 mb-1">{notif.message}</p>
                                <div className="flex justify-between items-center text-[10px] text-slate-500">
                                  <span>{notif.type.toUpperCase()}</span>
                                  <span>{new Date(notif.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                                </div>
                              </div>
                            ))
                          )}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* Profile Avatar Trigger */}
                <div className="relative">
                  <button
                    onClick={() => {
                      setShowUserDropdown(!showUserDropdown);
                      setShowNotifDropdown(false);
                    }}
                    className="flex items-center gap-1.5 focus:outline-none"
                  >
                    <div className="h-8 w-8 rounded-full bg-slate-700 border border-slate-600 flex items-center justify-center text-slate-200 font-bold hover:bg-slate-600 transition-colors">
                      <UserIcon size={16} />
                    </div>
                  </button>

                  <AnimatePresence>
                    {showUserDropdown && (
                      <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                        className="absolute right-0 mt-2 w-56 bg-slate-950 border border-slate-800 rounded-xl shadow-2xl overflow-hidden z-50"
                      >
                        <div className="px-4 py-3 bg-slate-900 border-b border-slate-800">
                          <p className="text-xs font-semibold text-white truncate">{user.name}</p>
                          <p className="text-[10px] text-slate-400 truncate">{user.phoneNumber || 'Telegram Link Account'}</p>
                        </div>
                        <div className="p-1">
                          <button
                            onClick={() => { setTab('wallet'); setShowUserDropdown(false); }}
                            className="flex w-full items-center gap-2 px-3 py-2 text-xs text-slate-300 hover:bg-slate-800 hover:text-white rounded-lg transition-colors"
                          >
                            <Wallet size={14} />
                            <span>Deposit & Withdrawal</span>
                          </button>
                          {user.role === 'admin' && (
                            <button
                              onClick={() => { setTab('admin'); setShowUserDropdown(false); }}
                              className="flex w-full items-center gap-2 px-3 py-2 text-xs text-red-400 hover:bg-red-950/30 hover:text-red-300 rounded-lg transition-colors"
                            >
                              <Shield size={14} />
                              <span>Admin Console</span>
                            </button>
                          )}
                          <div className="h-[1px] bg-slate-800 my-1" />
                          <button
                            onClick={() => { onLogout(); setShowUserDropdown(false); }}
                            className="flex w-full items-center gap-2 px-3 py-2 text-xs text-slate-400 hover:bg-slate-850 hover:text-white rounded-lg transition-colors"
                          >
                            <LogOut size={14} />
                            <span>Log Out</span>
                          </button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </>
            ) : (
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400 hidden sm:inline">Playing safely from Ethiopia</span>
                <div className="h-5 w-7 bg-slate-800 rounded border border-slate-700 overflow-hidden flex flex-col justify-between">
                  <div className="h-1/3 bg-green-600" />
                  <div className="h-1/3 bg-yellow-500 flex items-center justify-center p-[1px]">
                    <div className="h-full w-full bg-blue-600 rounded-full" />
                  </div>
                  <div className="h-1/3 bg-red-600" />
                </div>
              </div>
            )}
          </div>

        </div>
      </div>
    </nav>
    
      {/* Mobile Bottom Navigation Bar styled to match Raya brand aesthetics */}
      {user && (
        <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-[#090d16] border-t border-slate-800/80 shadow-[0_-8px_30px_rgb(0,0,0,0.5)] flex justify-around items-center h-16 pb-safe px-4" id="mobile_bottom_nav">
          <button
            onClick={() => setTab('lobby')}
            id="mobile_nav_lobby"
            className={`flex flex-col items-center justify-center flex-1 py-1 cursor-pointer transition-all duration-200 ${
              currentTab === 'lobby' || currentTab === 'game' 
                ? 'text-yellow-400 font-bold scale-[1.05]' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Gamepad2 size={20} className={`${currentTab === 'lobby' || currentTab === 'game' ? 'drop-shadow-[0_0_8px_rgba(250,204,21,0.4)]' : ''}`} />
            <span className="text-[10px] tracking-wide mt-1">Play Bingo</span>
          </button>

          <button
            onClick={() => setTab('wallet')}
            id="mobile_nav_wallet"
            className={`flex flex-col items-center justify-center flex-1 py-1 cursor-pointer transition-all duration-200 ${
              currentTab === 'wallet' 
                ? 'text-yellow-400 font-bold scale-[1.05]' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Wallet size={20} className={`${currentTab === 'wallet' ? 'drop-shadow-[0_0_8px_rgba(250,204,21,0.4)]' : ''}`} />
            <span className="text-[10px] tracking-wide mt-1">Wallet</span>
          </button>

          {user.role === 'admin' && (
            <button
              onClick={() => setTab('admin')}
              id="mobile_nav_admin"
              className={`flex flex-col items-center justify-center flex-1 py-1 cursor-pointer transition-all duration-200 ${
                currentTab === 'admin' 
                  ? 'text-red-400 font-bold scale-[1.05]' 
                  : 'text-red-400/60 hover:text-red-300'
              }`}
            >
              <Shield size={20} className={`${currentTab === 'admin' ? 'drop-shadow-[0_0_8px_rgba(248,113,113,0.4)]' : ''}`} />
              <span className="text-[10px] tracking-wide mt-1">Admin</span>
            </button>
          )}
        </div>
      )}
    </>
  );
}
