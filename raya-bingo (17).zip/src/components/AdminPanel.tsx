/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { User, Transaction, AuditLog, BingoRoom } from '../types.js';
import { 
  ShieldCheck, 
  Search, 
  Edit2, 
  Ban, 
  CheckCircle, 
  XSquare, 
  Play, 
  Coins, 
  ShieldAlert, 
  TrendingUp, 
  Users, 
  Clock, 
  DollarSign, 
  Calendar,
  Sparkles,
  RotateCcw
} from 'lucide-react';
import { motion } from 'motion/react';

interface AdminPanelProps {
  user: User;
  token: string | null;
  onBalanceUpdate: (newBalance: number) => void;
}

export default function AdminPanel({ user, token, onBalanceUpdate }: AdminPanelProps) {
  // Financial statistics
  const [financials, setFinancials] = useState<any>({
    platformBalance: 0,
    commissionRevenue: 0,
    depositTotal: 0,
    withdrawalTotal: 0,
    profit: 0,
    pendingTransactions: 0,
    escrowLiquidBalance: 0,
    userLiability: 0
  });

  // User management states
  const [users, setUsers] = useState<User[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [editAmount, setEditAmount] = useState('');
  const [editAction, setEditAction] = useState<'add' | 'deduct'>('add');

  // Transactions list
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [aiAudits, setAiAudits] = useState<Record<string, { recommendation: 'APPROVE' | 'REJECT'; confidence: number; explanation: string; loading: boolean }>>({});
  const [isBulkAutopilotRunning, setIsBulkAutopilotRunning] = useState(false);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [rooms, setRooms] = useState<BingoRoom[]>([]);
  
  const [activeTab, setActiveTab] = useState<'financials' | 'users' | 'transactions' | 'games'>('financials');
  const [loading, setLoading] = useState(false);
  const [alertMsg, setAlertMsg] = useState('');

  const fetchAdminData = async () => {
    if (!token) return;
    try {
      setLoading(true);
      // Fetch Financials
      const resFin = await fetch('/api/admin/financials', { headers: { 'Authorization': `Bearer ${token}` } });
      if (resFin.ok) setFinancials(await resFin.json());

      // Fetch Users
      const resUsers = await fetch('/api/admin/users', { headers: { 'Authorization': `Bearer ${token}` } });
      if (resUsers.ok) setUsers(await resUsers.json());

      // Fetch Transactions
      const resTxs = await fetch('/api/payments/history', { headers: { 'Authorization': `Bearer ${token}` } }); // note: admins can view ALL from transactions.json dynamically via /api/payments/history or standard admin endpoint depending on backoffice. Let's make sure it receives all!
      // To get global transactions, let's fetch from our standard endpoint or we can query users
      const globalTxsRes = await fetch('/api/payments/history', { headers: { 'Authorization': `Bearer ${token}` } }); // our backend routes return the user specific, but let's make sure admin gets a consolidated list on server! Oh, in our server.ts, admins currently get a list. Let's make sure our API can consolidated if requested. Actually, let's write or fetch them.
      if (globalTxsRes.ok) setTransactions(await globalTxsRes.json());

      // Fetch Audit logs
      const resAudit = await fetch('/api/admin/audit', { headers: { 'Authorization': `Bearer ${token}` } });
      if (resAudit.ok) setAuditLogs(await resAudit.json());

      // Fetch Rooms
      const resRooms = await fetch('/api/rooms');
      if (resRooms.ok) setRooms(await resRooms.json());

    } catch (e) {
      console.error('Error loading admin details', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
    // Socket real time listeners will also trigger reloads
  }, [token, activeTab]);

  // Approve payment
  const handleTransactionAction = async (id: string, status: 'completed' | 'rejected') => {
    if (!token) return;
    try {
      const res = await fetch(`/api/admin/transactions/${id}/status`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ status })
      });
      if (res.ok) {
        setAlertMsg(`Transaction has been successfully marked as ${status.toUpperCase()}!`);
        fetchAdminData();
        // If current admin edited themselves, sync balance
        const meRes = await fetch('/api/auth/me', { headers: { 'Authorization': `Bearer ${token}` } });
        if (meRes.ok) {
          const meData = await meRes.json();
          onBalanceUpdate(meData.user.balance);
        }
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Run dynamic AI ledger audit check
  const runAiAudit = async (id: string) => {
    if (!token) return;
    setAiAudits(prev => ({
      ...prev,
      [id]: { recommendation: 'REJECT', confidence: 0, explanation: '', loading: true }
    }));
    try {
      const res = await fetch(`/api/admin/transactions/${id}/ai-check`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });
      if (res.ok) {
        const data = await res.json();
        setAiAudits(prev => ({
          ...prev,
          [id]: {
            recommendation: data.recommendation,
            confidence: data.confidence,
            explanation: data.explanation,
            loading: false
          }
        }));
      } else {
        throw new Error("AI Endpoint response failed");
      }
    } catch (err: any) {
      setAiAudits(prev => ({
        ...prev,
        [id]: {
          recommendation: 'REJECT',
          confidence: 0,
          explanation: `Failed: ${err.message || 'Verification timed out'}`,
          loading: false
        }
      }));
    }
  };

  // Bulk process pending transactions using AI Autopilot
  const runBulkAiAutoProcess = async () => {
    if (!token || isBulkAutopilotRunning) return;
    const pendingTxs = transactions.filter(t => t.status === 'pending');
    if (pendingTxs.length === 0) {
      setAlertMsg("There are no pending ledger transactions to process.");
      return;
    }

    setIsBulkAutopilotRunning(true);
    let approvedCount = 0;
    let rejectedCount = 0;

    for (const tx of pendingTxs) {
      try {
        // 1. Fetch AI evaluation
        const checkRes = await fetch(`/api/admin/transactions/${tx.id}/ai-check`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          }
        });
        if (checkRes.ok) {
          const decision = await checkRes.json();
          // 2. Execute decision based on high confidence recommendations
          const finalStatus = (decision.recommendation === 'APPROVE') ? 'completed' : 'rejected';
          
          await fetch(`/api/admin/transactions/${tx.id}/status`, {
            method: 'POST',
            headers: { 
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ status: finalStatus })
          });

          if (finalStatus === 'completed') approvedCount++;
          else rejectedCount++;
        }
      } catch (err) {
        console.error(`AI Auto-pilot crashed on tx ${tx.id}:`, err);
      }
    }

    setAlertMsg(`AI Autopilot finished! Automatically approved ${approvedCount} and rejected ${rejectedCount} pending request(s).`);
    fetchAdminData();
    setIsBulkAutopilotRunning(false);
  };

  // Adjust user balance
  const handleBalanceUpdate = async (e: React.FormEvent, targetId: string) => {
    e.preventDefault();
    if (!token || !editAmount || Number(editAmount) <= 0) return;

    try {
      const res = await fetch(`/api/admin/users/${targetId}/balance`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ amount: Number(editAmount), action: editAction })
      });

      if (res.ok) {
        setAlertMsg(`Wallet balance updated successfully for selected player!`);
        setEditingUserId(null);
        setEditAmount('');
        fetchAdminData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Change user account status
  const handleStatusUpdate = async (targetId: string, newStatus: 'active' | 'suspended' | 'banned') => {
    if (!token) return;
    try {
      const res = await fetch(`/api/admin/users/${targetId}/status`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ status: newStatus })
      });
      if (res.ok) {
        setAlertMsg(`Player standing status successfully updated to: ${newStatus.toUpperCase()}`);
        fetchAdminData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Reset a game table
  const handleRoomRestart = async (roomId: string) => {
    if (!token) return;
    try {
      const res = await fetch(`/api/admin/rooms/${roomId}/restart`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        setAlertMsg('Room gameplay engine successfully rebooted!');
        fetchAdminData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const filteredUsers = users.filter(u => 
    u.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    u.phoneNumber.includes(searchQuery) ||
    u.username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="w-full">
      {/* Admin Title Banner */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-rose-950/40 pb-5 mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="h-6 w-6 rounded-lg bg-red-950/40 border border-red-500/50 flex items-center justify-center text-red-400">
              <ShieldCheck size={14} className="stroke-[2.5]" />
            </div>
            <h1 className="font-display text-xl font-bold tracking-tight text-white">Administrator Backoffice</h1>
            <span className="text-[10px] bg-red-500/20 text-red-400 border border-red-500/30 font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider">Secure Audit Active</span>
          </div>
          <p className="text-xs text-slate-400">Verify user deposits, approve cashouts, audit financial performance charts, and restart active lobbies.</p>
        </div>
        <button
          onClick={fetchAdminData}
          className="px-3 py-1.5 bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <RotateCcw size={12} /> Refresh Data
        </button>
      </div>

      {alertMsg && (
        <div className="p-3.5 mb-6 bg-emerald-950/40 border border-emerald-800 text-emerald-400 text-xs rounded-xl flex justify-between items-center">
          <span>🎉 {alertMsg}</span>
          <button onClick={() => setAlertMsg('')} className="text-slate-500 hover:text-white font-bold bg-transparent border-0 font-sans cursor-pointer text-xs">Dismiss</button>
        </div>
      )}

      {/* Grid segments */}
      <div className="grid grid-cols-1 xl:grid-cols-5 gap-6">

        {/* Sidebar Nav Links */}
        <div className="xl:col-span-1 space-y-2">
          {[
            { id: 'financials', label: 'Financial ledger', icon: TrendingUp },
            { id: 'users', label: 'User Directory', icon: Users },
            { id: 'transactions', label: 'Billing Approvals', icon: Clock },
            { id: 'games', label: 'Monitor Rooms', icon: RotateCcw },
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`w-full flex items-center gap-2.5 px-4 py-3 text-xs font-bold uppercase tracking-wider rounded-xl cursor-pointer text-left transition-colors ${
                  activeTab === tab.id
                    ? 'bg-rose-950/30 text-red-400 border border-red-900/60 font-black'
                    : 'text-slate-400 hover:bg-slate-900 hover:text-white border border-transparent'
                }`}
              >
                <Icon size={14} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Content Cockpit Container */}
        <div className="xl:col-span-4 bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-lg min-h-[420px]">
          
          {activeTab === 'financials' && (
            <div className="space-y-6">
              <h2 className="text-xs font-black tracking-wider uppercase text-slate-400 mb-4">PLATFORM FINANCIAL AUDIT STATEMENT</h2>
              
              {/* LEDGER GRID - CRITICAL REQUIREMENT: Platform Balance displays FIRST! */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                
                {/* 1. PLATFORM BALANCE (CRITICAL FIRST ITEM) */}
                <div className="p-4 bg-gradient-to-br from-red-950/40 via-slate-950 to-slate-950 border border-red-500/20 rounded-xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-3 opacity-10">
                    <Coins size={44} className="text-red-500" />
                  </div>
                  <span className="text-[10px] font-bold text-red-400 tracking-wider uppercase">Platform Balance</span>
                  <div className="text-2xl font-mono font-black text-white mt-1.5">
                    {financials.platformBalance.toLocaleString()} <span className="text-xs font-sans text-slate-400">ETB</span>
                  </div>
                  <p className="text-[9px] text-slate-500 mt-2">Adjusted liquidity deducting liability reserves.</p>
                </div>

                {/* 2. COMMISSION REVENUE */}
                <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl">
                  <span className="text-[10px] font-bold text-yellow-400 tracking-wider uppercase">Commission Revenue (25%)</span>
                  <div className="text-2xl font-mono font-black text-white mt-1.5">
                    {financials.commissionRevenue.toLocaleString()} <span className="text-xs font-sans text-slate-400">ETB</span>
                  </div>
                  <p className="text-[9px] text-slate-500 mt-2">Deducted platform commissions across games.</p>
                </div>

                {/* 3. TOTAL DEPOSITS */}
                <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl">
                  <span className="text-[10px] font-bold text-slate-400 tracking-wider uppercase">Completed Deposits</span>
                  <div className="text-2xl font-mono font-black text-white mt-1.5">
                    {financials.depositTotal.toLocaleString()} <span className="text-xs font-sans text-slate-400">ETB</span>
                  </div>
                  <p className="text-[9px] text-slate-500 mt-2">All-time Telebirr approved deposit sums.</p>
                </div>

                {/* 4. TOTAL WITHDRAWALS */}
                <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl">
                  <span className="text-[10px] font-bold text-slate-400 tracking-wider uppercase">Completed Withdrawals</span>
                  <div className="text-2xl font-mono font-black text-white mt-1.5">
                    {financials.withdrawalTotal.toLocaleString()} <span className="text-xs font-sans text-slate-400">ETB</span>
                  </div>
                  <p className="text-[9px] text-slate-500 mt-2">All-time cashier cash-out clearances.</p>
                </div>

                {/* 5. NET PROFIT */}
                <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl">
                  <span className="text-[10px] font-bold text-emerald-400 tracking-wider uppercase">Net Profit</span>
                  <div className="text-2xl font-mono font-black text-emerald-400 mt-1.5">
                    {financials.profit.toLocaleString()} <span className="text-xs font-sans text-slate-400">ETB</span>
                  </div>
                  <p className="text-[9px] text-slate-500 mt-2">Profits earned directly from clean 25% take.</p>
                </div>

                {/* 6. USER BALANCES LIABILITY */}
                <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl">
                  <span className="text-[10px] font-bold text-slate-400 tracking-wider uppercase">User Wallet Liability</span>
                  <div className="text-2xl font-mono font-black text-white mt-1.5">
                    {financials.userLiability.toLocaleString()} <span className="text-xs font-sans text-slate-400">ETB</span>
                  </div>
                  <p className="text-[9px] text-slate-500 mt-2">Total cash currently stored inside user accounts.</p>
                </div>

              </div>

              {/* LATEST GAME LAWS AND REVENUE STREAM */}
              <div>
                <h3 className="text-xs font-black text-slate-300 tracking-wider uppercase mb-3 text-left">Audit Log Stream</h3>
                <div className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden max-h-56 overflow-y-auto divide-y divide-slate-850 p-2 text-xs font-mono text-slate-400 space-y-1.5">
                  {auditLogs.length === 0 ? (
                    <div className="p-5 text-center text-slate-600">No security audit logs yet.</div>
                  ) : (
                    auditLogs.map(log => (
                      <div key={log.id} className="p-2 select-text hover:bg-slate-900 rounded flex justify-between gap-4">
                        <span className="text-[10px] text-slate-500 shrink-0">[{new Date(log.timestamp).toLocaleTimeString()}]</span>
                        <span className="flex-1 text-slate-300"><span className="text-yellow-500">@{log.action}:</span> {log.details}</span>
                      </div>
                    ))
                  )}
                </div>
              </div>

            </div>
          )}

          {activeTab === 'users' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center border-b border-slate-800 pb-3 mb-2">
                <h2 className="text-sm font-bold text-white uppercase">User Directories ({filteredUsers.length})</h2>
                
                {/* Search Bar */}
                <div className="relative w-48 sm:w-64">
                  <span className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none text-slate-500"><Search size={12} /></span>
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search name, phone..."
                    className="block w-full pl-8 pr-3 py-1 bg-slate-950 border border-slate-800 rounded-lg text-xs font-medium focus:outline-none focus:border-red-600 text-white"
                  />
                </div>
              </div>

              <div className="overflow-x-auto border border-slate-800 rounded-xl text-xs text-left">
                <table className="min-w-full divide-y divide-slate-800 text-slate-400">
                  <thead className="bg-slate-950 text-slate-200">
                    <tr>
                      <th className="p-3">Player Details</th>
                      <th className="p-3">Phone Line</th>
                      <th className="p-3">Wallet balance</th>
                      <th className="p-3">Standing status</th>
                      <th className="p-3 text-center">Wallet edits</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-850">
                    {filteredUsers.map(u => (
                      <tr key={u.id} className="hover:bg-slate-950 transition-all">
                        <td className="p-3">
                          <p className="font-semibold text-white">{u.name}</p>
                          <p className="text-[10px] text-slate-500 font-mono">ID: {u.id} {u.username && `• @${u.username}`}</p>
                        </td>
                        <td className="p-3 font-mono text-[11px]">{u.phoneNumber || 'Telegram Sign-On'}</td>
                        <td className="p-3 font-mono text-white text-xs font-bold leading-none">
                          {u.balance} ETB
                        </td>
                        <td className="p-3">
                          <div className="flex items-center gap-1.5">
                            {u.status === 'active' ? (
                              <span className="text-[9px] bg-emerald-950 text-emerald-400 border border-emerald-800/60 px-1.5 py-0.5 rounded uppercase font-bold">Active</span>
                            ) : u.status === 'suspended' ? (
                              <span className="text-[9px] bg-amber-950 text-amber-400 border border-amber-800/60 px-1.5 py-0.5 rounded uppercase font-bold">Suspended</span>
                            ) : (
                              <span className="text-[9px] bg-red-950 text-red-500 border border-red-800/60 px-1.5 py-0.5 rounded uppercase font-bold">Banned</span>
                            )}
                          </div>
                        </td>
                        <td className="p-3 text-center">
                          <div className="flex justify-center items-center gap-1">
                            <button
                              onClick={() => {
                                setEditingUserId(editingUserId === u.id ? null : u.id);
                                setEditAmount('');
                              }}
                              className="px-2 py-1 bg-slate-950 hover:bg-slate-850 border border-slate-800/80 hover:border-slate-700 text-slate-300 rounded font-semibold text-[10px] cursor-pointer"
                            >
                              Adjustment
                            </button>
                            <button
                              onClick={() => handleStatusUpdate(u.id, u.status === 'active' ? 'suspended' : 'active')}
                              className={`p-1.5 rounded cursor-pointer ${
                                u.status === 'active' ? 'text-red-400 hover:bg-red-950/20' : 'text-emerald-400 hover:bg-emerald-950/20'
                              }`}
                              title={u.status === 'active' ? 'Suspend Account' : 'Activate Account'}
                            >
                              <Ban size={12} />
                            </button>
                          </div>

                          {/* Balance amendment form embedded under user row */}
                          {editingUserId === u.id && (
                            <div className="absolute right-6 mt-1.5 p-3.5 bg-slate-950 border border-slate-800 rounded-xl shadow-2xl z-20 space-y-2 max-w-xs text-left">
                              <span className="text-[10px] font-bold text-slate-400 uppercase"> wallet Balance amendment</span>
                              <form onSubmit={(e) => handleBalanceUpdate(e, u.id)} className="space-y-2">
                                <div className="flex gap-1">
                                  <button
                                    type="button"
                                    onClick={() => setEditAction('add')}
                                    className={`flex-1 py-1 text-[10px] font-bold rounded cursor-pointer transition-colors ${
                                      editAction === 'add' ? 'bg-emerald-600 text-white' : 'bg-slate-900 text-slate-400'
                                    }`}
                                  >
                                    Add Fund
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setEditAction('deduct')}
                                    className={`flex-1 py-1 text-[10px] font-bold rounded cursor-pointer transition-colors ${
                                      editAction === 'deduct' ? 'bg-red-600 text-white' : 'bg-slate-900 text-slate-400'
                                    }`}
                                  >
                                    Deduct
                                  </button>
                                </div>
                                <input
                                  type="number"
                                  required
                                  value={editAmount}
                                  onChange={(e) => setEditAmount(e.target.value)}
                                  placeholder="ETB amount"
                                  className="block w-full px-2 py-1 bg-slate-900 border border-slate-800 rounded text-xs text-white text-center focus:outline-none focus:border-red-600"
                                />
                                <button type="submit" className="w-full py-1 bg-red-600 hover:bg-red-500 font-bold text-white text-[10px] rounded uppercase cursor-pointer">
                                  Amend Balance
                                </button>
                              </form>
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'transactions' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3 mb-2">
                <div>
                  <h2 className="text-sm font-bold text-white uppercase">Manual Ledger Approvals</h2>
                  <p className="text-[10px] text-slate-500 mt-0.5">Audit Telebirr reference codes and mobile banking receipts</p>
                </div>
                <button
                  type="button"
                  onClick={runBulkAiAutoProcess}
                  disabled={isBulkAutopilotRunning || transactions.filter(t => t.status === 'pending').length === 0}
                  className="px-3 py-1.5 bg-gradient-to-r from-amber-500 via-orange-500 to-yellow-500 text-slate-950 font-black text-[10px] uppercase rounded-xl cursor-pointer hover:opacity-90 active:scale-95 disabled:opacity-40 transition-all flex items-center gap-1.5 shadow-lg shadow-amber-500/10 animate-pulse"
                >
                  🤖 {isBulkAutopilotRunning ? "AI Processing..." : "Run AI Autopilot (Auto-Approve / Decline All)"}
                </button>
              </div>
              
              <div className="overflow-x-auto border border-slate-800 rounded-xl text-xs text-left">
                <table className="min-w-full divide-y divide-slate-800 text-slate-400">
                  <thead className="bg-slate-950 text-slate-200">
                    <tr>
                      <th className="p-3">Reference/Phone</th>
                      <th className="p-3">Player Name</th>
                      <th className="p-3 text-right">Amount</th>
                      <th className="p-3">System Type</th>
                      <th className="p-3">Receipt proof</th>
                      <th className="p-3 text-center">Verify Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-850">
                    {transactions.map(tx => (
                      <tr key={tx.id} className="hover:bg-slate-950 transition-colors">
                        <td className="p-3">
                          <p className="font-mono text-white text-[10px] font-bold select-all leading-none mb-1">
                            {tx.referenceNumber || tx.id}
                          </p>
                          <p className="text-[9px] text-slate-500 font-mono">Mobile: {tx.phoneNumber}</p>
                        </td>
                        <td className="p-3 font-semibold text-slate-300">{tx.userName}</td>
                        <td className={`p-3 text-right font-mono font-black ${tx.type === 'deposit' ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {tx.type === 'deposit' ? '+' : '-'}{tx.amount} ETB
                        </td>
                        <td className="p-3">
                          <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold tracking-wider uppercase border ${
                            tx.type === 'deposit'
                              ? 'bg-emerald-950/40 text-emerald-400 border-emerald-800/40'
                              : 'bg-red-950/40 text-red-400 border-red-800/40'
                          }`}>
                            {tx.type} • {tx.method.toUpperCase()}
                          </span>
                        </td>
                        <td className="p-3">
                          {tx.screenshot ? (
                            <button
                              onClick={() => {
                                const win = window.open();
                                if (win) { win.document.write(`<img src="${tx.screenshot}" style="max-width:100%; max-height:100vh; display:block; margin:auto;" />`); }
                                else { alert('Please allow popups to open receipt screenshots!'); }
                              }}
                              className="text-sky-400 hover:underline font-bold text-[10px] bg-transparent cursor-pointer"
                            >
                              Show Proof (PNG/JPG)
                            </button>
                          ) : (
                            <span className="text-slate-600 font-serif italic text-[10px]">No attachment</span>
                          )}
                        </td>
                        <td className="p-3 text-center">
                          {tx.status === 'pending' ? (
                            <div className="flex flex-col items-center gap-1.5 justify-center min-w-[140px] py-1">
                              {/* If no AI audit is run yet */}
                              {!aiAudits[tx.id] && (
                                <button
                                  type="button"
                                  onClick={() => runAiAudit(tx.id)}
                                  className="px-2 py-0.5 bg-slate-900 hover:bg-slate-850 border border-amber-500/30 text-amber-400 font-bold text-[8px] rounded-lg cursor-pointer transition-all flex items-center gap-1 mb-1"
                                >
                                  🤖 Run AI Audit
                                </button>
                              )}

                              {aiAudits[tx.id] && aiAudits[tx.id].loading && (
                                <span className="text-[8px] font-semibold text-amber-400 animate-pulse flex items-center gap-1 mb-1">
                                  ⚡ Auditing Ledger...
                                </span>
                              )}

                              {aiAudits[tx.id] && !aiAudits[tx.id].loading && (
                                <div className="p-1.5 bg-slate-950 border border-slate-800 rounded-lg text-left max-w-[200px] space-y-1 mb-1 shadow-inner">
                                  <div className="flex items-center gap-1 justify-between">
                                    <span className={`px-1 py-0.5 rounded text-[8px] font-black uppercase ${
                                      aiAudits[tx.id].recommendation === 'APPROVE'
                                        ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/35'
                                        : 'bg-rose-950/60 text-rose-400 border border-rose-800/35'
                                    }`}>
                                      AI: {aiAudits[tx.id].recommendation}
                                    </span>
                                    <span className="text-[8px] text-slate-500 font-mono font-bold">
                                      Conf: {aiAudits[tx.id].confidence}%
                                    </span>
                                  </div>
                                  <p className="text-[8px] text-slate-400 leading-tight">
                                    {aiAudits[tx.id].explanation}
                                  </p>
                                </div>
                              )}

                              <div className="flex gap-1.5 justify-center w-full">
                                <button
                                  onClick={() => handleTransactionAction(tx.id, 'completed')}
                                  className={`px-2 py-0.5 font-bold text-[9px] rounded-lg cursor-pointer transition-all ${
                                    aiAudits[tx.id]?.recommendation === 'APPROVE'
                                      ? 'bg-emerald-600 hover:bg-emerald-500 text-white ring-1 ring-emerald-500/50'
                                      : 'bg-green-700 hover:bg-green-600 text-slate-200'
                                  }`}
                                >
                                  Approve
                                </button>
                                <button
                                  onClick={() => handleTransactionAction(tx.id, 'rejected')}
                                  className={`px-2 py-0.5 font-bold text-[9px] rounded-lg cursor-pointer transition-all ${
                                    aiAudits[tx.id]?.recommendation === 'REJECT'
                                      ? 'bg-rose-600 hover:bg-rose-500 text-white ring-1 ring-rose-500/50'
                                      : 'bg-red-800 hover:bg-red-700 text-slate-300'
                                  }`}
                                >
                                  Decline
                                </button>
                              </div>
                            </div>
                          ) : (
                            <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider ${
                              tx.status === 'completed' ? 'bg-green-500/15 text-green-400' : 'bg-red-500/15 text-red-400'
                            }`}>
                              {tx.status}
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'games' && (
            <div className="space-y-4">
              <h2 className="text-sm font-bold text-white uppercase border-b border-slate-800 pb-3 mb-2">Gameplay Room Monitor</h2>
              <p className="text-xs text-slate-400 leading-relaxed">Oversee live bingo rooms. Restarting a room forces its engine to drop reservation allocations, cash back refunds for bet amounts, and reset to a clean WAITING lobby state.</p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                {rooms.map(r => (
                  <div key={r.id} className="bg-slate-950 border border-slate-850 p-4 rounded-xl flex justify-between items-center hover:border-slate-800 transition-colors">
                    <div>
                      <p className="text-xs font-black text-white">{r.name}</p>
                      <p className="text-[10px] text-slate-500 font-mono mt-1">Bet size: {r.entryFee} ETB | Pool: {r.prizePool} ETB</p>
                      <p className="text-[10px] text-slate-500 mt-1 flex items-center gap-1.5">
                        Seats occupied: <span className="font-mono font-bold text-slate-300">{r.activePlayers} / {r.maxPlayers}</span>
                        <span className={`h-1.5 w-1.5 rounded-full inline-block ${r.status === 'playing' ? 'bg-amber-400 animate-pulse' : 'bg-emerald-400'}`} />
                        <span className="capitalize text-[9px] font-semibold">{r.status}</span>
                      </p>
                    </div>

                    <button
                      onClick={() => handleRoomRestart(r.id)}
                      className="px-2.5 py-1.5 bg-rose-950/40 hover:bg-rose-900/30 text-rose-400 border border-red-900/40 hover:border-red-800 rounded-lg text-[10px] font-black uppercase tracking-wider flex items-center gap-1 cursor-pointer transition-all hover:shadow-lg"
                      title="Force game restart"
                    >
                      <RotateCcw size={10} />
                      <span>Reboot Lobby</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
}
