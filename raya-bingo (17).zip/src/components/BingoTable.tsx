/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useMemo } from 'react';
import { User, BingoRoom, BingoCard, ChatMessage } from '../types.js';
import { 
  Check, 
  Gamepad2, 
  Volume2, 
  VolumeX, 
  Send, 
  MessageSquare, 
  Users, 
  Sparkles, 
  AlertTriangle,
  PlayCircle,
  Clock,
  LogOut,
  Trophy,
  Activity,
  Search,
  Shuffle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { io, Socket } from 'socket.io-client';

// Extremely robust fetch with automatic retry and exponential backoff to handle iframe micro-disconnects/transient errors
const robustFetch = async (url: string, options?: RequestInit, retries = 3, delay = 500): Promise<Response> => {
  try {
    const response = await fetch(url, options);
    // If we encounter a server error (e.g., 502/503/504 gateway anomalies or scale delays)
    if (!response.ok && response.status >= 500 && retries > 0) {
      console.warn(`Server responded with temporary status ${response.status}. Retrying robustFetch... (${retries} retries left)`);
      await new Promise(resolve => setTimeout(resolve, delay));
      return robustFetch(url, options, retries - 1, delay * 2);
    }
    return response;
  } catch (error) {
    if (retries > 0) {
      console.warn(`Connection failed fetching ${url}: ${error}. Automatically retrying... (${retries} retries left)`);
      await new Promise(resolve => setTimeout(resolve, delay));
      return robustFetch(url, options, retries - 1, delay * 2);
    }
    throw error;
  }
};

const LOCALIZATION = {
  en: {
    back: "← Back",
    refresh: "Refresh",
    mainWallet: "Main Wallet",
    playWallet: "Play Wallet",
    stake: "Stake",
    countdown: "s",
    seatsFilled: "Seats Filled",
    activePlayers: "Players",
    prizePool: "Derash (Prize)",
    allCards: "All Cards",
    available: "Available",
    taken: "Taken",
    interactiveBoard: "Interactive Board",
    playMode: "Play Mode",
    manual: "Manual",
    autoDaub: "Auto-Daub",
    leaveTable: "Leave Table",
    calledGrid: "Called Balls Grid",
    watchingOnly: "This game round is already playing. Please wait for the next countdown to claim tickets and enter!",
    winnerAnnouncement: "WE HAVE A WINNER!",
    winner: "Winner",
    pattern: "Winning Pattern",
    payout: "Jackpot Payout",
    bulkSelect: "Bulk Select Cards:",
    searchPlaceholder: "Search card serial number (1-1000)...",
    lastCalled: "LAST BALL",
    drawnCount: "Drawn Balls",
    cardSelectedHeader: "BINGO TICKETS REGISTERED",
    registeredPassesStatus: "✓ Live Registered & Synced",
    maleAnnouncerBadge: "Ethiopian Announcer Voice Active (Male)",
    lobbyHeader: "MULTIPLE PLAYERS ACTIVE LOBBIES",
    lobbyDesc: "Select desired bet pool. Lobbies populate with active platform accounts, ensuring 24/7 matchmaking."
  },
  am: {
    back: "← ተመለስ",
    refresh: "አድስ (Refresh)",
    mainWallet: "ዋና የገንዘብ ቦርሳ",
    playWallet: "ለመጫወቻ ቦርሳ",
    stake: "መያዣ (Stake)",
    countdown: "ሰከንድ",
    seatsFilled: "የተያዙ መቀመጫዎች",
    activePlayers: "ንቁ ተጫዋቾች",
    prizePool: "የዙሩ ደራሽ (ሽልማት)",
    allCards: "ሁሉም ካርዶች",
    available: "ክፍት ካርዶች",
    taken: "የተያዙ ካርዶች",
    interactiveBoard: "የመጫወቻ ሰሌዳ",
    playMode: "የጨዋታ ሁኔታ",
    manual: "በእጅ ምልክት ማድረጊያ",
    autoDaub: "አውቶማቲክ (Auto-Daub)",
    leaveTable: "ከጠረጴዛው ውጣ",
    calledGrid: "የወጡ የቁጥሮች ሰሌዳ",
    watchingOnly: "የዚህ ዙር ጨዋታ ተጀምሯል። አዲስ ዙር እስኪጀምር እዚህ ይጠብቁ።",
    winnerAnnouncement: "አሸናፊ ተገኝቷል! ጃክፖት!",
    winner: "አሸናፊ ተጫዋች",
    pattern: "ያሸነፈበት መንገድ",
    payout: "የሽልማት ክፍያ",
    bulkSelect: "በጅምላ ምረጥ:",
    searchPlaceholder: "የካርድ ቁጥር ፈልግ (1-1000)...",
    lastCalled: "የመጨረሻው የወጣው ቁጥር",
    drawnCount: "የወጡ ኳሶች ብዛት",
    cardSelectedHeader: "የተመረጠ የቢንጎ ቲኬት የቀጥታ ምዝገባ",
    registeredPassesStatus: "✓ የቀጥታ ምዝገባዎ ጸድቋል",
    maleAnnouncerBadge: "የአማርኛ ወንድ ድምፅ አንባቢ በርቶል",
    lobbyHeader: "የቀጥታ ባለብዙ ተጫዋች የቢንጎ አዳራሾች",
    lobbyDesc: "የሚጫወቱበትን የገንዘብ መጠን ይምረጡ። ጨዋታዎች በየ30 ሰከንዱ አውቶማቲክ ይጀምራሉ።"
  }
};

interface BingoTableProps {
  user: User;
  token: string | null;
  onBalanceUpdate: (newBalance: number) => void;
  onAddNotif: (msg: string, type: 'payment' | 'game' | 'system') => void;
  setTab: (tab: string) => void;
}

export default function BingoTable({ 
  user, 
  token, 
  onBalanceUpdate, 
  onAddNotif,
  setTab
}: BingoTableProps) {
  // Localization state
  const [lang, setLang] = useState<'en' | 'am'>(() => (localStorage.getItem('raya_lang') as 'en' | 'am') || 'am');
  const t = (key: string) => (LOCALIZATION[lang] as any)[key] || key;

  // Cradle spinning animation state
  const [isSpinningCradle, setIsSpinningCradle] = useState(false);

  // Lobby states
  const [rooms, setRooms] = useState<BingoRoom[]>([]);
  const [selectedRoomId, setSelectedRoomId] = useState<string | null>(null);
  const [availableCards, setAvailableCards] = useState<BingoCard[]>([]);
  
  // Multi-card selection state: list of card IDs (up to 20!)
  const [chosenCardIds, setChosenCardIds] = useState<number[]>([]);
  // Active card data inside game
  const [myCardsData, setMyCardsData] = useState<{ id: number; numbers: number[][] }[]>([]);
  // Active playing card ID shown in the tab view currently
  const [activeCardTabId, setActiveCardTabId] = useState<number | null>(null);
  // Auto-Play (Auto-Daub) setting
  const [autoPlayEnabled, setAutoPlayEnabled] = useState<boolean>(true);
  // Multi-card map containing marked patterns for each card
  const [markedCellsMap, setMarkedCellsMap] = useState<{ [cardId: number]: boolean[][] }>({});

  // Card Search state
  const [cardSearch, setCardSearch] = useState('');
  const [cardFilterTab, setCardFilterTab] = useState<'all' | 'available' | 'reserved'>('all');
  
  // Game states
  const [inGame, setInGame] = useState(false);
  const [players, setPlayers] = useState<any[]>([]);
  const [calledNumbers, setCalledNumbers] = useState<number[]>([]);
  const [lastCalledNumber, setLastCalledNumber] = useState<number | null>(null);
  const [amharicVoiceText, setAmharicVoiceText] = useState('');
  const [countdown, setCountdown] = useState<number | null>(null);

  // Settings
  const [isMuted, setIsMuted] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);

  // Winner modal
  const [gameWinner, setGameWinner] = useState<{ id: string; name: string; pattern: string; prize: number } | null>(null);

  // Spectator mode state
  const [selectedSpectateUserId, setSelectedSpectateUserId] = useState<string | null>(null);

  // Non-blocking premium toast notification state
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(prev => prev === msg ? null : prev);
    }, 3750);
  };
  const [spectateCardData, setSpectateCardData] = useState<{ id: number; numbers: number[][] } | null>(null);
  const [spectatorMarkedCells, setSpectatorMarkedCells] = useState<{ [cardId: number]: boolean[][] }>({});

  const socketRef = useRef<Socket | null>(null);
  const chatScrollRef = useRef<HTMLDivElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const activeAudioSourceRef = useRef<AudioBufferSourceNode | null>(null);
  const activeFetchControllerRef = useRef<AbortController | null>(null);

  // Load Rooms in Lobby
  const fetchRooms = async () => {
    try {
      const res = await robustFetch('/api/rooms');
      if (res.ok) {
        const data = await res.json();
        // Requirement: 10 ETB room always appears first
        const sorted = data.sort((a: BingoRoom, b: BingoRoom) => {
          if (a.entryFee === 10) return -1;
          if (b.entryFee === 10) return 1;
          return a.entryFee - b.entryFee;
        });
        setRooms(sorted);
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    fetchRooms();
    const interval = setInterval(fetchRooms, 10000);
    return () => clearInterval(interval);
  }, []);

  // Fetch available card options on room selection
  const fetchAvailableCards = async (roomId: string) => {
    try {
      const res = await robustFetch(`/api/cards/available?roomId=${roomId}`);
      if (res.ok) {
        const data = await res.json();
        setAvailableCards(data);
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Synchronizes chosen cards automatically with the active room
  const syncCardSelections = async (cardIds: number[]) => {
    if (!selectedRoomId) return;
    try {
      if (cardIds.length === 0) {
        setMyCardsData([]);
        socketRef.current?.emit('room:join', { roomId: selectedRoomId, token, cardIds: [] });
        return;
      }

      const targetRoom = rooms.find(r => r.id === selectedRoomId);
      if (!targetRoom) return;

      const totalFee = targetRoom.entryFee * cardIds.length;
      if (user.balance < totalFee) {
        return;
      }

      // Fetch our playing cards' visual grids
      const cardsData = await Promise.all(cardIds.map(async cid => {
        let cObj = availableCards.find(c => c.id === cid);
        if (!cObj) {
          try {
            const res = await robustFetch(`/api/cards/${cid}`);
            if (res.ok) {
              cObj = await res.json();
            }
          } catch (e) {
            console.error(e);
          }
        }
        return {
          id: cid,
          numbers: cObj ? cObj.numbers : Array(5).fill(null).map(() => Array(5).fill(0))
        };
      }));

      setMyCardsData(cardsData);
      if (cardsData.length > 0) {
        setActiveCardTabId(cardsData[0].id);
      }

      // Active browser AudioContext/Synthesizer auto activation
      try {
        if (!audioContextRef.current) {
          audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
        }
        if (audioContextRef.current && audioContextRef.current.state === 'suspended') {
          audioContextRef.current.resume();
        }
      } catch (ae) {}

      // Emit new card choices to server instantly
      socketRef.current?.emit('room:join', { roomId: selectedRoomId, token, cardIds });
    } catch (err) {
      console.error("Auto sync card choices failed:", err);
    }
  };

  useEffect(() => {
    if (selectedRoomId) {
      fetchAvailableCards(selectedRoomId);
      setChosenCardIds([]);
      setCardSearch('');
      setCardFilterTab('all');
      
      // Auto-connect socket to see the room's live countdown right away!
      connectSocketRoom(selectedRoomId);
    } else {
      // Clean up socket
      if (socketRef.current) {
        socketRef.current.disconnect();
        socketRef.current = null;
      }
      setCountdown(null);
      setChosenCardIds([]);
    }
  }, [selectedRoomId]);

  useEffect(() => {
    if (selectedRoomId && chosenCardIds.length > 0) {
      syncCardSelections(chosenCardIds);
    }
  }, [chosenCardIds, selectedRoomId]);

  // Sync spectator targeted seat and fetch card grid numbers
  useEffect(() => {
    if (inGame && myCardsData.length === 0 && players.length > 0) {
      let activeUser = players[0];
      if (selectedSpectateUserId) {
        const matching = players.find(p => `${p.userId}-${p.cardId}` === selectedSpectateUserId || p.userId === selectedSpectateUserId);
        if (matching) {
          activeUser = matching;
        }
      }

      if (activeUser && activeUser.cardId) {
        const targetSpectateKey = `${activeUser.userId}-${activeUser.cardId}`;
        if (selectedSpectateUserId !== targetSpectateKey) {
          setSelectedSpectateUserId(targetSpectateKey);
        }
        robustFetch(`/api/cards/${activeUser.cardId}`)
          .then(res => {
            if (res.ok) return res.json();
            throw new Error('Ticket load error');
          })
          .then(cardData => {
            if (cardData && cardData.numbers) {
              setSpectateCardData({ id: activeUser.cardId, numbers: cardData.numbers });
            }
          })
          .catch(err => {
            console.error("Spectate fetch failure:", err);
          });
      }
    } else {
      if (selectedSpectateUserId !== null) {
        setSelectedSpectateUserId(null);
      }
      if (spectateCardData !== null) {
        setSpectateCardData(null);
      }
    }
  }, [selectedSpectateUserId, players, inGame, myCardsData.length]);

  // Connect socket on joining Room
  const connectSocketRoom = (roomId: string) => {
    if (socketRef.current) {
      socketRef.current.disconnect();
    }

    // Connect to same hosting port
    socketRef.current = io();

    socketRef.current.on('connect', () => {
      console.log('Socket joined game lobby');
      // Initially join room just to receive broadcasts
      socketRef.current?.emit('room:join', { roomId, token });
    });

    // Handle Countdown
    socketRef.current.on('room:countdown', ({ seconds }) => {
      setCountdown(seconds);
    });

    // Handle Room Updates
    socketRef.current.on('room:updated', ({ room, players }) => {
      setPlayers(players);
    });

    // Handle Game Started
    socketRef.current.on('game:started', async ({ gameId, room, players: sessionPlayers, prizePool }) => {
      setInGame(true);
      setCountdown(null);
      setCalledNumbers([]);
      setLastCalledNumber(null);
      setGameWinner(null);
      setPlayers(sessionPlayers);
      
      // Look up our registered card IDs in this session
      const ourSessionEntries = sessionPlayers.filter(p => p.userId === user.id);
      const ourCardIds = ourSessionEntries.map(p => p.cardId).filter(Boolean) as number[];

      // Fetch our playing cards directly from backend to prevent empty 0 0 0 boards!
      let fetchedMyCards: BingoCard[] = [];
      try {
        const myRes = await robustFetch('/api/cards/my', {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (myRes.ok) {
          fetchedMyCards = await myRes.json();
        }
      } catch (err) {
        console.error("Failed to fetch my exact playing cards on game start:", err);
      }

      // Build card metadata from state
      const cardsData = ourCardIds.map(cid => {
        const cObj = fetchedMyCards.find(c => c.id === cid) || availableCards.find(c => c.id === cid);
        return {
          id: cid,
          numbers: cObj ? cObj.numbers : Array(5).fill(null).map(() => Array(5).fill(0))
        };
      });
      setMyCardsData(cardsData);

      // Initialize marked cells map (FREE space is pre-marked)
      const initialMap: { [cardId: number]: boolean[][] } = {};
      cardsData.forEach(card => {
        const freshMarked = Array(5).fill(null).map(() => Array(5).fill(false));
        freshMarked[2][2] = true; // FREE space
        initialMap[card.id] = freshMarked;
      });
      setMarkedCellsMap(initialMap);

      if (cardsData.length > 0) {
        setActiveCardTabId(cardsData[0].id);
      }

      // Deduct entry fee locally
      onBalanceUpdate(user.balance - (room.entryFee * ourCardIds.length));
    });

    // Handle Number Called
    socketRef.current.on('game:number_called', ({ number, calledNumbers, amharicText }) => {
      setCalledNumbers(calledNumbers);
      setLastCalledNumber(number);
      setAmharicVoiceText(amharicText);

      // Speech Synthesis triggered in Amharic
      speakAmharicVoice(amharicText);

      // Auto-daub if enabled
      if (autoPlayEnabled) {
        setMarkedCellsMap(prev => {
          const nextMap = { ...prev };
          Object.keys(nextMap).forEach(cidStr => {
            const cid = parseInt(cidStr);
            const card = myCardsData.find(c => c.id === cid);
            if (card) {
              const grid = card.numbers;
              const cardMarked = nextMap[cid] ? nextMap[cid].map(row => [...row]) : Array(5).fill(null).map(() => Array(5).fill(false));
              for (let r = 0; r < 5; r++) {
                for (let c = 0; c < 5; c++) {
                  if (grid[r][c] === number) {
                    cardMarked[r][c] = true;
                  }
                }
              }
              nextMap[cid] = cardMarked;
            }
          });
          return nextMap;
        });
      }

      playShortBeep(880, 0.08); // high beep sound
    });

    // Handle Chat Messages
    socketRef.current.on('room:chat_msg', (msg: ChatMessage) => {
      setChatMessages(prev => [...prev, msg]);
    });

    // Handle Game Ended
    socketRef.current.on('game:ended', ({ winnerId, winnerName, pattern, prizePool }) => {
      setGameWinner({
        id: winnerId,
        name: winnerName,
        pattern,
        prize: prizePool
      });

      // Award prize locally if this user won
      if (winnerId === user.id) {
        onBalanceUpdate(user.balance + prizePool);
        onAddNotif(`🎉 You won ${prizePool} ETB with a '${pattern}' pattern!`, 'game');
      }

      playShortBeep(660, 0.4); // victory tone

      // Transition back to selection lobby after 7s to play next round
      setTimeout(() => {
        setInGame(false);
        setGameWinner(null);
        setCalledNumbers([]);
        setLastCalledNumber(null);
        setPlayers([]);
        setChatMessages([]);

        // Ask server for fresh rooms
        if (selectedRoomId) {
          fetchAvailableCards(selectedRoomId);
        }

        if (autoPlayEnabled) {
          const prevCount = chosenCardIds.length > 0 ? chosenCardIds.length : 1;
          setTimeout(() => {
            setAvailableCards(currentAvail => {
              const freshAvail = currentAvail.filter(c => !c.reservedBy);
              const availIds = freshAvail.map(c => c.id);
              const shufflePick = [...availIds].sort(() => 0.5 - Math.random()).slice(0, Math.min(prevCount, availIds.length));
              setChosenCardIds(shufflePick);
              return currentAvail;
            });
          }, 1500);
        } else {
          setChosenCardIds([]);
          setMyCardsData([]);
          setActiveCardTabId(null);
        }
      }, 7000);
    });

    socketRef.current.on('error', (err) => {
      showToast(`Connection issue: ${err}`);
      handleLeaveRoom();
    });
  };

  // Browser-side PCM audio decoder and player for Gemini Speech Modality (24000Hz)
  const playPcmAudio = (base64Pcm: string, sampleRate = 24000) => {
    try {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioContextRef.current;
      
      if (ctx.state === 'suspended') {
        ctx.resume();
      }
      
      const binaryString = window.atob(base64Pcm);
      const len = binaryString.length;
      const numSamples = len / 2;
      const floatBuffer = new Float32Array(numSamples);
      
      for (let i = 0; i < numSamples; i++) {
        const index = i * 2;
        const low = binaryString.charCodeAt(index);
        const high = binaryString.charCodeAt(index + 1);
        let shortVal = low | (high << 8);
        if (shortVal & 0x8000) {
          shortVal = shortVal - 0x10000;
        }
        floatBuffer[i] = shortVal / 32768;
      }
      
      const audioBuffer = ctx.createBuffer(1, numSamples, sampleRate);
      audioBuffer.getChannelData(0).set(floatBuffer);
      
      // Stop and clear any previous active source to guarantee clean transitions
      if (activeAudioSourceRef.current) {
        try {
          activeAudioSourceRef.current.stop();
        } catch (_) {}
        activeAudioSourceRef.current = null;
      }

      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(ctx.destination);
      
      activeAudioSourceRef.current = source;
      source.onended = () => {
        if (activeAudioSourceRef.current === source) {
          activeAudioSourceRef.current = null;
        }
      };

      source.start(0);
    } catch (error) {
      console.error("Error playing PCM audio:", error);
    }
  };

  const speakNativeAmharicFallback = (text: string) => {
    try {
      if ('speechSynthesis' in window) {
        // Chromium/Safari bug unsticking hack
        window.speechSynthesis.resume();
        window.speechSynthesis.cancel();
        
        let utteranceText = text;
        const replacements: [RegExp, string][] = [
          [/ቢ/gi, 'Bee '],
          [/አይ/gi, 'Eye '],
          [/ኤን/gi, 'En '],
          [/ጂ/gi, 'Jee '],
          [/ኦ/gi, 'Oh '],
          [/B/gi, 'B '],
          [/I/gi, 'I '],
          [/N/gi, 'N '],
          [/G/gi, 'G '],
          [/O/gi, 'O '],
          [/ሃያ/g, 'Haya '],
          [/ሰላሳ/g, 'Selasa '],
          [/አርባ/g, 'Arba '],
          [/ሃምሳ/g, 'Hamsa '],
          [/ስድሳ/g, 'Sidsa '],
          [/ሰባ/g, 'Seba '],
          [/አስራ/g, 'Asra '],
          [/አስር/g, 'Asir '],
          [/አንድ/g, 'and'],
          [/ሁለት/g, 'hulet'],
          [/ሶስት/g, 'sost'],
          [/አራት/g, 'arat'],
          [/አምስት/g, 'amist'],
          [/ስድስት/g, 'sidist'],
          [/ሰባት/g, 'sebat'],
          [/ስምንት/g, 'simint'],
          [/ዘጠኝ/g, 'zetegn']
        ];
        replacements.forEach(([regex, repl]) => {
          utteranceText = utteranceText.replace(regex, repl);
        });

        const utterance = new SpeechSynthesisUtterance(utteranceText);
        utterance.rate = 0.85;
        utterance.pitch = 0.7; // Deep professional announcer voice pitch
        
        const voices = window.speechSynthesis.getVoices();
        let selectedVoice = voices.find(v => 
          (v.lang.startsWith('en-') || v.lang.startsWith('am-')) && 
          (v.name.toLowerCase().includes('male') || 
           v.name.toLowerCase().includes('david') || 
           v.name.toLowerCase().includes('mark') || 
           v.name.toLowerCase().includes('google-male') ||
           v.name.toLowerCase().includes('james'))
        );
        if (!selectedVoice) {
          selectedVoice = voices.find(v => 
            !v.name.toLowerCase().includes('female') &&
            !v.name.toLowerCase().includes('zira') &&
            !v.name.toLowerCase().includes('susan') &&
            !v.name.toLowerCase().includes('hazel') &&
            !v.name.toLowerCase().includes('heera') &&
            !v.name.toLowerCase().includes('siri') &&
            !v.name.toLowerCase().includes('samantha')
          );
        }
        if (selectedVoice) {
          utterance.voice = selectedVoice;
        }

        window.speechSynthesis.speak(utterance);
      }
    } catch (e) {
      console.error('System Web Speech synthesis backup failed:', e);
    }
  };

  // Speaks called number amharic letters Spoken Aloud using Gemini Orbit Voice
  const speakAmharicVoice = async (text: string) => {
    if (isMuted) return;

    // Track and abort any current pending fetch before making a new one to prevent overlap or delayed playback issues
    if (activeFetchControllerRef.current) {
      activeFetchControllerRef.current.abort();
      activeFetchControllerRef.current = null;
    }

    // Track current active sound source so we can stop it if a new number is called!
    if (activeAudioSourceRef.current) {
      try {
        activeAudioSourceRef.current.stop();
      } catch (_) {}
      activeAudioSourceRef.current = null;
    }

    try {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.resume();
        window.speechSynthesis.cancel();
      }
    } catch (_) {}

    const controller = new AbortController();
    activeFetchControllerRef.current = controller;

    let fallbackTriggered = false;

    // Trigger local Amharic synthesizer fallback if Gemini TTS API is pending/slow (exceeds 1150ms)
    const timeoutId = setTimeout(() => {
      if (activeFetchControllerRef.current === controller) {
        fallbackTriggered = true;
        console.warn("Gemini speech response slow. Invoking local browser voice fallback...");
        speakNativeAmharicFallback(text);
      }
    }, 1150);

    try {
      const response = await fetch(`/api/tts?text=${encodeURIComponent(text)}`, { signal: controller.signal });

      // Verify the controller is still active representing the current called number
      if (activeFetchControllerRef.current === controller && !fallbackTriggered) {
        clearTimeout(timeoutId);
        if (response.ok) {
          const data = await response.json();
          if (data.base64Audio) {
            playPcmAudio(data.base64Audio);
          } else {
            speakNativeAmharicFallback(text);
          }
        } else {
          speakNativeAmharicFallback(text);
        }
      }
    } catch (e: any) {
      clearTimeout(timeoutId);
      if (e.name !== 'AbortError') {
        console.error('Gemini speech error, falling back to local announcer:', e);
        if (activeFetchControllerRef.current === controller && !fallbackTriggered) {
          speakNativeAmharicFallback(text);
        }
      }
    } finally {
      if (activeFetchControllerRef.current === controller) {
        activeFetchControllerRef.current = null;
      }
    }
  };

  // Synthesizes simple frequency signals
  const playShortBeep = (freq: number, duration: number) => {
    if (isMuted) return;
    try {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioContextRef.current;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch (e) {
      // safe fallback
    }
  };

  // Multi-card selection actions
  const handleToggleCardSelection = (cardId: number) => {
    const targetRoom = rooms.find(r => r.id === selectedRoomId);
    setChosenCardIds(prev => {
      if (prev.includes(cardId)) {
        return prev.filter(id => id !== cardId);
      } else {
        if (targetRoom) {
          const nextCount = prev.length + 1;
          const totalCost = nextCount * targetRoom.entryFee;
          if (user.balance < totalCost) {
            showToast(`Insufficient balance to claim ${nextCount} cards. Each card costs ${targetRoom.entryFee} ETB.`);
          }
        }
        return [...prev, cardId];
      }
    });
  };

  // Spectator cell manual mark
  const handleSpectateCellMark = (cardId: number, r: number, c: number) => {
    if (r === 2 && c === 2) return;
    setSpectatorMarkedCells(prev => {
      const nextMap = { ...prev };
      const cardMarked = nextMap[cardId] ? nextMap[cardId].map(row => [...row]) : Array(5).fill(null).map(() => Array(5).fill(false));
      cardMarked[r][c] = !cardMarked[r][c];
      nextMap[cardId] = cardMarked;
      return nextMap;
    });
    playShortBeep(659, 0.08); // click sound
  };

  // Quick select random cards
  const handleSelectRandomCards = (count: number) => {
    const targetRoom = rooms.find(r => r.id === selectedRoomId);
    if (!targetRoom) return;

    const totalCost = count * targetRoom.entryFee;
    if (user.balance < totalCost) {
      showToast(`Required: ${totalCost} ETB. Your current balance is ${user.balance} ETB.`);
      return;
    }

    const availableIds = availableCards.filter(c => !c.reservedBy).map(c => c.id);
    if (availableIds.length < count) {
      showToast(`Only ${availableIds.length} cards are available in this lobby. Selecting all of them.`);
      setChosenCardIds(availableIds);
      return;
    }

    const shuffled = [...availableIds].sort(() => 0.5 - Math.random());
    setChosenCardIds(shuffled.slice(0, count));
    playShortBeep(523.25, 0.15); // pleasant chime
  };

  // Join Room bet placing
  const handleJoinLobbyRoom = async () => {
    if (!selectedRoomId || chosenCardIds.length === 0) return;

    try {
      const targetRoom = rooms.find(r => r.id === selectedRoomId);
      if (!targetRoom) return;

      const totalFee = targetRoom.entryFee * chosenCardIds.length;
      if (user.balance < totalFee) {
        showToast(`Insufficient balance! Required: ${totalFee} ETB.`);
        setTab('wallet');
        return;
      }

      // Read chosen card grid numbers
      const cardsData = await Promise.all(chosenCardIds.map(async cid => {
        let cObj = availableCards.find(c => c.id === cid);
        if (!cObj) {
          try {
            const res = await robustFetch(`/api/cards/${cid}`);
            if (res.ok) {
              cObj = await res.json();
            }
          } catch (e) {
            console.error(e);
          }
        }
        return {
          id: cid,
          numbers: cObj ? cObj.numbers : Array(5).fill(null).map(() => Array(5).fill(0))
        };
      }));
      setMyCardsData(cardsData);
      if (cardsData.length > 0) {
        setActiveCardTabId(cardsData[0].id);
      }

      // Initialize real socket
      connectSocketRoom(selectedRoomId);

      // Explicitly authorize and wake up browser AudioContext & Speech API via user gesture
      try {
        if ('speechSynthesis' in window) {
          window.speechSynthesis.speak(new SpeechSynthesisUtterance(""));
        }
        if (!audioContextRef.current) {
          audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
        }
        if (audioContextRef.current && audioContextRef.current.state === 'suspended') {
          audioContextRef.current.resume();
        }
      } catch (ae) {
        console.warn("Browser audio gesture activation warning:", ae);
      }

      // Perform actual bet reserve handoff via HTTP socket parameters
      socketRef.current?.emit('room:join', { roomId: selectedRoomId, token, cardIds: chosenCardIds });
      
      showToast(`Confirmed! Joined ${targetRoom.name} with ${chosenCardIds.length} card(s).`);
    } catch (err) {
      console.error(err);
    }
  };

  // Active cell manual mark
  const handleCellMark = (cardId: number, r: number, c: number) => {
    if (!inGame || !myCardsData) return;
    const card = myCardsData.find(c => c.id === cardId);
    if (!card) return;

    // FREE cell is always marked
    if (r === 2 && c === 2) return;

    setMarkedCellsMap(prev => {
      const nextMap = { ...prev };
      const cardMarked = nextMap[cardId] ? nextMap[cardId].map(row => [...row]) : Array(5).fill(null).map(() => Array(5).fill(false));
      cardMarked[r][c] = !cardMarked[r][c]; // toggle mark
      nextMap[cardId] = cardMarked;
      return nextMap;
    });
    playShortBeep(659, 0.08); // click sound
  };

  // Submit in game chat
  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || !socketRef.current) return;
    socketRef.current.emit('game:chat', chatInput);
    setChatInput('');
  };

  const handleLeaveRoom = () => {
    if (socketRef.current) {
      socketRef.current.disconnect();
      socketRef.current = null;
    }
    setInGame(false);
    setSelectedRoomId(null);
    setCountdown(null);
    setChosenCardIds([]);
    setMyCardsData([]);
    setActiveCardTabId(null);
    setCalledNumbers([]);
    setLastCalledNumber(null);
    setPlayers([]);
    setChatMessages([]);
  };

  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [chatMessages]);

  // Card Search handlers
  const handleSearchChange = (val: string) => {
    setCardSearch(val);
  };

  // Set of available card IDs for instant O(1) lookups
  const availableCardIdsSet = useMemo(() => {
    return new Set(availableCards.map(c => c.id));
  }, [availableCards]);

  // Generate full 1,000 card metadata
  const cardGridItems = useMemo(() => {
    return Array.from({ length: 1000 }, (_, i) => {
      const id = i + 1;
      const isAvailable = availableCardIdsSet.has(id);
      return { id, isAvailable };
    });
  }, [availableCardIdsSet]);

  // Displayed grid items based on search filter and tabs
  const displayedGridItems = useMemo(() => {
    return cardGridItems.filter(item => {
      // 1. Tab filtering
      if (cardFilterTab === 'available' && !item.isAvailable) return false;
      if (cardFilterTab === 'reserved' && item.isAvailable) return false;

      // 2. Search query filtering
      if (cardSearch.trim()) {
        const query = cardSearch.trim().toLowerCase();
        const idStr = item.id.toString();
        const isIdMatch = idStr === query || idStr.includes(query);
        const isTextMatch = `card number ${item.id}`.toLowerCase().includes(query);
        return isIdMatch || isTextMatch;
      }

      return true;
    });
  }, [cardGridItems, cardFilterTab, cardSearch]);

  const handleCradleClick = () => {
    if (isSpinningCradle) return;
    setIsSpinningCradle(true);
    
    // Play satisfying mechanical "spin & drop" sounds
    playShortBeep(600, 0.05);
    setTimeout(() => playShortBeep(450, 0.05), 100);
    setTimeout(() => playShortBeep(300, 0.08), 200);
    setTimeout(() => playShortBeep(150, 0.12), 350);

    setTimeout(() => {
      setIsSpinningCradle(false);
      // Select 1 random card
      const availableOnly = availableCards.filter(c => !c.reservedBy && !chosenCardIds.includes(c.id));
      if (availableOnly.length > 0) {
        const randomCard = availableOnly[Math.floor(Math.random() * availableOnly.length)];
        setChosenCardIds(prev => {
          if (prev.includes(randomCard.id)) return prev;
          if (prev.length >= 20) {
            showToast(lang === 'am' ? 'ከ20 በላይ መጫወት አይፈቀድም።' : 'Cannot select more than 20 cards.');
            return prev;
          }
          return [...prev, randomCard.id];
        });
      } else {
        showToast(lang === 'am' ? 'ምንም ክፍት ቲኬቶች የሉም!' : 'No available cards found!');
      }
    }, 1000);
  };

  const handleChooseRandomCard = () => {
    handleSelectRandomCards(1);
  };

  const currentRoomInfo = rooms.find(r => r.id === selectedRoomId);
  const activeCount = inGame ? players.length : (currentRoomInfo?.activePlayers || 0);
  const roomEntryFee = currentRoomInfo?.entryFee || 10;
  const totalPoolRaw = activeCount * roomEntryFee;
  const commissionAmount = totalPoolRaw * 0.25;
  const netPayoutAmount = totalPoolRaw * 0.75;

  return (
    <div className="w-full relative">
      {/* Non-blocking premium toast notification indicator */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            key="custom-toast-notification"
            initial={{ opacity: 0, y: -25, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -25, scale: 0.95 }}
            className="fixed top-8 left-1/2 -translate-x-1/2 z-55 bg-slate-900 border-2 border-orange-500 text-orange-400 font-extrabold px-6 py-3.5 rounded-2xl shadow-2xl flex items-center gap-3 select-none max-w-sm text-center text-xs"
          >
            <div className="h-5 w-5 rounded-full bg-orange-500/10 border border-orange-500/35 flex items-center justify-center shrink-0 text-orange-500 font-mono text-[10px]">
              🔔
            </div>
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        
        {/* VIEW 1: LOBBY (ROOM SELECTOR) */}
        {!selectedRoomId && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-6"
          >
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-md">
              <div className="flex items-center gap-3">
                <div className="bg-emerald-500/10 p-2.5 rounded-xl border border-emerald-500/20 text-emerald-400">
                  <Gamepad2 size={20} className="animate-pulse" />
                </div>
                <div>
                  <h2 className="text-sm font-semibold text-white tracking-wide uppercase">{t('lobbyHeader')}</h2>
                  <p className="text-[10px] text-slate-400">{t('lobbyDesc')}</p>
                </div>
              </div>

              {/* Language toggle selector */}
              <div className="flex items-center gap-1 bg-slate-950 p-1.5 rounded-xl border border-slate-850 shrink-0 select-none">
                <button
                  type="button"
                  onClick={() => {
                    setLang('am');
                    localStorage.setItem('raya_lang', 'am');
                    playShortBeep(523, 0.05);
                  }}
                  className={`px-3 py-1 text-xs font-bold rounded-lg cursor-pointer transition-all ${
                    lang === 'am'
                      ? 'bg-orange-600 text-white font-black shadow'
                      : 'text-slate-500 hover:text-slate-300'
                  }`}
                >
                  አማርኛ
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setLang('en');
                    localStorage.setItem('raya_lang', 'en');
                    playShortBeep(523, 0.05);
                  }}
                  className={`px-3 py-1 text-xs font-bold rounded-lg cursor-pointer transition-all ${
                    lang === 'en'
                      ? 'bg-slate-800 text-white font-black shadow'
                      : 'text-slate-500 hover:text-slate-300'
                  }`}
                >
                  English
                </button>
              </div>
            </div>

            {/* Room Categories columns */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {rooms.map(room => (
                <div 
                  key={room.id}
                  className="bg-slate-900 border border-slate-850 hover:border-slate-700 hover:bg-slate-850 rounded-2xl p-5 shadow-lg flex flex-col justify-between transition-all group relative overflow-hidden"
                >
                  <div className="space-y-4">
                    <div className="flex justify-between items-start">
                      <div>
                        {room.entryFee === 10 && (
                          <span className="text-[9px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-bold px-1.5 py-0.5 rounded uppercase tracking-wider mb-2 block w-fit">
                            {lang === 'am' ? 'የመጀመሪያ ክፍል (10 ብር)' : 'First Room (10 ETB)'}
                          </span>
                        )}
                        <h3 className="font-display font-semibold text-sm text-slate-200 group-hover:text-yellow-400 transition-colors uppercase">{room.name}</h3>
                      </div>
                      <span className="font-mono text-sm font-black text-yellow-400">{room.entryFee} ETB</span>
                    </div>

                    {/* Room Statistics */}
                    <div className="grid grid-cols-2 gap-2 py-3 border-y border-slate-800 text-[10px]">
                      <div>
                        <span className="text-slate-500 block leading-none mb-1">{t('activePlayers')}</span>
                        <span className="font-mono font-bold text-slate-300">{room.activePlayers} {lang === 'am' ? 'ተጫዋች' : 'Players'}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-slate-500 block leading-none mb-1">{t('prizePool')}</span>
                        <span className="font-mono font-bold text-emerald-400">{Number((room.entryFee * room.activePlayers * 0.75).toFixed(2))} <span className="text-[8px] font-sans">ETB</span></span>
                      </div>
                    </div>
                  </div>

                  {room.status === 'playing' ? (
                    <button
                      onClick={() => {
                        setSelectedRoomId(room.id);
                        setInGame(true);
                        setMyCardsData([]);
                        connectSocketRoom(room.id);
                        playShortBeep(523.25, 0.05);
                      }}
                      className="w-full flex items-center justify-center gap-1.5 mt-4 py-2.5 bg-gradient-to-r from-amber-600 to-red-600 hover:from-amber-500 hover:to-red-500 text-white text-xs font-bold uppercase tracking-wider rounded-xl cursor-pointer transition-all shadow-lg active:scale-95 animate-pulse"
                    >
                      <span className="w-1.5 h-1.5 bg-red-400 rounded-full animate-ping mr-1"></span>
                      <span>📺 {lang === 'am' ? 'በቀጥታ ተመልከት (Watch)' : 'Watch Live / Spectate'}</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        setSelectedRoomId(room.id);
                        playShortBeep(523, 0.05);
                      }}
                      className="w-full flex items-center justify-center gap-1.5 mt-4 py-2.5 bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-500 hover:to-orange-400 text-white text-xs font-bold uppercase tracking-wider rounded-xl cursor-pointer transition-all shadow-lg active:scale-95"
                    >
                      <span>{lang === 'am' ? 'ቲኬት ምረጥ' : 'Select Ticket Code'}</span>
                    </button>
                  )}
                </div>
              ))}
            </div>
          </motion.div>
        )}        {/* VIEW 2: CARD SELECTOR (CHOOSE BINGO DECK) */}
        {selectedRoomId && !inGame && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-6"
          >
            {/* Picture 1 Header Row: Left Back, Right Actions */}
            <div className="flex justify-between items-center bg-slate-900 border border-slate-800 p-3 rounded-2xl shadow-md">
              <button
                type="button"
                onClick={() => {
                  setSelectedRoomId(null);
                  playShortBeep(330, 0.05);
                }}
                className="px-4 py-2 bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-semibold cursor-pointer flex items-center gap-1.5 transition-colors"
              >
                {t('back')}
              </button>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setInGame(true);
                    setMyCardsData([]);
                    setChosenCardIds([]);
                    playShortBeep(523, 0.05);
                  }}
                  className="px-4 py-2 bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white rounded-xl text-xs font-bold cursor-pointer flex items-center gap-1.5 transition-colors shadow-lg active:scale-95"
                >
                  📺 {lang === 'am' ? 'በቀጥታ ተመልከት (Spectate)' : 'Spectate / Watch'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    fetchAvailableCards(selectedRoomId);
                    playShortBeep(659, 0.05);
                  }}
                  className="px-4 py-2 bg-[#ff5500] hover:bg-orange-500 text-white rounded-xl text-xs font-bold cursor-pointer flex items-center gap-1.5 transition-colors shadow-lg shadow-orange-900/10 active:scale-95"
                >
                  {t('refresh')}
                </button>
              </div>
            </div>

            {/* Picture 1 HUD Panel: 4 side-by-side rectangular dashboard stats and cradler spinner */}
            <div className="grid grid-cols-2 lg:grid-cols-5 gap-3.5">
              {/* 1. Main Wallet */}
              <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-sm text-center flex flex-col justify-center min-h-[85px]">
                <span className="text-[10px] text-slate-400 font-extrabold uppercase tracking-widest">{t('mainWallet')}</span>
                <span className="text-lg font-mono font-black text-emerald-400 mt-1">{user.balance.toFixed(2)} <span className="text-[10px] font-sans">BR</span></span>
              </div>

              {/* 2. Play Wallet */}
              <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-sm text-center flex flex-col justify-center min-h-[85px]">
                <span className="text-[10px] text-slate-400 font-extrabold uppercase tracking-widest">{t('playWallet')}</span>
                <span className="text-lg font-mono font-black text-slate-400 mt-1">0.00 <span className="text-[10px] font-sans">BR</span></span>
              </div>

              {/* 3. Stake */}
              <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-sm text-center flex flex-col justify-center min-h-[85px]">
                <span className="text-[10px] text-slate-400 font-extrabold uppercase tracking-widest">{t('stake')}</span>
                <span className="text-lg font-mono font-black text-yellow-500 mt-1">
                  {rooms.find(r => r.id === selectedRoomId)?.entryFee || 10} <span className="text-[10px] font-sans">BR</span>
                </span>
              </div>

              {/* 4. Countdown */}
              <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-sm text-center flex flex-col justify-center min-h-[85px] relative overflow-hidden">
                <span className="text-[10px] text-slate-400 font-extrabold uppercase tracking-widest">COUNTDOWN ጊዜ</span>
                <span className={`text-xl font-mono font-black mt-1 ${countdown !== null && countdown <= 10 ? 'text-red-500 animate-pulse' : 'text-yellow-400'}`}>
                  {countdown !== null ? `${countdown} ${t('countdown')}` : `--`}
                </span>
              </div>

              {/* 5. SPIN CRADLE BUTTON (The clickable click enter alternative!) */}
              <div 
                onClick={handleCradleClick}
                className="col-span-2 lg:col-span-1 bg-slate-950 border border-slate-850 hover:border-yellow-500/40 p-3 rounded-2xl text-center flex flex-col items-center justify-center cursor-pointer transition-all hover:bg-slate-900/40 select-none group relative overflow-hidden"
              >
                <div className="relative flex items-center justify-center">
                  <motion.div
                    animate={{ rotate: isSpinningCradle ? 360 : 0 }}
                    transition={{ duration: 1.0, ease: "easeInOut" }}
                    className="h-10 w-10 rounded-full border-2 border-dashed border-yellow-500/50 flex items-center justify-center"
                  >
                    <span className="h-4 w-4 bg-yellow-500 rounded-full animate-bounce" />
                  </motion.div>
                </div>
                <span className="text-[10px] font-extrabold text-white mt-1 uppercase tracking-wider group-hover:text-yellow-400 transition-colors">
                  {lang === 'am' ? 'ክራድል እሽከረክር (እዚህ ይጫኑ)' : 'TAP TO SPIN CRADLE'}
                </span>
                <span className="text-[8px] text-slate-500 mt-0.5">
                  {lang === 'am' ? 'ክራድል በመጫን ይግቡ' : 'Spin to claim card details'}
                </span>
              </div>
            </div>

            {/* Live Payout & Participant Calculator Panel */}
            <div className="bg-slate-950 border-2 border-dashed border-slate-800 p-5 rounded-3xl relative overflow-hidden shadow-inner flex flex-col gap-4">
              <div className="absolute inset-0 bg-gradient-to-r from-emerald-500/5 via-transparent to-amber-500/5 pointer-events-none" />
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 relative z-10">
                <div className="flex gap-3.5 items-center">
                  <div className="h-11 w-11 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex flex-col items-center justify-center text-indigo-400 shrink-0">
                    <Trophy size={20} className="animate-pulse" />
                  </div>
                  <div>
                    <h4 className="text-white text-xs font-black uppercase tracking-wider flex items-center gap-1.5 leading-none">
                      <span>{lang === 'am' ? 'የዙሩ ጠቅላላ ተጫዋቾች እና የሽልማት ሰሌዳ' : 'ROOM PRIZE POOL & TRANSPARENT COMMISSION'}</span>
                      <span className="text-[9px] bg-indigo-500/15 border border-indigo-400/20 px-2 py-0.5 rounded text-indigo-400 font-mono uppercase font-black">25% FEE</span>
                    </h4>
                    <p className="text-[10px] text-slate-400 mt-1.5 leading-relaxed max-w-xl">
                      {lang === 'am' 
                        ? 'ከእያንዳንዱ ዙር ጠቅላላ ክፍያ ላይ 25% የጨዋታ አዘጋጅ ኮሚሽን ተቀንሶ ቀሪው 75% ለአሸናፊው ሙሉ በሙሉ ወዲያውኑ ይከፈላል።' 
                        : 'A 25% table commission is transparently charged to build and scale the system. The remaining 75% of the entry stakes is paid directly to the winner!'}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3 w-full lg:w-auto shrink-0 font-mono">
                  {/* Active Seats */}
                  <div className="bg-slate-900 border border-slate-800/80 p-2.5 rounded-2xl min-w-[100px] text-center">
                    <span className="text-[8px] text-slate-500 block uppercase font-bold tracking-wider leading-none mb-1">{lang === 'am' ? 'ንቁ ተጫዋቾች' : 'Seats Claimed'}</span>
                    <span className="text-sm font-black text-slate-200">{activeCount} {lang === 'am' ? 'ካርድ' : 'Cards'}</span>
                  </div>
                  {/* Commision */}
                  <div className="bg-slate-900 border border-slate-800/80 p-2.5 rounded-2xl min-w-[100px] text-center">
                    <span className="text-[8px] text-slate-500 block uppercase font-bold tracking-wider leading-none mb-1">{lang === 'am' ? 'ኮሚሽን (25%)' : 'Commission (25%)'}</span>
                    <span className="text-xs font-bold text-rose-400">-{commissionAmount.toFixed(2)} <span className="text-[8px] font-sans">BR</span></span>
                  </div>
                  {/* Net prize */}
                  <div className="bg-slate-900 border border-amber-500/20 p-2.5 rounded-2xl min-w-[125px] text-center bg-gradient-to-b from-slate-900 via-slate-900 to-amber-950/20">
                    <span className="text-[8px] text-yellow-500 block uppercase font-black tracking-wider leading-none mb-1">{lang === 'am' ? 'ጭልጥ ሽልማት (75%)' : 'Net Winnings (75%)'}</span>
                    <span className="text-sm font-black text-amber-450">{netPayoutAmount.toFixed(2)} <span className="text-[8px] font-sans">BR</span></span>
                  </div>
                </div>
              </div>
            </div>

            {/* Dashboard & Filtering Grid Controls */}
            <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl space-y-4 shadow-md">
              <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
                
                {/* Search Box */}
                <div className="relative w-full lg:max-w-xs">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500">
                    <Search size={14} />
                  </span>
                  <input
                    type="text"
                    value={cardSearch}
                    onChange={(e) => handleSearchChange(e.target.value)}
                    placeholder={t('searchPlaceholder')}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors"
                  />
                </div>

                {/* Filter Tabs */}
                <div className="flex flex-wrap items-center gap-1.5 bg-slate-950/80 p-1 rounded-xl border border-slate-800/60 w-full lg:w-auto">
                  <button
                    type="button"
                    onClick={() => {
                      setCardFilterTab('all');
                      playShortBeep(440, 0.05);
                    }}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                      cardFilterTab === 'all'
                        ? 'bg-slate-800 text-white shadow-sm'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {t('allCards')} (1,000)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setCardFilterTab('available');
                      playShortBeep(440, 0.05);
                    }}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer flex items-center gap-1 ${
                      cardFilterTab === 'available'
                        ? 'bg-emerald-700 text-white shadow-sm'
                        : 'text-emerald-400/80 hover:text-emerald-400'
                    }`}
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    {t('available')} ({availableCards.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setCardFilterTab('reserved');
                      playShortBeep(440, 0.05);
                    }}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer flex items-center gap-1 ${
                      cardFilterTab === 'reserved'
                        ? 'bg-red-900 border border-red-800/30 text-white shadow-sm'
                        : 'text-slate-500 hover:text-slate-300'
                    }`}
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-red-400" />
                    {t('taken')} ({1000 - availableCards.length})
                  </button>
                </div>

                {/* Bulk choice count controls for up to 20 tickets */}
                <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto pt-3 lg:pt-0">
                  <span className="text-[10px] font-black uppercase text-slate-500 tracking-wider">{t('bulkSelect')}</span>
                  <button
                    type="button"
                    onClick={() => handleSelectRandomCards(1)}
                    className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-white font-mono text-xs font-bold rounded-lg cursor-pointer transition-colors active:scale-95"
                  >
                    +1 {lang === 'am' ? 'ካርድ' : 'Card'}
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSelectRandomCards(5)}
                    className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-white font-mono text-xs font-bold rounded-lg cursor-pointer transition-colors active:scale-95"
                  >
                    +5 {lang === 'am' ? 'ካርድ' : 'Cards'}
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSelectRandomCards(10)}
                    className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-white font-mono text-xs font-bold rounded-lg cursor-pointer transition-colors active:scale-95"
                  >
                    +10 {lang === 'am' ? 'ካርድ' : 'Cards'}
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSelectRandomCards(20)}
                    className="px-2.5 py-1 bg-[#ff5500] hover:bg-orange-500 text-white font-mono text-xs font-bold rounded-lg cursor-pointer transition-colors active:scale-95"
                  >
                    +20 {lang === 'am' ? 'ካርድ' : 'Cards'}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setChosenCardIds([]);
                      playShortBeep(220, 0.1);
                    }}
                    className="px-2.5 py-1 bg-red-950/20 hover:bg-red-900 border border-red-900/35 text-red-400 font-mono text-xs font-bold rounded-lg cursor-pointer transition-colors"
                  >
                    {lang === 'am' ? 'አጥፋ' : 'Reset'}
                  </button>
                </div>
              </div>
            </div>

            {/* Status color coded legend keys */}
            <div className="flex flex-wrap gap-4 text-[10px] text-slate-400 pt-1">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded bg-slate-900 border border-slate-700 block" />
                <span>{lang === 'am' ? 'የማይያዙ ክፍት ቲኬቶች' : 'Available slots in current room'}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded bg-red-950/20 border border-red-950/30 block" />
                <span>{lang === 'am' ? 'የተያዙ (የተሸጡ) ካርዶች' : 'Already Claimed / Reserved'}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded bg-red-600 border border-red-400 block animate-pulse shadow-md shadow-red-500/30" />
                <span>{lang === 'am' ? 'የእርስዎ ንቁ ካርዶች' : 'Your active selected Cards'}</span>
              </div>
            </div>

            {/* Quick countdown warning */}
            {countdown !== null && (
              <div className="p-3.5 bg-[#ff5500]/10 border border-[#ff5500]/30 text-orange-400 text-xs rounded-xl flex items-center gap-2 animate-pulse">
                <Clock size={15} className="animate-spin-slow text-yellow-400 shrink-0" />
                <span>{lang === 'am' ? `ጨዋታው በ ${countdown} ሰከንድ ውስጥ ይጀምራል። አሁን ካርድ መርጠው ይግቡ!` : `Countdown Alert! Next game round starts automatically in ${countdown} seconds! Lock card select below immediately.`}</span>
              </div>
            )}

            {/* Picture 1 Grid: Elongated Orange Board Ticket buttons arranged in exactly 8 columns */}
            {displayedGridItems.length === 0 ? (
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center">
                <p className="text-slate-400 text-sm">No card numbers match your chosen filter. Change search keyword or switch tab.</p>
                <button
                  onClick={() => {
                    handleSearchChange('');
                    setCardFilterTab('all');
                  }}
                  className="mt-3 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold cursor-pointer"
                >
                  Clear Filters
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex justify-between items-center text-[11px] text-slate-500 px-1 font-mono uppercase">
                  <span>SHOWING {displayedGridItems.length} OF 1,000 PASSPORT TICKETS</span>
                  <span>{lang === 'am' ? 'ከ1-1000 ባሉት ካርዶች ላይ ምልክት ያድርጉ (ያልተገደበ)' : 'TAP OR CLICK GRAY TICKETS (UNLIMITED SELECTION)'}</span>
                </div>

                <div className="max-h-[380px] overflow-y-auto pr-1 border border-slate-800/80 rounded-2xl p-4 bg-slate-950/45 shadow-inner">
                  <div className="grid grid-cols-8 gap-2 justify-center">
                    {displayedGridItems.map(item => {
                      const isChosen = chosenCardIds.includes(item.id);
                      return (
                        <button
                          key={item.id}
                          type="button"
                          disabled={false}
                          onClick={() => {
                            handleToggleCardSelection(item.id);
                            playShortBeep(587.33, 0.05);
                          }}
                          className={`min-h-[52px] py-1.5 flex flex-col items-center justify-between rounded-xl border text-xs font-semibold font-mono cursor-pointer transition-all ${
                            isChosen
                              ? 'bg-red-600 border-red-400 text-white shadow-lg shadow-red-500/35 scale-[1.05] z-10 font-black'
                              : item.isAvailable
                                ? 'bg-slate-800 border-slate-700 text-slate-300 hover:border-slate-500 hover:scale-[1.03]'
                                : 'bg-slate-900/60 border-slate-850 text-slate-500 hover:border-slate-500 hover:scale-[1.03] opacity-60'
                          }`}
                          title={`Card Number ${item.id}`}
                        >
                          <span className="text-[8px] opacity-75 font-sans">TICKET</span>
                          <span className="text-xs font-black">{item.id}</span>
                          {isChosen && <span className="text-[8px] text-emerald-200">✓ ok</span>}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* Chosen card detail HUD summary box */}
            <AnimatePresence>
              {chosenCardIds.length > 0 && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="bg-gradient-to-r from-slate-900 to-slate-850 border border-slate-800 p-5 rounded-2xl flex flex-col md:flex-row justify-between items-center gap-4 shadow-xl"
                >
                  <div className="flex items-center gap-4">
                    <div className="h-12 w-12 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
                      <Sparkles size={20} className="animate-pulse" />
                    </div>
                    <div>
                      <h4 className="text-white text-xs font-bold uppercase tracking-wider">
                        {t('cardSelectedHeader')} ({chosenCardIds.length} ACTIVE)
                      </h4>
                      <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                        Selected IDs: <span className="font-bold text-yellow-400 font-mono text-xs">{chosenCardIds.slice(0, 8).map(id => `#${id}`).join(', ')}{chosenCardIds.length > 8 ? ' ...' : ''}</span>. Total cost for this round is <span className="text-emerald-400 font-bold font-mono text-xs">{(chosenCardIds.length * (rooms.find(r => r.id === selectedRoomId)?.entryFee || 0)).toLocaleString()} ETB</span>.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 px-4 py-2.5 bg-emerald-950/30 border border-emerald-500/20 text-emerald-400 text-xs font-bold uppercase rounded-xl select-none">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                    <span>{t('registeredPassesStatus')}</span>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}

        {/* VIEW 3: IN GAME (INTERACTIVE CALLING BOARD AND MULTI-PLAYER) */}
        {selectedRoomId && inGame && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-6"
          >
            {/* Play-Room Auditory and Navigation Header */}
            <div className="bg-slate-900 border border-slate-800 flex flex-col sm:flex-row items-center justify-between p-5 rounded-3xl shadow-xl gap-4">
              <div className="flex flex-col sm:flex-row items-center gap-5 w-full sm:w-auto">
                {/* Clean, High-Contrast Called Ball Indicator */}
                <div className="relative flex items-center justify-center shrink-0">
                  <div className="absolute inset-0 bg-yellow-500/10 rounded-full animate-ping" />
                  <div className="h-16 w-16 rounded-full bg-gradient-to-tr from-yellow-500 to-amber-600 border-2 border-yellow-400 flex flex-col items-center justify-center text-slate-950 shadow-2xl relative z-10">
                    <span className="text-[9px] font-black leading-none font-sans select-none tracking-widest uppercase">BALL</span>
                    <span className="text-2xl font-mono font-black select-none leading-none mt-1">
                      {lastCalledNumber || '--'}
                    </span>
                  </div>
                </div>

                <div className="text-center sm:text-left select-none">
                  {/* Amharic Text feedback & Controls */}
                  <div className="flex items-center justify-center sm:justify-start gap-3">
                    <span className="text-[10px] bg-red-500/10 text-red-400 border border-red-500/20 font-extrabold px-2 py-0.5 rounded-full tracking-wide uppercase">
                      {lang === 'am' ? 'የአማርኛ ድምፅ' : 'Amharic Caller'}
                    </span>
                    
                    {/* Audio Mute Action Toggle with pulse */}
                    <button 
                      onClick={() => setIsMuted(!isMuted)}
                      className="text-slate-400 hover:text-white bg-slate-950 border border-slate-800 hover:border-slate-700 cursor-pointer flex items-center justify-center p-1.5 rounded-xl transition-all"
                      title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
                    >
                      {isMuted ? <VolumeX size={14} /> : <Volume2 size={14} className="text-emerald-400 animate-bounce" />}
                    </button>
                    
                    {!isMuted && (
                      <span className="text-[9px] text-emerald-400 font-mono font-bold animate-pulse">
                        ON
                      </span>
                    )}
                  </div>
                  
                  <h3 className="font-display font-black text-xl text-white mt-1.5 leading-none tracking-wide select-text">
                    {amharicVoiceText ? (
                      <span className="flex items-center gap-2">
                        <span className="text-amber-400 text-2xl font-bold">{amharicVoiceText}</span>
                        {lastCalledNumber && (
                          <span className="text-xs font-mono text-slate-400 font-bold bg-slate-950 border border-slate-800 px-2.5 py-0.5 rounded">
                            {(() => {
                              const num = lastCalledNumber;
                              if (num >= 1 && num <= 15) return 'B';
                              if (num >= 16 && num <= 30) return 'I';
                              if (num >= 31 && num <= 45) return 'N';
                              if (num >= 46 && num <= 60) return 'G';
                              if (num >= 61 && num <= 75) return 'O';
                              return '';
                            })()}-{lastCalledNumber}
                          </span>
                        )}
                      </span>
                    ) : (
                      <span className="text-slate-450 text-sm italic font-medium">
                        {lang === 'am' ? 'የመጀመሪያው ቁጥር እስኪወጣ በመጠባበቅ ላይ...' : 'Standby for Amharic vocal announcements...'}
                      </span>
                    )}
                  </h3>
                </div>
              </div>

              {/* Leave table button */}
              <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto justify-end">
                <button
                  onClick={handleLeaveRoom}
                  className="px-4 py-2 bg-red-950/20 text-red-400 hover:text-red-350 border border-red-900/30 hover:border-red-800 rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer shadow-lg hover:shadow-red-950/20 active:scale-95"
                >
                  <LogOut size={12} />
                  <span>{lang === 'am' ? 'ውጣ' : 'Leave Table'}</span>
                </button>
              </div>
            </div>

            {/* Live Arena Stats Panel: Showing how many players are in the room and what they can win, with ZERO commissions shown! */}
            <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-xl select-none relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-[#ff5500]/5 via-transparent to-yellow-500/5 pointer-events-none" />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 relative z-10 animate-fade-in">
                {/* Active Player Seats */}
                <div className="bg-slate-950 p-4 rounded-2xl border border-slate-850 flex items-center justify-between">
                  <div className="flex items-center gap-3.5">
                    <div className="h-10 w-10 rounded-xl bg-[#ff5500]/10 border border-[#ff5500]/25 flex items-center justify-center text-[#ff5500] shrink-0">
                      <Users size={18} />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block uppercase font-black tracking-wider leading-none mb-1.5">{lang === 'am' ? 'የተሳታፊዎች ብዛት' : 'Players in This Room'}</span>
                      <span className="text-xl font-black text-slate-200 font-mono leading-none">{players.length} {lang === 'am' ? 'ተጫዋቾች' : 'Active Seats'}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded-lg text-emerald-400 font-mono text-[9px] uppercase font-black animate-pulse">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0" />
                    <span>{lang === 'am' ? 'ቀጥታ' : 'Live'}</span>
                  </div>
                </div>

                {/* Net Payout Win Amount to take home */}
                <div className="bg-slate-950 p-4 rounded-2xl border border-slate-850 flex items-center justify-between">
                  <div className="flex items-center gap-3.5">
                    <div className="h-10 w-10 rounded-xl bg-yellow-500/10 border border-yellow-500/25 flex items-center justify-center text-yellow-400 shrink-0">
                      <Trophy size={18} className="animate-bounce" />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block uppercase font-black tracking-wider leading-none mb-1.5">{lang === 'am' ? 'ማሸነፍ የሚችሉት ጠቅላላ ሽልማት' : 'Total You Will Win'}</span>
                      <span className="text-xl font-black text-yellow-400 font-mono leading-none">{netPayoutAmount.toFixed(2)} <span className="text-xs font-sans font-black">ETB</span></span>
                    </div>
                  </div>
                  <div className="bg-yellow-500/10 text-yellow-400 border border-yellow-500/20 px-2.5 py-1 rounded-lg font-mono text-[9px] uppercase font-black">
                    🏆 {lang === 'am' ? 'ታላቅ ሽልማት' : 'GRAND PRIZE'}
                  </div>
                </div>
              </div>
            </div>

            {/* Split Screen Matrix: Side-by-side Called Numbers Columns AND Interactive Board */}
            <div className="grid grid-cols-2 gap-2 sm:gap-6 items-start">

              {/* LEFT SIDE: PRIMARY INTERACTIVE CARD DECK */}
              <div className="space-y-4">

                {myCardsData.length === 0 ? (
                  /* Watching view fallback */
                  <div className="bg-slate-900 border border-slate-800 p-3 sm:p-6 rounded-2xl sm:rounded-3xl shadow-xl space-y-4 flex flex-col justify-between min-h-[340px] sm:min-h-[380px]">
                    <div>
                      {/* Spectator Header */}
                      <div className="flex justify-between items-center border-b border-slate-800 pb-2 sm:pb-3 mb-3 sm:mb-4">
                        <div>
                          <span className="text-[10px] sm:text-xs font-black text-[#ff5500] uppercase flex items-center gap-1 sm:gap-1.5 animate-pulse">
                            <span className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-red-500 rounded-full animate-ping" />
                            {lang === 'am' ? 'የቀጥታ ተመልካች መከታተያ' : 'Live Spectator Panel'}
                          </span>
                          <span className="text-[8px] sm:text-[9px] text-slate-500 font-mono block mt-0.5">
                            {lang === 'am' ? 'የጨዋታ ክፍሉን በቀጥታ ይከታተሉ' : 'SPECTATOR LOUNGE - 24/7 AUTO GAME'}
                          </span>
                        </div>
                        <button
                          onClick={() => {
                            setInGame(false);
                            setMyCardsData([]);
                            setChosenCardIds([]);
                            playShortBeep(330, 0.05);
                          }}
                          className="px-2 py-0.5 sm:px-2.5 sm:py-1 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-[8px] sm:text-[9px] font-bold uppercase cursor-pointer"
                        >
                          {lang === 'am' ? 'ቲኬት ምረጥ' : 'Select Ticket'}
                        </button>
                      </div>

                      {/* Select who to watch */}
                      {players.length > 0 ? (
                        <div className="space-y-2 sm:space-y-3">
                          <div>
                            <span className="text-[8px] sm:text-[10px] text-slate-500 block uppercase font-mono mb-1 font-bold">
                              {lang === 'am' ? 'የተጫዋቾች ካርድ ለመከታተል ይጫኑ:' : 'TAP PLAYER SEAT TO WATCH CARD:'}
                            </span>
                            <div className="flex gap-1 overflow-x-auto pb-1 max-w-full">
                              {players.map(p => {
                                const spectateKey = `${p.userId}-${p.cardId}`;
                                const isWatchingThis = selectedSpectateUserId === spectateKey;
                                return (
                                  <button
                                    key={spectateKey}
                                    type="button"
                                    onClick={() => {
                                      setSelectedSpectateUserId(spectateKey);
                                      playShortBeep(440, 0.05);
                                    }}
                                    className={`px-2 py-1 sm:px-3 sm:py-1.5 rounded-lg sm:rounded-xl text-[8px] sm:text-[10px] font-mono border whitespace-nowrap cursor-pointer transition-all ${
                                      isWatchingThis
                                        ? 'bg-red-600 border-red-500 text-white font-black shadow shadow-red-500/20'
                                        : 'bg-slate-950/50 border-slate-800/80 text-slate-400 hover:text-slate-300'
                                    }`}
                                  >
                                    {p.userName} (#{p.cardId})
                                  </button>
                                );
                              })}
                            </div>
                          </div>

                          {/* Spectated player card details */}
                          {spectateCardData ? (
                            <div className="space-y-2 border-t border-slate-800/50 pt-2">
                              <div className="flex justify-between items-center text-[8px] sm:text-[10px] font-mono">
                                <span className="text-slate-400 uppercase">
                                  {lang === 'am' ? 'እየተከታተሉ ያሉት:' : 'WATCHING:'} <span className="text-yellow-400 font-bold">Card #{spectateCardData.id}</span>
                                </span>
                                <span className="text-teal-400 font-semibold uppercase animate-pulse text-[8px] sm:text-[9px]">
                                  {lang === 'am' ? 'የቀጥታ ምልክቶች' : 'LIVE BOARD'}
                                </span>
                              </div>

                              {/* 5x5 Grid for spectated card */}
                              <div className="grid grid-cols-5 gap-1 select-none aspect-square text-center font-display max-w-[280px] mx-auto">
                                {['B','I','N','G','O'].map(l => (
                                  <div key={l} className="text-slate-500 text-[9px] sm:text-xs font-black p-0.5 bg-slate-950/40 rounded border border-slate-850 font-display flex items-center justify-center">{l}</div>
                                ))}
                                
                                {spectateCardData.numbers.map((rowArr, rIndex) => (
                                  rowArr.map((numVal, cIndex) => {
                                    const isCenter = rIndex === 2 && cIndex === 2;
                                    const cellMarkedMap = spectatorMarkedCells[spectateCardData.id] || Array(5).fill(null).map(() => Array(5).fill(false));
                                    const isMarked = cellMarkedMap[rIndex][cIndex];
                                    const isCalled = calledNumbers.includes(numVal) || isCenter || isMarked;
                                    return (
                                      <div 
                                        key={`spec-${rIndex}-${cIndex}`}
                                        onClick={() => handleSpectateCellMark(spectateCardData.id, rIndex, cIndex)}
                                        className={`relative aspect-square flex flex-col items-center justify-center rounded-lg border text-[9px] sm:text-xs font-mono font-bold cursor-pointer transition-all ${
                                          isCenter
                                            ? 'bg-amber-400/10 border-amber-500/30 text-amber-400 font-display'
                                            : isMarked
                                              ? 'bg-red-600 border-red-400 text-white font-black shadow-lg shadow-red-500/35 scale-[0.98]'
                                              : isCalled
                                                ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-400 animate-pulse'
                                                : 'bg-slate-950/65 border-slate-855 text-slate-450 hover:bg-slate-900 hover:text-slate-300'
                                        }`}
                                      >
                                        <span className="text-[10px] sm:text-xs">{isCenter ? '⚡' : numVal}</span>
                                        {isMarked && !isCenter && (
                                          <span className="absolute bottom-0 text-[6px] text-white/80">✓</span>
                                        )}
                                      </div>
                                    );
                                  })
                                ))}
                              </div>
                            </div>
                          ) : (
                            <div className="py-6 text-center text-[10px] text-slate-500 italic">
                              Loading ticket details...
                            </div>
                          )}

                        </div>
                      ) : (
                        <div className="py-8 text-center space-y-2">
                          <p className="text-[10px] text-slate-400">{lang === 'am' ? 'ንቁ ተጫዋቾች እየተጠበቁ ነው...' : 'Awaiting active players...'}</p>
                          <div className="w-5 h-5 border-2 border-t-red-500 border-r-transparent border-slate-700 animate-spin rounded-full mx-auto" />
                        </div>
                      )}
                    </div>

                    {/* Quick spectator interactive deck */}
                    <div className="bg-slate-950/60 border border-slate-800 p-2 rounded-xl">
                      <span className="text-[8px] sm:text-[9px] text-slate-500 block uppercase font-mono font-bold mb-1 text-center">
                        {lang === 'am' ? 'የተመልካች ፈጣን መልዕክት መላኪያ:' : 'SEND SPECTATOR QUICK MOJI:'}
                      </span>
                      <div className="grid grid-cols-6 gap-1 sm:gap-2">
                        {['🎰', '👏', '🔥', '🥳', '🙌', '🎯'].map(emo => (
                          <button
                            key={emo}
                            type="button"
                            onClick={() => {
                              playShortBeep(650, 0.05);
                              if (socketRef.current) {
                                  socketRef.current.emit('room:chat', {
                                    roomId: selectedRoomId,
                                    token,
                                    message: `${emo} Spectator: Great game playing! ${emo}`
                                  });
                                }
                              }}
                              className="bg-slate-900 hover:bg-slate-850 py-0.5 rounded text-xs sm:text-sm transition-all active:scale-90 select-none cursor-pointer border border-slate-800/80 text-center"
                            >
                              {emo}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  ) : (
                    /* Live Playing cards view - MULTIPLE CARDS RENDERING VERTICALLY */
                    <div className="bg-slate-900 border border-slate-800 p-2 sm:p-5 rounded-2xl sm:rounded-3xl shadow-xl space-y-3 sm:space-y-5">
                      <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-2 pb-2 border-b border-slate-800">
                        <div>
                          <span className="text-[9px] sm:text-xs font-black tracking-wide text-white uppercase block">
                            {lang === 'am' ? 'የጨዋታ ካርድ ሰሌዳ' : 'MY ACTIVE CARDS'}
                          </span>
                          <p className="text-[8px] sm:text-[10px] text-slate-500 font-mono mt-0.5 leading-none">
                            {lang === 'am' 
                              ? `${myCardsData.length} ካርድ ${myCardsData.length > 1 ? 'ዎች' : ''} እየተጫወቱ ነው` 
                              : `${myCardsData.length} Active ${myCardsData.length > 1 ? 'Cards' : 'Card'} in Play`}
                          </p>
                        </div>

                        {/* Play Mode Manual vs Auto-Daub Switch */}
                        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-850 shrink-0">
                          <span className="text-[8px] sm:text-[10px] uppercase font-bold text-slate-400 font-mono scale-90">
                            {lang === 'am' ? 'ሁነታ:' : 'MODE:'}
                          </span>
                          <button
                            type="button"
                            onClick={() => {
                              setAutoPlayEnabled(false);
                              playShortBeep(440, 0.1);
                            }}
                            className={`px-1.5 py-0.5 sm:px-2.5 sm:py-1 text-[8px] sm:text-[10px] font-bold rounded cursor-pointer transition-all ${
                              !autoPlayEnabled
                                ? 'bg-amber-500 text-slate-950 font-black'
                                : 'text-slate-500 hover:text-slate-350'
                            }`}
                          >
                            Manual
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setAutoPlayEnabled(true);
                              playShortBeep(554.37, 0.1);
                            }}
                            className={`px-1.5 py-0.5 sm:px-2.5 sm:py-1 text-[8px] sm:text-[10px] font-bold rounded cursor-pointer transition-all ${
                              autoPlayEnabled
                                ? 'bg-emerald-500 text-slate-950 font-black'
                                : 'text-slate-500 hover:text-slate-350'
                            }`}
                          >
                            Auto-Daub
                          </button>
                        </div>
                      </div>

                      {/* Stacking All Cards Vertically */}
                      <div className="space-y-4 max-h-[75vh] overflow-y-auto pr-1">
                        {myCardsData.map((card, cardIndex) => (
                          <div key={card.id} className="bg-slate-950/60 p-1.5 sm:p-4 rounded-xl sm:rounded-2xl border border-slate-850 space-y-2">
                            <div className="flex justify-between items-center text-[8px] sm:text-[10px] font-mono leading-none px-1">
                              <span className="text-slate-400 uppercase font-black">
                                {lang === 'am' ? 'ካርድ ቁጥር' : 'CARD NO'}: <span className="text-yellow-400">#{card.id}</span>
                              </span>
                              <span className="text-[7px] sm:text-[8px] tracking-wider uppercase font-black bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-1 py-0.5 rounded">
                                {lang === 'am' ? 'በጨዋታ ላይ' : `CARD ${cardIndex + 1}/${myCardsData.length}`}
                              </span>
                            </div>

                            {/* 5x5 BINGO Grid Layout */}
                            <div className="grid grid-cols-5 gap-1 select-none aspect-square text-center font-display max-w-[340px] mx-auto">
                              {['B','I','N','G','O'].map(l => (
                                <div key={l} className="text-slate-400 text-[9px] sm:text-xs font-black p-0.5 bg-slate-900 rounded border border-slate-800 font-display flex items-center justify-center">{l}</div>
                              ))}
                              
                              {card.numbers.map((rowArr, rIndex) => (
                                rowArr.map((numVal, cIndex) => {
                                  const isCenter = rIndex === 2 && cIndex === 2;
                                  const cellMarkedMap = markedCellsMap[card.id] || Array(5).fill(null).map(() => Array(5).fill(false));
                                  const isMarked = cellMarkedMap[rIndex][cIndex];
                                  const isCalled = calledNumbers.includes(numVal) || isCenter || isMarked;
                                  
                                  return (
                                    <div 
                                      key={`${card.id}-${rIndex}-${cIndex}`}
                                      onClick={() => handleCellMark(card.id, rIndex, cIndex)}
                                      className={`relative aspect-square flex flex-col items-center justify-center rounded-lg border text-[9px] sm:text-xs font-mono font-bold cursor-pointer transition-all ${
                                        isCenter
                                          ? 'bg-amber-400/10 border-amber-500/30 text-amber-400 font-display animate-pulse'
                                          : isMarked
                                            ? 'bg-red-600 border-red-400 text-white font-black shadow-lg shadow-red-500/35 scale-[0.98]'
                                            : isCalled
                                              ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-400 glow-active animate-pulse border-dashed'
                                              : 'bg-slate-900 border-slate-800 hover:bg-slate-850 text-slate-300'
                                      }`}
                                    >
                                      <span className="text-[10px] sm:text-xs font-black">{isCenter ? '⚡' : numVal}</span>
                                      {isMarked && !isCenter && (
                                        <span className="absolute bottom-1 right-1 px-0.5 sm:px-1 rounded bg-black/60 text-[6px] sm:text-[7px] text-white opacity-95">✓</span>
                                      )}
                                    </div>
                                  );
                                })
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

              </div>

              {/* RIGHT SIDE: BINGO CALLED Grid in compact rows to eliminate scroll demands */}
              <div className="bg-slate-900 border border-slate-800 p-2 sm:p-4 rounded-2xl sm:rounded-3xl shadow-2xl flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-center border-b border-slate-800 pb-2 sm:pb-3 mb-2 sm:mb-4">
                    <span className="text-[9px] sm:text-xs font-black text-white uppercase flex items-center gap-1 sm:gap-1.5">
                      <span className="h-1.5 w-1.5 sm:h-2 sm:w-2 rounded-full bg-orange-500 animate-ping" />
                      {lang === 'am' ? 'የወጡ ቁጥሮች ሰንጠረዥ' : 'CALLED BOARD'}
                    </span>
                    <span className="text-[8px] sm:text-[10px] font-mono text-teal-400 bg-teal-500/10 px-1.5 py-0.5 rounded border border-teal-500/20 font-black leading-none">
                      {calledNumbers.length} / 75 {lang === 'am' ? 'የወጡ' : 'Drawn'}
                    </span>
                  </div>

                  {/* Horizontal Rows for B-I-N-G-O Grid Alignment */}
                  <div className="space-y-1.5">
                    {[
                      { letter: 'B', min: 1, max: 15, color: 'text-rose-450 border-rose-500/30 bg-rose-500/5' },
                      { letter: 'I', min: 16, max: 30, color: 'text-sky-450 border-sky-500/30 bg-sky-500/5' },
                      { letter: 'N', min: 31, max: 45, color: 'text-amber-450 border-amber-500/30 bg-amber-500/5' },
                      { letter: 'G', min: 46, max: 60, color: 'text-purple-450 border-purple-500/30 bg-purple-500/5' },
                      { letter: 'O', min: 61, max: 75, color: 'text-emerald-450 border-emerald-500/30 bg-emerald-500/5' }
                    ].map(row => (
                      <div key={row.letter} className="flex items-center gap-1 sm:gap-2 bg-slate-950/60 p-1 sm:p-1.5 rounded-xl sm:rounded-2xl border border-slate-850">
                        {/* Letter Identifier */}
                        <div className={`w-6 h-6 sm:w-8 sm:h-8 rounded-lg sm:rounded-xl flex items-center justify-center font-black ${row.color} border shrink-0 text-xs sm:text-sm`}>
                          {row.letter}
                        </div>
                        
                        {/* CSS Grid template of exactly 15 equal columns */}
                        <div className="grid gap-0.5 sm:gap-1 w-full" style={{ gridTemplateColumns: 'repeat(15, minmax(0, 1fr))' }}>
                          {Array.from({ length: row.max - row.min + 1 }).map((_, idx) => {
                            const val = row.min + idx;
                            const hasBeenCalled = calledNumbers.includes(val);
                            const isCurrent = lastCalledNumber === val;
                            return (
                              <div
                                key={val}
                                className={`aspect-square flex items-center justify-center text-[7px] sm:text-[10px] font-mono rounded-md sm:rounded-lg font-black border transition-all ${
                                  isCurrent
                                    ? 'bg-yellow-400 text-slate-900 border-yellow-300 scale-105 shadow-md shadow-yellow-500/25 animate-pulse text-[8px] sm:text-[11px]'
                                    : hasBeenCalled
                                      ? 'bg-orange-500/20 border-orange-500/40 text-orange-400'
                                      : 'bg-transparent border-transparent text-slate-600 opacity-20 font-semibold'
                                }`}
                              >
                                {val}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-2.5 pt-2 border-t border-slate-800 text-[8px] text-slate-500 font-mono text-center uppercase">
                  {lang === 'am' ? 'እውነተኛ የቢንጎ ጨዋታ ሰሌዳ' : 'Raya Bingo Official Live Caller Cage Grid'}
                </div>
              </div>

            </div>

              {/* Lower wide row: Players & Chat under side-by-side gameroom arena */}
              <div className="lg:col-span-12 grid grid-cols-1 lg:grid-cols-12 gap-6 pt-6 border-t border-slate-800/40">
              
              {/* Connected users section */}
              <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md flex flex-col justify-between">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2.5 block">Seats occupied ({players.length})</span>
                <div className="space-y-1.5 max-h-44 overflow-y-auto pr-1">
                  {players.map(p => (
                    <div key={`${p.userId}-${p.cardId}`} className="flex justify-between items-center text-xs p-1.5 bg-slate-950 border border-slate-850 rounded-lg whitespace-nowrap">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <span className={`h-1.5 w-1.5 rounded-full ${p.isBot ? 'bg-blue-400' : 'bg-emerald-400'}`} />
                        <span className="font-semibold text-slate-300 truncate" title={p.userName}>{p.userName}</span>
                      </div>
                      <span className="text-[9px] text-slate-500 font-mono shrink-0">Card #{p.cardId}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Chat panel */}
              <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-2xl flex flex-col h-[280px] overflow-hidden">
                <div className="bg-slate-950 px-3.5 py-2.5 border-b border-slate-800 text-[10px] uppercase font-bold text-slate-300">
                  Lobby Chat Lounge
                </div>
                
                {/* Messages view */}
                <div 
                  ref={chatScrollRef}
                  className="flex-1 p-3 overflow-y-auto space-y-2.5 text-xs bg-slate-950 divide-y divide-slate-900"
                >
                  {chatMessages.length === 0 ? (
                    <p className="text-[10px] text-slate-600 font-serif italic text-center pt-8">Lounge is quiet. Send a friendly emote!</p>
                  ) : (
                    chatMessages.map(msg => (
                      <div key={msg.id} className="pt-2">
                        <div className="flex justify-between text-[10px] text-slate-500 font-mono mb-0.5">
                          <span className="font-bold text-yellow-500">{msg.userName}</span>
                          <span>{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        </div>
                        <p className="text-slate-350 select-text break-words pr-2">{msg.message}</p>
                      </div>
                    ))
                  )}
                </div>

                {/* Input form */}
                <form onSubmit={handleSendChat} className="p-2.5 border-t border-slate-800 flex gap-1.5 items-center bg-slate-950 shrink-0">
                  <input
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    placeholder="Chat..."
                    className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none"
                  />
                  <button type="submit" className="p-2 bg-green-700 hover:bg-green-600 rounded-lg text-white cursor-pointer select-none">
                    <Send size={12} />
                  </button>
                </form>
              </div>

            </div>

            {/* Winner banner modal */}
            <AnimatePresence>
              {gameWinner && (
                <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
                  <motion.div 
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.9, opacity: 0 }}
                    className="bg-slate-900 border border-yellow-500/40 max-w-md w-full p-6 text-center rounded-3xl shadow-2xl relative overflow-hidden"
                  >
                    {/* CONFETTI GRAPHIC FALLBACK */}
                    <div className="absolute top-0 inset-x-0 h-2 bg-gradient-to-r from-green-500 via-yellow-500 to-red-500" />
                    
                    <div className="mb-4 inline-flex items-center justify-center h-16 w-16 rounded-full bg-yellow-500/10 border border-yellow-400 text-yellow-400">
                      <Trophy size={40} className="animate-bounce" />
                    </div>

                    <h1 className="font-display text-2xl font-black text-white">BINGO!</h1>
                    <p className="text-xs text-slate-400 mt-1 uppercase font-semibold">We have a winner!</p>

                    <div className="bg-slate-950 border border-slate-850 p-4 rounded-2xl my-4 text-xs space-y-2">
                      <p className="text-slate-400">Winner: <span className="font-bold text-white text-sm block mt-0.5">{gameWinner.name}</span></p>
                      <div className="h-[1px] bg-slate-850" />
                      <p className="text-slate-400">Payout: <span className="font-mono font-black text-emerald-400 text-base">{gameWinner.prize} ETB</span></p>
                      <div className="h-[1px] bg-slate-850" />
                      <p className="text-slate-400">Winning Line: <span className="font-mono text-yellow-500">{gameWinner.pattern}</span></p>
                    </div>

                    <p className="text-[10px] text-slate-500 animate-pulse mt-3">Re-routing to lobby for next round in seconds...</p>
                  </motion.div>
                </div>
              )}
            </AnimatePresence>

          </motion.div>
        )}

      </AnimatePresence>
    </div>
  );
}
