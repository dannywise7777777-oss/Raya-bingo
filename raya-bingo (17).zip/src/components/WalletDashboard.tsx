/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { User, Transaction, PaymentMethod } from '../types.js';
import { 
  Coins, 
  ArrowUpRight, 
  ArrowDownLeft, 
  History, 
  Upload, 
  AlertTriangle, 
  Send, 
  CheckCircle,
  Copy,
  Receipt,
  PiggyBank
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface WalletDashboardProps {
  user: User;
  token: string | null;
  onBalanceUpdate: (newBalance: number) => void;
  onAddNotif: (msg: string, type: 'payment' | 'game' | 'system') => void;
}

export default function WalletDashboard({ 
  user, 
  token,
  onBalanceUpdate, 
  onAddNotif 
}: WalletDashboardProps) {
  const [activeSegment, setActiveSegment] = useState<'deposit' | 'withdraw' | 'history'>('deposit');
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  
  // Deposit state
  const [depAmount, setDepAmount] = useState('');
  const [depMethod, setDepMethod] = useState<PaymentMethod>('telebirr');
  const [depRef, setDepRef] = useState('');
  const [depPhone, setDepPhone] = useState(user.phoneNumber || '0940889473');
  const [depScreenshot, setDepScreenshot] = useState<string | null>(null);
  const [depModeType, setDepModeType] = useState<'auto' | 'manual'>('auto');
  const [pastedSMS, setPastedSMS] = useState('');
  
  // Withdrawal state
  const [withAmount, setWithAmount] = useState('');
  const [withMethod, setWithMethod] = useState<PaymentMethod>('telebirr');
  const [withPhone, setWithPhone] = useState(user.phoneNumber || '0940889473');

  const [loading, setLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [copied, setCopied] = useState(false);

  // Account instructions (Telebirr-only transfer parameters)
  const PAYMENT_DETAILS = {
    telebirr: { accountName: "Daniel", accountNumber: "0940889473", fee: "0.00%" }
  };

  const fetchHistory = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/payments/history', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setTransactions(data);
      }
    } catch (e) {
      console.error('Error fetching transactions', e);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, [token, activeSegment]);

  // Handle image upload for deposit proof
  const handleProofChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setDepScreenshot(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Submit auto-deposit copy paste / screenshot
  const handleAutoDepositSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!pastedSMS.trim() && !depScreenshot) {
      setErrorMsg('Please paste the Telebirr SMS notification or drag/upload a receipt screenshot.');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/payments/auto-deposit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          pastedSMS: pastedSMS,
          screenshot: depScreenshot || ''
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Verification failed');
      }

      setSuccessMsg(data.message || `🎉 Success! Payment verified and wallet credited.`);
      
      // Update balance using current user session
      const balanceRes = await fetch('/api/auth/me', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (balanceRes.ok) {
        const userData = await balanceRes.json();
        if (userData && userData.user) {
          onBalanceUpdate(userData.user.balance);
        }
      }

      setPastedSMS('');
      setDepScreenshot(null);
      fetchHistory();
    } catch (err: any) {
      setErrorMsg(err.message || 'Payment verifier was unable to confirm this transaction. Please use manual form.');
    } finally {
      setLoading(false);
    }
  };

  // Submit deposit
  const handleDepositSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!depAmount || Number(depAmount) <= 0) {
      setErrorMsg(' Please specify a valid deposit amount in ETB.');
      return;
    }

    if (!depRef.trim()) {
      setErrorMsg('Transaction Ref/Transaction ID is critical for manual ledger verification.');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/payments/deposit', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}` 
        },
        body: JSON.stringify({
          amount: Number(depAmount),
          method: depMethod,
          referenceNumber: depRef.toUpperCase().trim(),
          phoneNumber: depPhone,
          screenshot: depScreenshot || ''
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error);
      }

      setSuccessMsg(`Deposit request submitted! Once checked, your balance will update. Ref: ${depRef.toUpperCase()}`);
      setDepAmount('');
      setDepRef('');
      setDepScreenshot(null);
      fetchHistory();
    } catch (err: any) {
      setErrorMsg(err.message || 'Deposit submission unsuccessful');
    } finally {
      setLoading(false);
    }
  };

  

  // Submit withdrawal cashout
  const handleWithdrawSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    const amt = Number(withAmount);
    if (!withAmount || amt <= 0) {
      setErrorMsg('Please specify a positive withdrawal amount in ETB.');
      return;
    }

    if (user.balance < amt) {
      setErrorMsg(`Insufficient funds! Your current account balance is only ${user.balance} ETB.`);
      return;
    }

    if (!withPhone) {
      setErrorMsg('Please provide a valid cash-out phone number.');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/payments/withdraw', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}` 
        },
        body: JSON.stringify({
          amount: amt,
          method: withMethod,
          phoneNumber: withPhone
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error);
      }

      // Update local wallet state
      onBalanceUpdate(data.updatedBalance);
      setSuccessMsg(`Successful cashout dispatch for ${amt} ETB. Pending quick admin review!`);
      setWithAmount('');
      fetchHistory();
    } catch (err: any) {
      setErrorMsg(err.message || 'Withdrawal submission unsuccessful');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* Column 1: Financial Status Indicator & Details */}
        <div className="space-y-6 lg:col-span-1">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg relative overflow-hidden">
            <div className="absolute top-0 right-0 h-24 w-24 bg-green-600/5 rounded-full blur-xl" />
            <div className="flex justify-between items-center mb-4">
              <span className="text-xs font-semibold text-slate-400 tracking-wide uppercase">Raya Account Balance</span>
              <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
            </div>
            
            <div className="flex items-baseline gap-2 mb-2">
              <h2 className="text-3xl font-display font-black text-yellow-400 tracking-tight">
                {user.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </h2>
              <span className="text-xs font-bold text-slate-300">ETB</span>
            </div>
            <p className="text-[10px] text-slate-500">Includes direct promotional bonus cash and verified ledger winnings.</p>

            <div className="h-[1px] bg-slate-800 my-4" />
            
            <div className="space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Owner Name:</span>
                <span className="text-white font-medium">{user.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Mobile Phone:</span>
                <span className="text-white font-mono">{user.phoneNumber || 'Telegram Link Only'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Onboarding standing:</span>
                <span className="text-green-400 font-bold uppercase">{user.otpVerified ? 'OTP Verified' : 'Standard'}</span>
              </div>
            </div>
          </div>

          {/* official ethiopian payment bank indices */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
            <h3 className="text-xs font-black text-slate-300 tracking-wider uppercase mb-3.5 flex items-center gap-2">
              <PiggyBank size={14} className="text-yellow-400" />
              <span>OFFICIAL INCOMING CHANNELS</span>
            </h3>
            
            <div className="space-y-3">
              {(Object.keys(PAYMENT_DETAILS) as Array<keyof typeof PAYMENT_DETAILS>).map(k => {
                const item = PAYMENT_DETAILS[k];
                const displayName = 'Telebirr Mobile Account';
                return (
                  <div key={k} className="p-3 bg-slate-950 border border-slate-800/80 rounded-xl space-y-1.5 hover:border-slate-700 transition-colors">
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-bold text-slate-200">{displayName}</span>
                      <span className="text-[9px] bg-yellow-400/10 text-yellow-500 border border-yellow-500/30 px-1 rounded font-mono">Fee: {item.fee}</span>
                    </div>
                    <div className="text-xs font-mono text-slate-400 flex justify-between items-center bg-slate-900 p-1.5 rounded">
                      <span className="text-white font-bold">{item.accountNumber}</span>
                      <button 
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(item.accountNumber);
                          setCopied(true);
                          setTimeout(() => setCopied(false), 2000);
                        }}
                        className="text-[10px] text-yellow-500 hover:text-yellow-400 flex items-center gap-1 font-semibold cursor-pointer"
                      >
                        {copied ? '✓ Copied!' : 'Copy'}
                      </button>
                    </div>
                    <div className="text-[10px] text-slate-400 flex justify-between mt-1">
                      <span>Deposits Contact: <span className="font-bold text-white">{item.accountName}</span></span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Column 2 & 3: Cashier Operations Tabs */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl shadow-lg flex flex-col overflow-hidden">
          
          {/* Tab buttons */}
          <div className="flex bg-slate-950 border-b border-slate-800">
            <button
              onClick={() => { setActiveSegment('deposit'); setErrorMsg(''); setSuccessMsg(''); }}
              className={`flex-1 py-3.5 text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer transition-colors ${
                activeSegment === 'deposit' 
                  ? 'bg-slate-900 text-yellow-400 border-b-2 border-yellow-500' 
                  : 'text-slate-400 hover:text-white hover:bg-slate-900/50'
              }`}
            >
              <ArrowUpRight size={14} className="text-emerald-500" />
              <span>Deposit Request</span>
            </button>
            <button
              onClick={() => { setActiveSegment('withdraw'); setErrorMsg(''); setSuccessMsg(''); }}
              className={`flex-1 py-3.5 text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer transition-colors ${
                activeSegment === 'withdraw' 
                  ? 'bg-slate-900 text-yellow-400 border-b-2 border-yellow-500' 
                  : 'text-slate-400 hover:text-white hover:bg-slate-900/50'
              }`}
            >
              <ArrowDownLeft size={14} className="text-red-500" />
              <span>Withdraw Cash</span>
            </button>
            <button
              onClick={() => { setActiveSegment('history'); setErrorMsg(''); setSuccessMsg(''); }}
              className={`flex-1 py-3.5 text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer transition-colors ${
                activeSegment === 'history' 
                  ? 'bg-slate-900 text-yellow-400 border-b-2 border-yellow-500' 
                  : 'text-slate-400 hover:text-white hover:bg-slate-900/50'
              }`}
            >
              <History size={14} />
              <span>Log History</span>
            </button>
          </div>

          <div className="p-5 sm:p-6 flex-1">
            {errorMsg && (
              <div className="p-3 mb-4 bg-red-950/40 border border-red-800 text-red-500 text-xs rounded-xl flex items-center gap-2">
                <AlertTriangle size={15} />
                <span>{errorMsg}</span>
              </div>
            )}

            {successMsg && (
              <div className="p-3 mb-4 bg-emerald-950/40 border border-emerald-800 text-emerald-400 text-xs rounded-xl flex items-center gap-2">
                <CheckCircle size={15} />
                <span>{successMsg}</span>
              </div>
            )}

            <AnimatePresence mode="wait">
              {activeSegment === 'deposit' && (
                <motion.div
                  key="deposit"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="space-y-4"
                >
                  {/* Select Verification Mode */}
                  <div className="flex bg-slate-950 p-1.5 rounded-2xl border border-slate-850 gap-1">
                    <button
                      type="button"
                      onClick={() => { setDepModeType('auto'); setErrorMsg(''); setSuccessMsg(''); }}
                      className={`flex-1 py-2 text-[10px] sm:text-xs font-bold uppercase tracking-wider rounded-xl transition-all cursor-pointer ${
                        depModeType === 'auto'
                          ? 'bg-yellow-500 text-slate-950 font-black shadow'
                          : 'text-slate-400 hover:text-white hover:bg-slate-900/30'
                      }`}
                    >
                      ⚡ AI Auto-Verify (SMS / Image)
                    </button>
                    <button
                      type="button"
                      onClick={() => { setDepModeType('manual'); setErrorMsg(''); setSuccessMsg(''); }}
                      className={`flex-1 py-2 text-[10px] sm:text-xs font-bold uppercase tracking-wider rounded-xl transition-all cursor-pointer ${
                        depModeType === 'manual'
                          ? 'bg-yellow-500 text-slate-950 font-black shadow'
                          : 'text-slate-400 hover:text-white hover:bg-slate-900/30'
                      }`}
                    >
                      📝 Manual Ref ID Submission
                    </button>
                  </div>

                  {depModeType === 'auto' ? (
                    <motion.div
                      key="auto-form"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="space-y-4"
                    >
                      <div className="p-4 bg-emerald-950/20 border border-emerald-900/40 rounded-2xl relative overflow-hidden">
                        <div className="absolute top-0 right-0 h-16 w-16 bg-emerald-500/5 rounded-full blur-xl" />
                        <h4 className="text-xs font-bold text-emerald-400 mb-1">⚡ Dynamic Instant Auto-Wallet Refill</h4>
                        <p className="text-[11px] text-slate-400 leading-relaxed">
                          Paste your received Telebirr SMS advice or upload a receipt receipt image. Our ledger checker queries telebirr.com registers and credits your balance in real-time!
                        </p>
                      </div>

                      <form onSubmit={handleAutoDepositSubmit} className="space-y-4">
                        <div>
                          <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1.5">Copy-Paste received SMS advice or receipt text</label>
                          <textarea
                            value={pastedSMS}
                            onChange={(e) => setPastedSMS(e.target.value)}
                            placeholder="e.g. Transaction of Birr 100.00 from 0940889473 is successful. transaction id is 9FJ6AM49K2..."
                            rows={3}
                            className="block w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 focus:border-green-600 rounded-xl text-xs font-mono text-white focus:outline-none focus:ring-0 transition-colors resize-none placeholder:text-slate-700"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1.5">Or upload transaction receipt screenshot / image (drag & drop supported)</label>
                          <div className="border border-dashed border-slate-800 hover:border-slate-700 bg-slate-950 rounded-xl p-4 text-center cursor-pointer transition-colors relative">
                            <input
                              type="file"
                              accept="image/*"
                              onChange={handleProofChange}
                              className="absolute inset-0 opacity-0 cursor-pointer"
                            />
                            {depScreenshot ? (
                              <div className="flex flex-col items-center gap-2">
                                <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1">✓ Receipt Image Loaded Successfully</span>
                                <img src={depScreenshot} alt="receipt" className="max-h-24 object-contain rounded border border-slate-800" />
                              </div>
                            ) : (
                              <div className="flex flex-col items-center gap-1 text-slate-500 hover:text-slate-400">
                                <Upload size={20} />
                                <span className="text-xs">Drag receipt image or click inside to upload screenshot</span>
                                <span className="text-[10px] text-slate-600 font-mono">PNG, JPEG, JPG formats supported</span>
                              </div>
                            )}
                          </div>
                        </div>

                        <button
                          type="submit"
                          disabled={loading}
                          className="w-full flex items-center justify-center gap-2 mt-4 py-3 bg-gradient-to-r from-emerald-700 to-emerald-650 hover:from-emerald-650 hover:to-emerald-600 text-white text-xs font-bold uppercase tracking-wider rounded-xl cursor-pointer disabled:opacity-50 transition-colors font-semibold"
                        >
                          <span>{loading ? 'Verifying payment on telebirr.com...' : '⚡ Verify & Approve Deposit Instantly'}</span>
                        </button>
                      </form>
                    </motion.div>
                  ) : (
                    <motion.div
                      key="manual-form"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="space-y-4"
                    >
                      <div className="p-4 bg-slate-950/60 border border-slate-800/85 rounded-2xl relative overflow-hidden">
                        <div className="absolute top-0 right-0 h-16 w-16 bg-amber-500/5 rounded-full blur-xl" />
                        <h4 className="text-xs font-bold text-white mb-1">📝 Manual Ledger Submission Form</h4>
                        <p className="text-[11px] text-slate-400 leading-relaxed">
                          Submit your 10-character Telebirr Reference ID manually. The AI auditor / bill controllers will verify your reference number and approve the pending ticket within 1-2 minutes.
                        </p>
                      </div>

                      <form onSubmit={handleDepositSubmit} className="space-y-4">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1.5">Deposit Amount (ETB)</label>
                            <input
                              type="number"
                              required
                              value={depAmount}
                              onChange={(e) => setDepAmount(e.target.value)}
                              placeholder="e.g. 100"
                              className="block w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 focus:border-green-600 rounded-xl text-sm font-mono text-white focus:outline-none focus:ring-0 transition-colors"
                            />
                            {/* Preset Buttons */}
                            <div className="flex gap-1.5 mt-2">
                              {['10', '50', '100', '250', '500'].map(p => (
                                <button
                                  type="button"
                                  key={p}
                                  onClick={() => setDepAmount(p)}
                                  className="px-2 py-1 bg-slate-950 border border-slate-850 hover:border-slate-700 text-[10px] font-mono font-bold hover:text-yellow-400 text-slate-400 rounded-lg transition-colors cursor-pointer"
                                >
                                  +{p} ETB
                                </button>
                              ))}
                            </div>
                          </div>
                          <div>
                            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1.5">Payment Method</label>
                            <select
                              value={depMethod}
                              disabled
                              className="block w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 focus:border-green-600 rounded-xl text-sm text-slate-400 focus:outline-none transition-colors cursor-not-allowed"
                            >
                              <option value="telebirr">Telebirr Wallet (Only)</option>
                            </select>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1.5">Your Registered Phone Number</label>
                            <input
                              type="text"
                              required
                              value={depPhone}
                              onChange={(e) => setDepPhone(e.target.value)}
                              placeholder="e.g. 0940889473"
                              className="block w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 focus:border-green-600 rounded-xl text-sm font-mono text-white focus:outline-none transition-colors"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1.5">Transaction ID / Reference ID</label>
                            <input
                              type="text"
                              required
                              value={depRef}
                              onChange={(e) => setDepRef(e.target.value)}
                              placeholder="e.g. TXN9876543210"
                              className="block w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 focus:border-green-600 rounded-xl text-sm font-mono text-white focus:outline-none transition-colors placeholder:text-slate-700"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1.5">Screenshot Payment Receipt (Optional)</label>
                          <div className="border border-dashed border-slate-800 hover:border-slate-700 bg-slate-950 rounded-xl p-4 text-center cursor-pointer transition-colors relative">
                            <input
                              type="file"
                              accept="image/*"
                              onChange={handleProofChange}
                              className="absolute inset-0 opacity-0 cursor-pointer"
                            />
                            {depScreenshot ? (
                              <div className="flex flex-col items-center gap-2">
                                <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1">✓ Receipt Image Loaded</span>
                                <img src={depScreenshot} alt="receipt" className="max-h-24 object-contain rounded border border-slate-800" />
                              </div>
                            ) : (
                              <div className="flex flex-col items-center gap-1 text-slate-500 hover:text-slate-400">
                                <Upload size={22} />
                                <span className="text-xs">Drag receipt image or click inside to upload screenshot</span>
                                <span className="text-[10px] text-slate-600 font-mono">PNG, JPEG, JPG formats supported</span>
                              </div>
                            )}
                          </div>
                        </div>

                        <button
                          type="submit"
                          disabled={loading}
                          className="w-full flex items-center justify-center gap-2 mt-4 py-3 bg-gradient-to-r from-green-700 to-green-600 hover:from-green-600 hover:to-green-500 text-white text-xs font-bold uppercase tracking-wider rounded-xl cursor-pointer disabled:opacity-50 transition-colors font-semibold"
                        >
                          <Send size={12} />
                          <span>{loading ? 'Submitting Request...' : 'Submit Deposit for AI / Manual audit'}</span>
                        </button>
                      </form>
                    </motion.div>
                  )}
                </motion.div>
              )}

              {activeSegment === 'withdraw' && (
                <motion.div
                  key="withdraw"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="space-y-4"
                >
                  <p className="text-xs text-slate-400 leading-relaxed">
                    💸 Initiate a mobile money cashout directly request. Our financial auditing desk verifies and completes payouts inside a quick 1-hour service SLA window.
                  </p>

                  <form onSubmit={handleWithdrawSubmit} className="space-y-4 pt-2">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1.5">Withdrawal Cashout sum (ETB)</label>
                        <input
                          type="number"
                          required
                          value={withAmount}
                          onChange={(e) => setWithAmount(e.target.value)}
                          placeholder="e.g. 200"
                          className="block w-full px-3.5 py-2 bg-slate-950 border border-slate-800 focus:border-green-600 rounded-xl text-sm font-mono text-white focus:outline-none transition-colors"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1.5">Method Destination</label>
                        <select
                          value={withMethod}
                          onChange={(e) => setWithMethod(e.target.value as PaymentMethod)}
                          className="block w-full px-3.5 py-2 bg-slate-950 border border-slate-800 focus:border-green-600 rounded-xl text-sm text-white focus:outline-none transition-colors cursor-not-allowed"
                          disabled
                        >
                          <option value="telebirr">Telebirr Wallet Payment</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1.5">Mobile Number/Bank Account Number to Credit</label>
                      <input
                        type="text"
                        required
                        value={withPhone}
                        onChange={(e) => setWithPhone(e.target.value)}
                        placeholder="e.g. 0940889473"
                        className="block w-full px-3.5 py-2 bg-slate-950 border border-slate-800 focus:border-green-600 rounded-xl text-sm font-mono text-white focus:outline-none transition-colors"
                      />
                      <span className="text-[10px] text-slate-500 mt-1 block">Confirm account parameters carefully to avoid irreversible payment routings.</span>
                    </div>

                    {withAmount && Number(withAmount) > 0 && (
                      <div className="p-3.5 bg-red-950/10 border border-red-900/35 rounded-xl space-y-1.5 font-mono text-xs">
                        <div className="flex justify-between text-slate-400">
                          <span>Requested Amount:</span>
                          <span className="text-white">{Number(withAmount).toFixed(2)} ETB</span>
                        </div>
                        <div className="flex justify-between text-slate-400">
                          <span>Withdrawal Fee (5%):</span>
                          <span className="text-red-400">-{Number(Number(withAmount) * 0.05).toFixed(2)} ETB</span>
                        </div>
                        <div className="h-[1px] bg-slate-800/40 my-1" />
                        <div className="flex justify-between font-bold text-slate-200">
                          <span>Net Payout (Credited):</span>
                          <span className="text-emerald-400">{Number(Number(withAmount) * 0.95).toFixed(2)} ETB</span>
                        </div>
                      </div>
                    )}

                    <button
                      type="submit"
                      disabled={loading}
                      className="w-full flex items-center justify-center gap-2 mt-4 py-2.5 bg-gradient-to-r from-red-700 to-red-600 hover:from-red-600 hover:to-red-500 text-white text-xs font-bold uppercase tracking-wider rounded-xl cursor-pointer disabled:opacity-50 transition-colors"
                    >
                      <Send size={12} />
                      <span>{loading ? 'Processing...' : 'Request Cashout'}</span>
                    </button>
                  </form>
                </motion.div>
              )}

              {activeSegment === 'history' && (
                <motion.div
                  key="history"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="space-y-4"
                >
                  <p className="text-xs text-slate-400">Audit trail of all deposits, cash-outs, and withdrawals requested within your Raya Bingo user session:</p>
                  
                  <div className="overflow-x-auto border border-slate-800 rounded-xl">
                    <table className="min-w-full divide-y divide-slate-800 text-left text-xs text-slate-400">
                      <thead className="bg-slate-950 text-slate-300 font-semibold">
                        <tr>
                          <th className="p-3">Reference/ID</th>
                          <th className="p-3">Method</th>
                          <th className="p-3 text-right">Amount</th>
                          <th className="p-3">Type</th>
                          <th className="p-3 text-center">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-850">
                        {transactions.length === 0 ? (
                          <tr>
                            <td colSpan={5} className="p-5 text-center text-slate-600 text-xs font-mono">No transaction logs available</td>
                          </tr>
                        ) : (
                          transactions.map(tx => (
                            <tr key={tx.id} className="hover:bg-slate-950 transition-colors">
                              <td className="p-3 select-all font-mono font-bold text-white text-[10px] truncate max-w-[100px]" title={tx.id}>
                                {tx.referenceNumber || tx.id}
                              </td>
                              <td className="p-3 capitalize font-semibold">{tx.method.replace('_', ' ')}</td>
                              <td className={`p-3 text-right font-mono font-bold ${tx.type === 'deposit' ? 'text-emerald-400' : 'text-rose-400'}`}>
                                {tx.type === 'deposit' ? '+' : '-'}{tx.amount} ETB
                              </td>
                              <td className="p-3">
                                <span className={`px-1.5 py-0.5 rounded text-[10px] font-semibold tracking-wider uppercase ${
                                  tx.type === 'deposit' ? 'bg-emerald-900/40 text-emerald-400 border border-emerald-800/60' : 'bg-red-900/40 text-red-400 border border-red-800/60'
                                }`}>
                                  {tx.type}
                                </span>
                              </td>
                              <td className="p-3 text-center">
                                <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold tracking-wider uppercase ${
                                  tx.status === 'completed' || tx.status === 'approved'
                                    ? 'bg-green-500/10 text-green-400 border border-green-500/30'
                                    : tx.status === 'pending'
                                    ? 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/30 glow-active'
                                    : 'bg-red-500/10 text-red-400 border border-red-500/30'
                                }`}>
                                  {tx.status}
                                </span>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

        </div>

      </div>
    </div>
  );
}
