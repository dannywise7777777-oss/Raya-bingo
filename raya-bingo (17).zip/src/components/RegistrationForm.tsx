/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Phone, 
  Lock, 
  ArrowRight, 
  CheckCircle, 
  MessageSquare, 
  Key, 
  Laptop,
  Coins,
  Smartphone,
  ChevronRight
} from 'lucide-react';

interface RegistrationFormProps {
  onRegisterSuccess: (userId: string, otpPrompt: boolean) => void;
  onVerifySuccess: (token: string, user: any) => void;
}

export default function RegistrationForm({ 
  onRegisterSuccess, 
  onVerifySuccess
}: RegistrationFormProps) {
  const [activeMode, setActiveMode] = useState<'telegram_portal' | 'admin_login'>('telegram_portal');
  const [botUsername, setBotUsername] = useState('Eti_Raya_Bingo_bot');
  const [adminPhone, setAdminPhone] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Dynamically retrieve the correct Telegram Bot username from the server configurations
    fetch('/api/telegram/bot-info')
      .then(res => res.json())
      .then(data => {
        if (data.username) {
          setBotUsername(data.username);
        }
      })
      .catch(err => console.error('Error fetching bot username info:', err));
  }, []);

  // Administrative login handler
  const handleAdminLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!adminPhone.trim() || !adminPassword.trim()) {
      setError('Please fill in both your phone number and password.');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phoneNumber: adminPhone.trim(),
          password: adminPassword.trim()
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Login failed. Please verify credentials.');
      }

      onVerifySuccess(data.token, data.user);
    } catch (err: any) {
      setError(err.message || 'Authentication error.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 rounded-2xl p-6 sm:p-8 shadow-2xl relative overflow-hidden" id="tg_registration_wrapper">
      {/* Visual background accents */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-green-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-32 h-32 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative">
        <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2" id="tg_title">
          <MessageSquare className="text-green-400" />
          Raya Bot Onboarding
        </h2>
        <p className="text-xs text-slate-400 mt-1 mb-6 font-medium">
          Ethiopia's premier real-time multiplayer Bingo. Register and join lobbies exclusively through Telegram.
        </p>

        {activeMode === 'telegram_portal' ? (
          <div className="space-y-6" id="tg_instructions_panel">
            {/* Play and Registration instructions steps */}
            <div className="space-y-4">
              <div className="flex gap-3">
                <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-500/10 border border-green-500/30 flex items-center justify-center text-xs font-bold text-green-400">
                  1
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-200">Launch Our Telegram Bot</h4>
                  <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                    Search for <span className="text-green-400 font-semibold font-mono">@{botUsername}</span> on Telegram or press the invite button below to activate your chat window.
                  </p>
                </div>
              </div>

              <div className="flex gap-3">
                <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-500/10 border border-green-500/30 flex items-center justify-center text-xs font-bold text-green-400">
                  2
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-200">Share Contact / Phone 📱</h4>
                  <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                    Inside the bot, tap the <strong className="text-white">Share Contact / Phone</strong> button. This instantly registers your playing profile and credits a <strong className="text-green-400">10 ETB free registration bonus</strong>!
                  </p>
                </div>
              </div>

              <div className="flex gap-3">
                <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-500/10 border border-green-500/30 flex items-center justify-center text-xs font-bold text-green-400">
                  3
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-200">Play Inside Telegram Instantly 🕹️</h4>
                  <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                    Launch the live game by hitting the bottom-left Menu Button <strong className="text-white">"Play Raya Bingo 🎮"</strong>. No manual username, form, or password required!
                  </p>
                </div>
              </div>
            </div>

            {/* Pulsing Game Bonus Badge */}
            <div className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 border border-green-500/20 rounded-xl p-3 flex items-center gap-3">
              <div className="bg-green-500/20 p-2 rounded-lg text-green-400 flex-shrink-0 animate-bounce">
                <Coins size={18} />
              </div>
              <div>
                <p className="text-[11px] font-bold text-green-400">10 ETB Welcome Offer Loaded</p>
                <p className="text-[9px] text-slate-400">Claimable instantly on verifying phone number through active contact card sharing.</p>
              </div>
            </div>

            {/* Main Action Button linking directly to the bot */}
            <a
              href={`https://t.me/${botUsername}`}
              target="_blank"
              rel="noopener noreferrer"
              id="btn_open_telegram"
              className="w-full flex items-center justify-center gap-2.5 py-3.5 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-400 hover:to-emerald-500 text-white text-xs font-extrabold uppercase tracking-widest rounded-xl cursor-pointer shadow-lg shadow-green-950/40 hover:shadow-green-500/10 transition-all transform hover:-translate-y-0.5 text-center active:scale-95"
            >
              <Smartphone size={16} />
              Open @{botUsername} Bot
              <ChevronRight size={14} />
            </a>

            {/* Direct Instant Refill Note */}
            <div className="bg-slate-900/50 border border-slate-850 rounded-xl p-3 text-center">
              <p className="text-[10px] text-slate-400 leading-normal">
                💡 <strong>Try Instant Refill:</strong> You can paste your Telebirr SMS notification message directly in the floating <strong className="text-yellow-400">⚡ Instant Refill</strong> panel in the bottom-right corner to fund your wallet instantly!
              </p>
            </div>

            {/* Hidden admin trigger toggle */}
            <div className="text-center pt-2">
              <button
                type="button"
                onClick={() => { setActiveMode('admin_login'); setError(''); }}
                id="toggle_admin_login"
                className="text-[10px] font-bold text-slate-500 hover:text-slate-300 transition-colors uppercase tracking-wider cursor-pointer inline-flex items-center gap-1.5"
              >
                <Key size={11} />
                Access Staff Portal login
              </button>
            </div>
          </div>
        ) : (
          <div id="admin_login_panel">
            <h3 className="text-xs font-bold text-amber-500 uppercase tracking-widest mb-4 flex items-center gap-1.5">
              <Laptop size={14} />
              Raya Bingo Staff Sign-In
            </h3>

            {error && (
              <div className="p-3 mb-4 bg-red-950/40 border border-red-800 text-red-400 text-xs rounded-xl" id="admin_login_error">
                {error}
              </div>
            )}

            <form onSubmit={handleAdminLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-450 mb-1.5">Staff Mobile Phone</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                    <Phone size={14} />
                  </div>
                  <input
                    type="text"
                    required
                    value={adminPhone}
                    onChange={(e) => setAdminPhone(e.target.value)}
                    placeholder="e.g. 0940889473"
                    id="admin_input_phone"
                    className="block w-full pl-10 pr-3.5 py-2.5 bg-slate-950 border border-slate-800 focus:border-amber-600 rounded-xl text-xs placeholder-slate-700 font-mono text-white focus:outline-none transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-450 mb-1.5">Security Password</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                    <Lock size={14} />
                  </div>
                  <input
                    type="password"
                    required
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                    placeholder="••••••••••••"
                    id="admin_input_password"
                    className="block w-full pl-10 pr-3.5 py-2.5 bg-slate-950 border border-slate-800 focus:border-amber-600 rounded-xl text-xs placeholder-slate-750 text-white focus:outline-none transition-colors"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                id="btn_admin_submit"
                className="w-full flex items-center justify-center gap-2 mt-4 py-3 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white text-xs font-bold uppercase tracking-wider rounded-xl cursor-pointer disabled:opacity-50 transition-all font-display hover:shadow-lg hover:shadow-amber-900/10"
              >
                {loading ? 'Verifying profile...' : 'Access Console'}
                <ArrowRight size={14} />
              </button>

              <button
                type="button"
                onClick={() => { setActiveMode('telegram_portal'); setError(''); }}
                id="back_to_telegram_portal"
                className="w-full text-center text-[10px] text-slate-450 hover:text-slate-300 mt-2 hover:underline transition-all cursor-pointer font-bold uppercase tracking-wider"
              >
                ← Back to Telegram Portal Instructions
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
