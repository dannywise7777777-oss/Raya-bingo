/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Zap, 
  X, 
  Check, 
  AlertCircle, 
  Info,
  Coins,
  RefreshCw,
  Sparkles
} from 'lucide-react';
import { User } from '../types.js';

interface RayaBotPortalProps {
  user: User | null;
  onLoginSuccess?: (token: string, user: any) => void;
  onBalanceUpdate?: (newBalance: number) => void;
  onAddNotif?: (msg: string, type: 'payment' | 'game' | 'system') => void;
}

export default function RayaBotPortal({ 
  user, 
  onLoginSuccess,
  onBalanceUpdate,
  onAddNotif 
}: RayaBotPortalProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [pastedSMS, setPastedSMS] = useState('');
  const [loading, setLoading] = useState(false);
  const [successData, setSuccessData] = useState<{ amount: number; reference: string; newBalance: number } | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleVerifySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pastedSMS.trim()) return;

    setLoading(true);
    setErrorMsg(null);
    setSuccessData(null);

    try {
      const token = localStorage.getItem('raya_token');
      if (!token) {
        setErrorMsg('Authentication required. Please register/log in first.');
        setLoading(false);
        return;
      }

      const res = await fetch('/api/payments/auto-deposit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          pastedSMS: pastedSMS,
          screenshot: '' // Only copy-paste support requested
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Verification failed. Make sure the message is a valid Telebirr advice.');
      }

      // Successful auto credit!
      setSuccessData({
        amount: data.amount || 0,
        reference: data.referenceNumber || 'Verified',
        newBalance: data.newBalance || 0
      });
      setPastedSMS('');

      // Update parent states
      if (onBalanceUpdate && data.newBalance !== undefined) {
        onBalanceUpdate(data.newBalance);
      }

      if (onAddNotif && data.amount) {
        onAddNotif(`🎉 Instantly credited ${data.amount} ETB via Telebirr SMS verify!`, 'payment');
      }

    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Unable to verify Telebirr transaction. Please ensure the full text is copied.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {/* FLOATING ACTION TRIGGER */}
      <div className="fixed bottom-4 right-4 z-40 select-none">
        <motion.button
          onClick={() => {
            setIsOpen(!isOpen);
            // reset state when opening
            if (!isOpen) {
              setSuccessData(null);
              setErrorMsg(null);
              setPastedSMS('');
            }
          }}
          className="flex h-12 px-4 items-center gap-2 rounded-full bg-gradient-to-r from-yellow-500 to-amber-600 text-[#0b0f19] font-black tracking-wider uppercase text-[11px] shadow-xl hover:shadow-yellow-500/10 hover:scale-105 active:scale-95 transition-all outline-none cursor-pointer border border-yellow-400/35 relative"
          id="btn_bot_floating"
          whileHover={{ scale: 1.05 }}
        >
          <Zap size={14} className="fill-[#0b0f19]" />
          <span>Instant Refill</span>
          
          <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-500 text-[8px] text-white font-bold items-center justify-center">⚡</span>
          </span>
        </motion.button>
      </div>

      {/* VERIFIER DIALOG CONTAINER */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.95 }}
            transition={{ duration: 0.2, ease: 'easeOut' }}
            className="fixed bottom-20 right-4 w-[340px] sm:w-[380px] bg-slate-950 border border-slate-800 rounded-2xl shadow-2xl flex flex-col z-50 overflow-hidden"
            id="bot_chat_panel"
          >
            {/* Header */}
            <div className="bg-slate-900 border-b border-slate-850 px-4 py-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="h-8 w-8 rounded-lg bg-yellow-500/10 border border-yellow-500/30 flex items-center justify-center text-yellow-400 shrink-0">
                  <Zap size={15} />
                </div>
                <div>
                  <h3 className="text-xs font-black text-white leading-none uppercase tracking-wide">
                    Telebirr Dynamic Ledger
                  </h3>
                  <span className="text-[10px] text-slate-400 leading-none">Real-time Refill Verifier</span>
                </div>
              </div>
              <button 
                onClick={() => setIsOpen(false)}
                className="p-1 text-slate-500 hover:text-slate-300 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              >
                <X size={15} />
              </button>
            </div>

            {/* Body */}
            <div className="p-4 flex-1 flex flex-col justify-between">
              {!user ? (
                /* Unauthenticated View */
                <div className="py-8 text-center flex flex-col items-center justify-center">
                  <Coins className="text-slate-600 mb-2.5 animate-pulse" size={24} />
                  <p className="text-[11px] text-slate-300 font-bold mb-1">Authorization Pending</p>
                  <p className="text-[10px] text-slate-500 max-w-[240px] leading-relaxed mx-auto">
                    Please log in or register your account at the top layout to unlock instant automated ledger crediting!
                  </p>
                </div>
              ) : successData ? (
                /* Success View */
                <motion.div 
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="space-y-4 py-2"
                >
                  <div className="mx-auto h-12 w-12 rounded-full bg-emerald-500/10 border border-emerald-500/25 flex items-center justify-center text-emerald-400">
                    <Check size={20} />
                  </div>
                  
                  <div className="text-center">
                    <h4 className="text-xs font-black text-white uppercase tracking-wider">Deposit Refill Approved!</h4>
                    <p className="text-[10px] text-slate-400 mt-1">Successfully matched transaction with telebirr.com official database.</p>
                  </div>

                  <div className="bg-slate-900 border border-slate-850 p-3 rounded-xl divide-y divide-slate-800 space-y-2 text-[11px] font-mono">
                    <div className="flex justify-between text-slate-400">
                      <span>Credited Amount:</span>
                      <span className="text-yellow-400 font-bold">+{successData.amount} ETB</span>
                    </div>
                    <div className="flex justify-between text-slate-400 pt-1.5">
                      <span>Reference ID:</span>
                      <span className="text-white font-bold">{successData.reference}</span>
                    </div>
                    <div className="flex justify-between text-slate-400 pt-1.5">
                      <span>Wallet Balance:</span>
                      <span className="text-emerald-400 font-bold">{successData.newBalance} ETB</span>
                    </div>
                  </div>

                  <button
                    onClick={() => setSuccessData(null)}
                    className="w-full py-2 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-200 text-[10px] font-bold uppercase tracking-wider rounded-xl transition-colors cursor-pointer"
                  >
                    Load Another Paste
                  </button>
                </motion.div>
              ) : (
                /* Main Paste Form View */
                <form onSubmit={handleVerifySubmit} className="space-y-3">
                  <div className="bg-slate-900/60 border border-slate-850/80 p-2.5 rounded-xl flex items-start gap-2 text-[10px] text-slate-400">
                    <Info size={13} className="text-yellow-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-slate-200 block mb-0.5">⚡ Automatic Receipt Checker</strong>
                      Copy and paste the entire Telebirr SMS text here. Our background service parses the reference and updates your balance on the spot.
                    </div>
                  </div>

                  {errorMsg && (
                    <div className="p-2.5 bg-rose-950/20 border border-rose-900/40 text-rose-400 text-[10px] rounded-xl flex items-center gap-1.5 min-h-[36px]">
                      <AlertCircle size={14} className="shrink-0" />
                      <span>{errorMsg}</span>
                    </div>
                  )}

                  <div>
                    <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 mb-1">Paste Telebirr SMS Advice Text Here</label>
                    <textarea
                      value={pastedSMS}
                      onChange={(e) => setPastedSMS(e.target.value)}
                      placeholder="e.g. Transaction of Birr 250.00 from 0940889473 is successful. transaction id is 9FJ6AM49K2..."
                      rows={4}
                      className="block w-full px-3 py-2 bg-slate-950 border border-slate-850 focus:border-yellow-500 rounded-xl text-[11px] font-mono text-white focus:outline-none focus:ring-0 transition-colors resize-none placeholder:text-slate-700"
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={loading || !pastedSMS.trim()}
                    className="w-full py-2.5 bg-gradient-to-r from-yellow-500 to-amber-600 hover:from-yellow-450 hover:to-amber-550 text-slate-950 text-[10px] font-black uppercase tracking-wider rounded-xl font-semibold transition-all flex items-center justify-center gap-1.5 disabled:opacity-40 cursor-pointer"
                  >
                    {loading ? (
                      <>
                        <RefreshCw size={11} className="animate-spin" />
                        <span>Verifying ledger...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles size={11} />
                        <span>Verify & Deposit Instantly</span>
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
